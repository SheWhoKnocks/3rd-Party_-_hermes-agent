#!/usr/bin/env python3
"""Install a tested runtime patch over v3.16.4 or newer. Preserve configuration and data."""
from pathlib import Path
import argparse,ast,datetime,hashlib,json,os,shutil,sqlite3,subprocess,time
ROOT=Path(__file__).resolve().parents[1]
def docker_info():return json.loads(subprocess.check_output(["docker","inspect","ai-proxy-agent-runtime-1"],text=True))[0]
def compose(state):
 cmd=["docker","compose","--project-directory",state["cwd"],"-p",state["project"]]
 for name in state["compose_files"]:cmd += ["-f",name]
 return cmd

def restore(backup):
 state=json.loads((backup/"state.json").read_text())
 shutil.copy2(backup/"app.py",Path(state["cwd"])/"agent-runtime/app.py")
 subprocess.run(["docker","image","tag",state["previous_image"],"ai-proxy-agent-runtime:latest"],check=True)
 subprocess.run(compose(state)+["up","-d","--no-deps","--no-build","--force-recreate","agent-runtime"],check=True)
 print("ROLLBACK_APPLIED; current runtime data and configuration retained")

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument("--dry-run",action="store_true")
 parser.add_argument("--rollback",type=Path)
 args=parser.parse_args()
 if args.rollback:
  if os.geteuid()!=0:parser.error("Use sudo for rollback")
  restore(args.rollback.resolve());return
 manifest=json.loads((ROOT/"release.json").read_text());version=manifest["version"]
 for line in (ROOT/"SHA256SUMS").read_text().splitlines():
  digest,name=line.split("  ",1);path=(ROOT/name).resolve()
  if not path.is_relative_to(ROOT.resolve()) or hashlib.sha256(path.read_bytes()).hexdigest()!=digest:raise RuntimeError("Invalid package checksum: "+name)
 source=ROOT/"opt/ai-proxy/agent-runtime/app.py";compile(source.read_bytes(),str(source),"exec")
 actual=next(ast.literal_eval(line.split("=",1)[1].strip()) for line in source.read_text().splitlines() if line.startswith("APP_VERSION ="));assert actual==version
 info=docker_info();labels=info["Config"]["Labels"];cwd=Path(labels["com.docker.compose.project.working_dir"])
 assert str(cwd)=="/opt/ai-proxy","Nonstandard target; use the full installer"
 current=next(ast.literal_eval(line.split("=",1)[1].strip()) for line in (cwd/"agent-runtime/app.py").read_text().splitlines() if line.startswith("APP_VERSION ="))
 assert tuple(map(int,current.split(".")))>=(3,16,4),"Use the cumulative installer to upgrade older installations first"
 env=dict(x.split("=",1) for x in info["Config"]["Env"])
 assert float(env.get("AGENT_REASONING_TIMEOUT_SECONDS","90"))>=90 and int(env.get("AGENT_REASONING_MAX_TOKENS","2400"))>=2400,"Configured reasoning budget/timeout needs review"
 if args.dry_run:print("DRY_RUN_OK",version,"checksums, syntax, target and settings verified; no changes made");return
 if os.geteuid()!=0:parser.error("Use sudo to install")
 stamp=datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
 backup=Path("/opt/AI-Install/backups")/("v"+version+"-"+stamp);backup.mkdir(parents=True,mode=0o700);backup.chmod(0o700)
 state={"version":version,"backup":str(backup),"previous_image":info["Image"],"cwd":str(cwd),"project":labels["com.docker.compose.project"],"compose_files":labels["com.docker.compose.project.config_files"].split(","),"runtime_volume":next(x["Source"] for x in info["Mounts"] if x["Destination"]=="/runtime"),"release":str(ROOT)}
 (backup/"state.json").write_text(json.dumps(state,indent=2));(Path("/opt/AI-Install")/("v"+version+"-deployment-state-path")).write_text(str(backup/"state.json"))
 shutil.copy2(cwd/"agent-runtime/app.py",backup/"app.py");shutil.copy2(cwd/".env",backup/"env.private")
 for i,name in enumerate(state["compose_files"]):shutil.copy2(name,backup/("compose-"+str(i)+".yml"))
 shutil.copy2(Path(__file__),backup/"installer.py")
 tag="ai-proxy-agent-runtime:rollback-"+stamp.lower();subprocess.run(["docker","image","tag",info["Image"],tag],check=True)
 (backup/"Dockerfile.release").write_text("FROM "+tag+chr(10)+"COPY app.py /app/app.py"+chr(10))
 image="ai-proxy-agent-runtime:"+version
 with (backup/"build.log").open("w") as log:subprocess.run(["docker","build","--network","none","-f",str(backup/"Dockerfile.release"),"-t",image,str(source.parent)],check=True,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 for attempt in range(60):
  c=sqlite3.connect("file:"+state["runtime_volume"]+"/tasks.db?mode=ro",uri=True,timeout=5);running=c.execute("SELECT count(*) FROM agent_jobs WHERE status='running'").fetchone()[0];c.close()
  if not running:break
  time.sleep(2)
 assert not running,"Tasks still running; installation not started"
 print("IMAGE_READY; backup",backup,flush=True)
 try:
  subprocess.run(["docker","stop","--time","30","ai-proxy-agent-runtime-1"],check=True,capture_output=True,timeout=45)
  subprocess.run(["tar","-czf",str(backup/"runtime-volume.tar.gz"),"-C",state["runtime_volume"],"."],check=True,capture_output=True,timeout=180)
  shutil.copy2(source,cwd/"agent-runtime/app.py")
  subprocess.run(["docker","image","tag",image,"ai-proxy-agent-runtime:latest"],check=True)
  with (backup/"deploy.log").open("w") as log:subprocess.run(compose(state)+["up","-d","--no-deps","--no-build","--force-recreate","agent-runtime"],check=True,stdout=log,stderr=subprocess.STDOUT,timeout=90)
  for attempt in range(45):
   fresh=docker_info();health=(fresh["State"].get("Health") or {}).get("Status")
   if health=="healthy":break
   if fresh["State"]["Status"] in {"exited","dead"}:raise RuntimeError("Runtime exited")
   time.sleep(2)
  assert health=="healthy","Runtime did not become healthy"
  assert fresh["Image"]==subprocess.check_output(["docker","image","inspect",image,"--format","{{.Id}}"],text=True).strip()
  state["status"]="healthy";state["deployed_image"]=fresh["Image"];(backup/"state.json").write_text(json.dumps(state,indent=2));print("DEPLOYED",version,"healthy; rollback backup",backup,flush=True)
 except Exception:
  print("Deployment failed; restoring previous runtime",flush=True);restore(backup);raise
if __name__=="__main__":main()
