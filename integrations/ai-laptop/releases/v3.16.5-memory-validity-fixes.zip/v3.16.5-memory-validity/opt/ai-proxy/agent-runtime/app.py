import hashlib
from contextlib import closing
from concurrent.futures import ThreadPoolExecutor, as_completed
import ipaddress
import json
import os
import re
import shlex
import shutil
import signal
import socket
import sqlite3
import subprocess
import threading
import time
import uuid
from datetime import datetime, timezone, timedelta
from zoneinfo import ZoneInfo
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import httpx
import yaml
import redis
from fastapi import Depends, FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

APP_VERSION = "3.16.5"
API_KEY = os.environ["AGENT_RUNTIME_API_KEY"]
AGENTS_DIR = Path(os.environ.get("AGENTS_DIR", "/config/agents"))
SKILLS_FILE = Path(os.environ.get("SKILLS_FILE", "/config/skills/registry.yaml"))
WORKSPACES = Path(os.environ.get("WORKSPACES_ROOT", "/workspaces")).resolve()
RUNTIME = Path(os.environ.get("RUNTIME_ROOT", "/runtime")).resolve()
TASK_DB = RUNTIME / "tasks.db"
CHECKPOINTS = RUNTIME / "checkpoints"
MAX_FILE_BYTES = int(os.environ.get("MAX_FILE_BYTES", "2000000"))
MAX_FETCH_BYTES = int(os.environ.get("MAX_FETCH_BYTES", "2000000"))
MEM0_URL = os.environ.get("MEM0_URL", "http://mem0:8080").rstrip("/")
MEM0_API_KEY = os.environ.get("MEM0_SERVICE_API_KEY", "")
LIFE_PROFILE_URL = os.environ.get("LIFE_PROFILE_URL", "http://life-profile:8081").rstrip("/")
LIFE_PROFILE_API_KEY = os.environ.get("LIFE_PROFILE_API_KEY", "")
PROACTIVE_URL = os.environ.get("PROACTIVE_URL", "http://proactive-assistant:8768").rstrip("/")
PROACTIVE_API_KEY = os.environ.get("PROACTIVE_ASSISTANT_API_KEY", "")
RHYTHM_URL = os.environ.get("RHYTHM_URL", "http://life-dashboard:8770").rstrip("/")
SCHEDULE_URL = os.environ.get("SCHEDULE_URL", "http://schedule-service:8772").rstrip("/")
SCHEDULE_API_KEY = os.environ.get("SCHEDULE_API_KEY", "")
HOME_ASSISTANT_GATEWAY_URL = os.environ.get("HOME_ASSISTANT_GATEWAY_URL", "http://home-assistant-gateway:8773").rstrip("/")
HOME_ASSISTANT_GATEWAY_API_KEY = os.environ.get("HOME_ASSISTANT_GATEWAY_API_KEY", "")
PLANNER_URL = os.environ.get("PLANNER_URL", "http://planner-service:8774").rstrip("/")
PLANNER_API_KEY = os.environ.get("PLANNER_API_KEY", "")
CURRENT_STATE_URL = os.environ.get("CURRENT_STATE_URL", "http://current-state-service:8780").rstrip("/")
CURRENT_STATE_API_KEY = os.environ.get("CURRENT_STATE_API_KEY", "")
NOTIFICATION_URL = os.environ.get("NOTIFICATION_URL", "http://notification-service:8781").rstrip("/")
NOTIFICATION_API_KEY = os.environ.get("NOTIFICATION_API_KEY", "")
ASSISTANCE_CONTROL_URL = os.environ.get("ASSISTANCE_CONTROL_URL", "http://assistance-control-service:8782").rstrip("/")
ASSISTANCE_CONTROL_API_KEY = os.environ.get("ASSISTANCE_CONTROL_API_KEY", "")
CALENDAR_INTELLIGENCE_URL = os.environ.get("CALENDAR_INTELLIGENCE_URL", "http://calendar-intelligence-service:8783").rstrip("/")
CALENDAR_INTELLIGENCE_API_KEY = os.environ.get("CALENDAR_INTELLIGENCE_API_KEY", "")
TIMELINE_URL = os.environ.get("TIMELINE_URL", "http://timeline-service:8784").rstrip("/")
TIMELINE_API_KEY = os.environ.get("TIMELINE_API_KEY", "")
ENVIRONMENT_CONTEXT_URL = os.environ.get("ENVIRONMENT_CONTEXT_URL", "http://environment-context-service:8785").rstrip("/")
ENVIRONMENT_CONTEXT_API_KEY = os.environ.get("ENVIRONMENT_CONTEXT_API_KEY", "")
REDIS_HOST = os.environ.get("REDIS_HOST", "redis")
REDIS_PORT = int(os.environ.get("REDIS_PORT", "6379"))
REDIS_PASSWORD = os.environ.get("REDIS_PASSWORD", "")
AGENT_NODE_ID = os.environ.get("AGENT_NODE_ID", socket.gethostname())
AGENT_EVENT_STREAM = os.environ.get("AGENT_EVENT_STREAM", "ai:agent-events")
AGENT_CONSUMER_GROUP = os.environ.get("AGENT_CONSUMER_GROUP", "ai-agent-runtime")
AGENT_HEARTBEAT_SECONDS = int(os.environ.get("AGENT_HEARTBEAT_SECONDS", "30"))
AGENT_SCHEDULER_SECONDS = int(os.environ.get("AGENT_SCHEDULER_SECONDS", "15"))
AGENT_EVENT_MAXLEN = int(os.environ.get("AGENT_EVENT_MAXLEN", "10000"))
AGENT_WORKER_SECONDS = float(os.environ.get("AGENT_WORKER_SECONDS", "1"))
AGENT_JOB_LEASE_SECONDS = int(os.environ.get("AGENT_JOB_LEASE_SECONDS", "120"))
AGENT_JOB_MAX_ATTEMPTS = int(os.environ.get("AGENT_JOB_MAX_ATTEMPTS", "3"))
AGENT_COMPLETED_RETENTION_HOURS = int(os.environ.get("AGENT_COMPLETED_RETENTION_HOURS", "168"))
AGENT_LEARNING_MIN_SUCCESSES = int(os.environ.get("AGENT_LEARNING_MIN_SUCCESSES", "3"))
AGENT_SESSION_SEARCH_LIMIT = int(os.environ.get("AGENT_SESSION_SEARCH_LIMIT", "20"))
POLICIES_DIR = Path(os.environ.get("POLICIES_DIR", "/config/policies"))
MODE_POLICY_FILE = Path(os.environ.get("MODE_POLICY_FILE", str(POLICIES_DIR / "agent-modes.yaml")))
GUARDRAIL_POLICY_FILE = Path(os.environ.get("GUARDRAIL_POLICY_FILE", str(POLICIES_DIR / "guardrail-policy.yaml")))
MODEL_ROLE_FILE = Path(os.environ.get("MODEL_ROLE_FILE", "/config/models/role-routing.yaml"))
AGENT_CONTEXT_CHECKPOINT_MAX_CHARS = int(os.environ.get("AGENT_CONTEXT_CHECKPOINT_MAX_CHARS", "12000"))
AGENT_PROJECT_GRAPH_MAX_FILES = int(os.environ.get("AGENT_PROJECT_GRAPH_MAX_FILES", "5000"))
LITELLM_URL = os.environ.get("LITELLM_URL", "http://litellm:4000/v1").rstrip("/")
LITELLM_API_KEY = os.environ.get("LITELLM_API_KEY", "")
AGENT_REASONING_ENABLED = os.environ.get("AGENT_REASONING_ENABLED", "true").lower() in {"1","true","yes","on"}
AGENT_REASONING_MAX_ACTIONS = int(os.environ.get("AGENT_REASONING_MAX_ACTIONS", "4"))
AGENT_REASONING_HISTORY_LIMIT = int(os.environ.get("AGENT_REASONING_HISTORY_LIMIT", "6"))
AGENT_REASONING_CONTEXT_CHARS = int(os.environ.get("AGENT_REASONING_CONTEXT_CHARS", "12000"))
AGENT_REASONING_TIMEOUT_SECONDS = float(os.environ.get("AGENT_REASONING_TIMEOUT_SECONDS", "90"))
AGENT_REASONING_MAX_TOKENS = int(os.environ.get("AGENT_REASONING_MAX_TOKENS", "2400"))
# Cover both JSON-format compatibility requests plus completion bookkeeping.
AGENT_JOB_LEASE_SECONDS = max(AGENT_JOB_LEASE_SECONDS, int(2 * AGENT_REASONING_TIMEOUT_SECONDS + 60))
RESOURCE_GUARDIAN_STATUS_FILE = Path(os.environ.get("RESOURCE_GUARDIAN_STATUS_FILE", "/resource-guardian/status.json"))
AGENT_RESOURCE_HEADROOM_MB = int(os.environ.get("AGENT_RESOURCE_HEADROOM_MB", "1536"))
AGENT_RESOURCE_WAIT_SECONDS = int(os.environ.get("AGENT_RESOURCE_WAIT_SECONDS", "30"))
AGENT_RESOURCE_MAX_WAITS = int(os.environ.get("AGENT_RESOURCE_MAX_WAITS", "20"))
AGENT_RESOURCE_STALE_SECONDS = int(os.environ.get("AGENT_RESOURCE_STALE_SECONDS", "180"))
AGENT_GPU_BUSY_UTIL_PERCENT = float(os.environ.get("AGENT_GPU_BUSY_UTIL_PERCENT", "85"))
try:
    AGENT_MODEL_VRAM_ESTIMATES = json.loads(os.environ.get("AGENT_MODEL_VRAM_ESTIMATES_JSON", '{"fast-local":3500,"reasoning-local":4096,"coding-local":4096,"reviewer":3500,"embedding":512,"vision":6000}'))
except Exception:
    AGENT_MODEL_VRAM_ESTIMATES = {"fast-local":3500,"reasoning-local":4096,"coding-local":4096,"reviewer":3500,"embedding":512,"vision":6000}
LIFE_ASSISTANT_TIMEZONE = os.environ.get("LIFE_ASSISTANT_TIMEZONE", "America/Edmonton").strip() or "America/Edmonton"
try:
    ASSISTANT_ZONE = ZoneInfo(LIFE_ASSISTANT_TIMEZONE)
except Exception as exc:
    raise RuntimeError(f"Invalid LIFE_ASSISTANT_TIMEZONE={LIFE_ASSISTANT_TIMEZONE!r}: {exc}") from exc

SHELL_ALLOW = set(filter(None, os.environ.get(
    "CONTROLLED_COMMANDS",
    "git,python,python3,pytest,grep,sed,awk,find,ls,cat,head,tail,sha256sum,tar,zip,unzip"
).split(",")))

app = FastAPI(title="AI Laptop Agent Runtime", version=APP_VERSION)


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def auth(authorization: str | None = Header(default=None)) -> None:
    if authorization != f"Bearer {API_KEY}":
        raise HTTPException(status_code=401, detail="Invalid or missing bearer token")


def db() -> sqlite3.Connection:
    RUNTIME.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(TASK_DB, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=30000")
    return conn


def init_db() -> None:
    CHECKPOINTS.mkdir(parents=True, exist_ok=True)
    with db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS tasks(
          id TEXT PRIMARY KEY,
          agent_id TEXT NOT NULL,
          objective TEXT NOT NULL,
          phase TEXT NOT NULL,
          status TEXT NOT NULL,
          plan_json TEXT NOT NULL DEFAULT '[]',
          evidence_json TEXT NOT NULL DEFAULT '[]',
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS tool_events(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          task_id TEXT,
          agent_id TEXT NOT NULL,
          tool TEXT NOT NULL,
          policy_class TEXT NOT NULL,
          approved INTEGER NOT NULL DEFAULT 0,
          success INTEGER NOT NULL,
          detail TEXT,
          created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS agent_jobs(
          id TEXT PRIMARY KEY,
          agent_id TEXT NOT NULL,
          trigger_type TEXT NOT NULL,
          trigger_id TEXT,
          event_type TEXT,
          payload_json TEXT NOT NULL DEFAULT '{}',
          status TEXT NOT NULL DEFAULT 'queued',
          priority INTEGER NOT NULL DEFAULT 50,
          node_id TEXT NOT NULL,
          attempts INTEGER NOT NULL DEFAULT 0,
          lease_owner TEXT,
          lease_expires_at TEXT,
          result_json TEXT NOT NULL DEFAULT '{}',
          error_text TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          UNIQUE(agent_id, trigger_type, trigger_id)
        );
        CREATE TABLE IF NOT EXISTS agent_status(
          agent_id TEXT PRIMARY KEY,
          state TEXT NOT NULL,
          node_id TEXT NOT NULL,
          last_heartbeat TEXT NOT NULL,
          last_event TEXT,
          last_job_id TEXT,
          detail_json TEXT NOT NULL DEFAULT '{}'
        );
        CREATE TABLE IF NOT EXISTS a2a_messages(
          id TEXT PRIMARY KEY,
          from_agent TEXT NOT NULL,
          to_agent TEXT NOT NULL,
          kind TEXT NOT NULL,
          payload_json TEXT NOT NULL DEFAULT '{}',
          status TEXT NOT NULL DEFAULT 'queued',
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS agent_artifacts(
          id TEXT PRIMARY KEY,
          agent_id TEXT NOT NULL,
          job_id TEXT,
          artifact_type TEXT NOT NULL,
          path TEXT,
          metadata_json TEXT NOT NULL DEFAULT '{}',
          created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS session_messages(
          id TEXT PRIMARY KEY,
          user_id TEXT,
          chat_id TEXT,
          message_id TEXT,
          model TEXT,
          input_type TEXT,
          text TEXT NOT NULL,
          created_at TEXT NOT NULL
        );
        CREATE VIRTUAL TABLE IF NOT EXISTS session_messages_fts USING fts5(id UNINDEXED, user_id UNINDEXED, chat_id UNINDEXED, text, content='session_messages', content_rowid='rowid');
        CREATE TRIGGER IF NOT EXISTS session_messages_ai AFTER INSERT ON session_messages BEGIN
          INSERT INTO session_messages_fts(rowid,id,user_id,chat_id,text) VALUES (new.rowid,new.id,new.user_id,new.chat_id,new.text);
        END;
        CREATE TRIGGER IF NOT EXISTS session_messages_ad AFTER DELETE ON session_messages BEGIN
          INSERT INTO session_messages_fts(session_messages_fts,rowid,id,user_id,chat_id,text) VALUES('delete',old.rowid,old.id,old.user_id,old.chat_id,old.text);
        END;
        CREATE TRIGGER IF NOT EXISTS session_messages_au AFTER UPDATE ON session_messages BEGIN
          INSERT INTO session_messages_fts(session_messages_fts,rowid,id,user_id,chat_id,text) VALUES('delete',old.rowid,old.id,old.user_id,old.chat_id,old.text);
          INSERT INTO session_messages_fts(rowid,id,user_id,chat_id,text) VALUES (new.rowid,new.id,new.user_id,new.chat_id,new.text);
        END;
        CREATE TABLE IF NOT EXISTS skill_observations(
          signature TEXT PRIMARY KEY,
          agent_id TEXT NOT NULL,
          task_name TEXT NOT NULL,
          success_count INTEGER NOT NULL DEFAULT 0,
          failure_count INTEGER NOT NULL DEFAULT 0,
          last_job_id TEXT,
          last_result_json TEXT NOT NULL DEFAULT '{}',
          first_seen_at TEXT NOT NULL,
          last_seen_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS skill_candidates(
          id TEXT PRIMARY KEY,
          signature TEXT UNIQUE NOT NULL,
          agent_id TEXT NOT NULL,
          name TEXT NOT NULL,
          description TEXT NOT NULL,
          procedure_json TEXT NOT NULL DEFAULT '{}',
          required_tools_json TEXT NOT NULL DEFAULT '[]',
          status TEXT NOT NULL DEFAULT 'candidate',
          evidence_count INTEGER NOT NULL DEFAULT 0,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS learned_skills(
          id TEXT PRIMARY KEY,
          name TEXT UNIQUE NOT NULL,
          version INTEGER NOT NULL DEFAULT 1,
          agent_id TEXT NOT NULL,
          description TEXT NOT NULL,
          procedure_json TEXT NOT NULL DEFAULT '{}',
          required_tools_json TEXT NOT NULL DEFAULT '[]',
          source_candidate_id TEXT,
          status TEXT NOT NULL DEFAULT 'active',
          promoted_by TEXT NOT NULL,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS skill_usage(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          skill_name TEXT NOT NULL,
          agent_id TEXT NOT NULL,
          job_id TEXT,
          context_json TEXT NOT NULL DEFAULT '{}',
          success INTEGER,
          created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS delegations(
          id TEXT PRIMARY KEY,
          parent_agent TEXT NOT NULL,
          child_agent TEXT NOT NULL,
          parent_task_id TEXT,
          child_task_id TEXT NOT NULL,
          mode TEXT NOT NULL,
          objective TEXT NOT NULL,
          context_json TEXT NOT NULL DEFAULT '{}',
          session_sources_json TEXT NOT NULL DEFAULT '[]',
          status TEXT NOT NULL DEFAULT 'queued',
          depth INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS guardrail_runs(
          id TEXT PRIMARY KEY,
          agent_id TEXT NOT NULL,
          task_id TEXT,
          mode TEXT NOT NULL,
          tool TEXT,
          outcome TEXT NOT NULL,
          checks_json TEXT NOT NULL DEFAULT '[]',
          created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS context_checkpoints(
          id TEXT PRIMARY KEY,
          agent_id TEXT NOT NULL,
          task_id TEXT,
          summary TEXT NOT NULL,
          sources_json TEXT NOT NULL DEFAULT '[]',
          created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS project_graph_files(
          agent_id TEXT NOT NULL,
          path TEXT NOT NULL,
          language TEXT,
          sha256 TEXT NOT NULL,
          symbols_json TEXT NOT NULL DEFAULT '[]',
          imports_json TEXT NOT NULL DEFAULT '[]',
          indexed_at TEXT NOT NULL,
          PRIMARY KEY(agent_id,path)
        );
        CREATE TABLE IF NOT EXISTS reasoning_runs(
          id TEXT PRIMARY KEY,
          correlation_id TEXT,
          agent_id TEXT NOT NULL,
          job_id TEXT,
          mode TEXT NOT NULL,
          model_role TEXT NOT NULL,
          model_alias TEXT,
          status TEXT NOT NULL,
          prompt_context_json TEXT NOT NULL DEFAULT '{}',
          proposal_json TEXT NOT NULL DEFAULT '{}',
          result_json TEXT NOT NULL DEFAULT '{}',
          error_text TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        );
        CREATE UNIQUE INDEX IF NOT EXISTS idx_reasoning_correlation_owner ON reasoning_runs(correlation_id) WHERE correlation_id IS NOT NULL;
        CREATE TABLE IF NOT EXISTS reasoning_actions(
          id TEXT PRIMARY KEY,
          reasoning_run_id TEXT NOT NULL,
          agent_id TEXT NOT NULL,
          tool TEXT NOT NULL,
          mode TEXT NOT NULL,
          policy_class TEXT NOT NULL,
          status TEXT NOT NULL,
          arguments_json TEXT NOT NULL DEFAULT '{}',
          result_json TEXT NOT NULL DEFAULT '{}',
          verification_json TEXT NOT NULL DEFAULT '{}',
          reviewer_json TEXT NOT NULL DEFAULT '{}',
          error_text TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS pending_actions(
          id TEXT PRIMARY KEY,
          user_id TEXT NOT NULL,
          chat_id TEXT NOT NULL,
          action_type TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'pending',
          state_json TEXT NOT NULL DEFAULT '{}',
          required_fields_json TEXT NOT NULL DEFAULT '[]',
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          expires_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_pending_actions_lookup ON pending_actions(user_id,chat_id,status,updated_at);
        CREATE TABLE IF NOT EXISTS fanout_batches(
          id TEXT PRIMARY KEY,agent_id TEXT NOT NULL,status TEXT NOT NULL,schema_json TEXT NOT NULL,items_json TEXT NOT NULL,result_json TEXT NOT NULL DEFAULT '{}',created_at TEXT NOT NULL,updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS resource_admissions(
          id TEXT PRIMARY KEY,model_role TEXT NOT NULL,decision TEXT NOT NULL,detail_json TEXT NOT NULL,created_at TEXT NOT NULL
        );
        """)
        columns={r[1] for r in conn.execute("PRAGMA table_info(agent_jobs)").fetchall()}
        migrations={
            "attempts":"INTEGER NOT NULL DEFAULT 0",
            "lease_owner":"TEXT",
            "lease_expires_at":"TEXT",
            "result_json":"TEXT NOT NULL DEFAULT '{}'",
            "error_text":"TEXT",
            "not_before":"TEXT",
            "resource_waits":"INTEGER NOT NULL DEFAULT 0",
        }
        for name,ddl in migrations.items():
            if name not in columns:
                conn.execute(f"ALTER TABLE agent_jobs ADD COLUMN {name} {ddl}")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_agent_jobs_claim ON agent_jobs(status,priority,created_at)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_agent_jobs_agent_status ON agent_jobs(agent_id,status)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_session_messages_user_created ON session_messages(user_id,created_at)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_skill_candidates_status ON skill_candidates(status,agent_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_delegations_parent ON delegations(parent_agent,status,created_at)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_guardrail_runs_task ON guardrail_runs(task_id,created_at)")


def load_agent(agent_id: str) -> dict[str, Any]:
    p = AGENTS_DIR / agent_id / "agent.yaml"
    if not p.exists():
        raise HTTPException(status_code=404, detail=f"Unknown agent: {agent_id}")
    data = yaml.safe_load(p.read_text()) or {}
    if data.get("name") != agent_id:
        raise HTTPException(status_code=500, detail="Agent manifest name mismatch")
    return data


def tool_class(agent: dict[str, Any], tool: str) -> str:
    return str((agent.get("tools") or {}).get(tool, "DENY"))


def _yaml_file(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    data = yaml.safe_load(path.read_text()) or {}
    return data if isinstance(data, dict) else {}


def mode_catalog() -> dict[str, Any]:
    data = _yaml_file(MODE_POLICY_FILE)
    return data.get("modes", {}) if isinstance(data.get("modes", {}), dict) else {}


def mode_policy(mode: str) -> dict[str, Any]:
    modes = mode_catalog()
    if mode not in modes:
        raise HTTPException(status_code=400, detail=f"Unknown agent mode: {mode}")
    cfg = modes[mode] or {}
    return cfg if isinstance(cfg, dict) else {}


def effective_tool_class(agent: dict[str, Any], tool: str, mode: str = "default") -> str:
    base = tool_class(agent, tool)
    cfg = mode_policy(mode)
    if tool in set(str(x) for x in cfg.get("deny_tools", []) or []):
        return "DENY"
    denied_classes = set(str(x) for x in cfg.get("deny_policy_classes", []) or [])
    allowed_tools = set(str(x) for x in cfg.get("allow_tools", []) or [])
    if base in denied_classes and tool not in allowed_tools:
        return "DENY"
    return base


def model_roles() -> dict[str, Any]:
    data = _yaml_file(MODEL_ROLE_FILE)
    return data.get("roles", {}) if isinstance(data.get("roles", {}), dict) else {}


def _guardrail_policy() -> dict[str, Any]:
    return _yaml_file(GUARDRAIL_POLICY_FILE)


def _guardrail_checks(agent_id: str, task_id: str | None, mode: str, tool: str | None, arguments: dict[str, Any], approved: bool = False) -> dict[str, Any]:
    agent = load_agent(agent_id)
    klass = effective_tool_class(agent, tool, mode) if tool else "AUTO_READ"
    checks: list[dict[str, Any]] = []
    outcome = "pass"
    if tool and klass == "DENY":
        checks.append({"name": "tool_policy", "status": "blocked", "detail": "agent/mode policy denies tool"})
        outcome = "blocked"
    else:
        checks.append({"name": "tool_policy", "status": "pass", "detail": klass})
    raw = json.dumps(arguments, ensure_ascii=False)
    secret = bool(re.search(r"(?i)(api[_-]?key|secret|password|token)\s*[:=]\s*['\"]?[A-Za-z0-9_\-]{16,}", raw))
    checks.append({"name": "secret_pattern", "status": "blocked" if secret else "pass"})
    if secret:
        outcome = "blocked"
    destructive = any(x.lower() in raw.lower() for x in ["rm -rf", "mkfs", "wipefs", "drop database", "truncate table"])
    if destructive and not approved:
        checks.append({"name": "destructive_intent", "status": "approval_required"})
        if outcome != "blocked": outcome = "approval_required"
    else:
        checks.append({"name": "destructive_intent", "status": "pass"})
    mutating = klass in {"AUTO_WRITE_SCOPED", "CONTROLLED", "APPROVAL_REQUIRED"}
    requires_review = bool(mode_policy(mode).get("require_review_for_mutation", False)) and mutating
    checks.append({"name": "mutation_review", "status": "review_required" if requires_review else "not_required", "model_role": "reviewer" if requires_review else None})
    run_id = str(uuid.uuid4())
    with db() as conn:
        conn.execute("INSERT INTO guardrail_runs(id,agent_id,task_id,mode,tool,outcome,checks_json,created_at) VALUES(?,?,?,?,?,?,?,?)", (run_id, agent_id, task_id, mode, tool, outcome, json.dumps(checks), now()))
    return {"id": run_id, "outcome": outcome, "mode": mode, "tool": tool, "policy_class": klass, "checks": checks, "review": {"required": requires_review, "role": "reviewer" if requires_review else None, "status": "reserved_for_reasoning-worker" if requires_review else "not_required"}}


def workspace_roots(agent: dict[str, Any]) -> list[Path]:
    roots = []
    cfg = agent.get("workspace") or {}
    for raw in [cfg.get("root"), *(cfg.get("shared_roots") or [])]:
        if not raw:
            continue
        # Manifests use /workspaces/... and runtime mounts that exact root.
        p = Path(raw).resolve()
        try:
            p.relative_to(WORKSPACES)
        except ValueError:
            raise HTTPException(status_code=500, detail=f"Unsafe workspace root in manifest: {raw}")
        roots.append(p)
    return roots


def resolve_scoped(agent: dict[str, Any], raw: str, must_exist: bool = False) -> Path:
    candidate = Path(raw)
    if not candidate.is_absolute():
        candidate = Path((agent.get("workspace") or {}).get("root", "/workspaces")) / candidate
    # Resolve parent first for create targets without permitting symlink escape.
    if candidate.exists():
        resolved = candidate.resolve()
    else:
        resolved = candidate.parent.resolve() / candidate.name
    if not any(resolved == root or root in resolved.parents for root in workspace_roots(agent)):
        raise HTTPException(status_code=403, detail="Path is outside this agent's permitted workspace roots")
    if must_exist and not resolved.exists():
        raise HTTPException(status_code=404, detail="Path not found")
    return resolved


def checkpoint(task_id: str | None, agent_id: str, path: Path) -> str | None:
    if not path.exists() or not task_id:
        return None
    digest = hashlib.sha256(str(path).encode()).hexdigest()[:12]
    dest = CHECKPOINTS / task_id / f"{digest}-{path.name}"
    dest.parent.mkdir(parents=True, exist_ok=True)
    if path.is_file():
        shutil.copy2(path, dest)
    return str(dest)


def event(task_id: str | None, agent_id: str, tool: str, klass: str, approved: bool, success: bool, detail: str) -> None:
    with db() as conn:
        conn.execute("INSERT INTO tool_events(task_id,agent_id,tool,policy_class,approved,success,detail,created_at) VALUES (?,?,?,?,?,?,?,?)",
                     (task_id, agent_id, tool, klass, int(approved), int(success), detail[:4000], now()))


def validate_url(url: str) -> None:
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise HTTPException(status_code=400, detail="Only http/https URLs are allowed")
    host = parsed.hostname.lower()
    if host in {"localhost", "host.docker.internal"} or host.endswith(".local"):
        raise HTTPException(status_code=403, detail="Local/private destinations are blocked")
    try:
        infos = socket.getaddrinfo(host, parsed.port or (443 if parsed.scheme == "https" else 80), type=socket.SOCK_STREAM)
    except socket.gaierror as exc:
        raise HTTPException(status_code=400, detail=f"DNS resolution failed: {exc}") from exc
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_reserved or ip.is_unspecified:
            raise HTTPException(status_code=403, detail="Private, loopback, link-local, reserved, or metadata destinations are blocked")




def compact_tool_payload(value:Any,max_items:int=20,max_string:int=2500,depth:int=0)->Any:
    if depth>6:return '<depth-limit>'
    if isinstance(value,str):return value if len(value)<=max_string else value[:max_string]+'…<truncated>'
    if isinstance(value,list):
        out=[compact_tool_payload(x,max_items,max_string,depth+1) for x in value[:max_items]]
        if len(value)>max_items:out.append({'_truncated_items':len(value)-max_items})
        return out
    if isinstance(value,dict):
        items=list(value.items()); out={str(k):compact_tool_payload(v,max_items,max_string,depth+1) for k,v in items[:max_items]}
        if len(items)>max_items:out['_truncated_keys']=len(items)-max_items
        return out
    return value

def run_hooks(stage: str, tool: str, args: dict[str, Any]) -> list[str]:
    notes = []
    if stage == "pre" and tool in {"file_patch", "file_create"}:
        text = json.dumps(args)
        if re.search(r"(?i)(api[_-]?key|secret|password|token)\s*[:=]\s*['\"]?[A-Za-z0-9_\-]{16,}", text):
            raise HTTPException(status_code=400, detail="Pre-tool secret scan blocked a likely embedded credential")
        notes.append("secret-pattern-scan:pass")
    if stage == "post" and tool in {"file_patch", "file_create"}:
        p = str(args.get("path", ""))
        if p.endswith((".yaml", ".yml")):
            notes.append("yaml-validation:requested")
    return notes


class TaskCreate(BaseModel):
    agent_id: str = Field(min_length=1, max_length=100)
    objective: str = Field(min_length=1, max_length=10000)


class TaskPlan(BaseModel):
    steps: list[str] = Field(min_length=1, max_length=100)


class TaskPhase(BaseModel):
    phase: str = Field(pattern="^(DISCOVER|PLAN|APPROVE|EXECUTE|VERIFY|COMPLETE)$")
    status: str = Field(default="active", pattern="^(active|blocked|failed|complete)$")
    evidence: list[str] = Field(default_factory=list, max_length=100)


class ToolCall(BaseModel):
    agent_id: str
    task_id: str | None = None
    tool: str
    arguments: dict[str, Any] = Field(default_factory=dict)
    approved: bool = False
    mode: str = Field(default="default", max_length=40)


_supervisor_stop = threading.Event()
_supervisor_threads: list[threading.Thread] = []


def redis_client() -> redis.Redis:
    return redis.Redis(host=REDIS_HOST, port=REDIS_PORT, password=REDIS_PASSWORD or None, decode_responses=True, socket_connect_timeout=3, socket_timeout=5)


def list_agent_manifests() -> dict[str, dict[str, Any]]:
    agents: dict[str, dict[str, Any]] = {}
    if not AGENTS_DIR.exists():
        return agents
    for manifest_path in sorted(AGENTS_DIR.glob("*/agent.yaml")):
        try:
            data = yaml.safe_load(manifest_path.read_text()) or {}
            agent_id = str(data.get("name") or manifest_path.parent.name)
            if agent_id:
                agents[agent_id] = data
        except Exception:
            continue
    return agents


def persistent_cfg(agent: dict[str, Any]) -> dict[str, Any]:
    cfg = agent.get("persistent") or agent.get("background") or {}
    return cfg if isinstance(cfg, dict) else {}


def agent_is_persistent(agent: dict[str, Any]) -> bool:
    cfg = persistent_cfg(agent)
    return bool(cfg.get("enabled", False))


def agent_subscriptions(agent: dict[str, Any]) -> list[str]:
    return [str(x) for x in persistent_cfg(agent).get("subscriptions", []) if str(x).strip()]


def agent_routing_keywords(agent: dict[str, Any]) -> list[str]:
    return [str(x).lower() for x in persistent_cfg(agent).get("routing_keywords", []) if str(x).strip()]


def event_matches(pattern: str, event_type: str) -> bool:
    if pattern == "*":
        return True
    if pattern.endswith(".*"):
        return event_type == pattern[:-2] or event_type.startswith(pattern[:-1])
    return pattern == event_type


def heartbeat_agent(agent_id: str, state: str = "listening", last_event: str | None = None, last_job_id: str | None = None, detail: dict[str, Any] | None = None) -> None:
    ts = now()
    with db() as conn:
        conn.execute("""INSERT INTO agent_status(agent_id,state,node_id,last_heartbeat,last_event,last_job_id,detail_json)
                      VALUES(?,?,?,?,?,?,?)
                      ON CONFLICT(agent_id) DO UPDATE SET state=excluded.state,node_id=excluded.node_id,last_heartbeat=excluded.last_heartbeat,
                      last_event=COALESCE(excluded.last_event,agent_status.last_event),last_job_id=COALESCE(excluded.last_job_id,agent_status.last_job_id),detail_json=excluded.detail_json""",
                     (agent_id,state,AGENT_NODE_ID,ts,last_event,last_job_id,json.dumps(detail or {})))


def enqueue_agent_job(agent_id: str, trigger_type: str, trigger_id: str, event_type: str | None, payload: dict[str, Any], priority: int = 50) -> str | None:
    job_id = str(uuid.uuid4())
    ts = now()
    with db() as conn:
        if trigger_type == "schedule":
            task_name = str(payload.get("task") or "")
            key_prefix = trigger_id.rsplit(":", 1)[0] if ":" in trigger_id else trigger_id
            active = conn.execute("SELECT id FROM agent_jobs WHERE agent_id=? AND trigger_type='schedule' AND trigger_id LIKE ? AND status IN ('queued','running','waiting') LIMIT 1", (agent_id, key_prefix + ":%" )).fetchone()
            if active:
                return None
        try:
            conn.execute("INSERT INTO agent_jobs(id,agent_id,trigger_type,trigger_id,event_type,payload_json,status,priority,node_id,attempts,result_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?, ?,?)",
                         (job_id,agent_id,trigger_type,trigger_id,event_type,json.dumps(payload),"queued",priority,AGENT_NODE_ID,0,"{}",ts,ts))
        except sqlite3.IntegrityError:
            return None
    heartbeat_agent(agent_id, "queued", event_type, job_id)
    return job_id


def publish_event(event_type: str, payload: dict[str, Any], source: str = "agent-runtime", user_id: str | None = None, correlation_id: str | None = None) -> str:
    evt = {
        "event_type": event_type,
        "source": source,
        "node_id": AGENT_NODE_ID,
        "user_id": user_id or "",
        "correlation_id": correlation_id or str(uuid.uuid4()),
        "payload": json.dumps(payload, separators=(",", ":")),
        "created_at": now(),
    }
    try:
        return str(redis_client().xadd(AGENT_EVENT_STREAM, evt, maxlen=AGENT_EVENT_MAXLEN, approximate=True))
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Agent event bus unavailable: {exc}") from exc


def _ensure_consumer_group(r: redis.Redis) -> None:
    try:
        r.xgroup_create(AGENT_EVENT_STREAM, AGENT_CONSUMER_GROUP, id="0-0", mkstream=True)
    except redis.ResponseError as exc:
        if "BUSYGROUP" not in str(exc):
            raise


def _event_loop() -> None:
    consumer = f"{AGENT_NODE_ID}-{os.getpid()}"
    while not _supervisor_stop.is_set():
        try:
            r = redis_client(); _ensure_consumer_group(r)
            batches = r.xreadgroup(AGENT_CONSUMER_GROUP, consumer, {AGENT_EVENT_STREAM: ">"}, count=50, block=2000)
            if not batches:
                continue
            agents = list_agent_manifests()
            for _, entries in batches:
                for event_id, fields in entries:
                    event_type = str(fields.get("event_type") or "unknown")
                    try: payload = json.loads(fields.get("payload") or "{}")
                    except Exception: payload = {"raw": fields.get("payload")}
                    envelope = {"event_id":event_id,"event_type":event_type,"source":fields.get("source"),"node_id":fields.get("node_id"),"user_id":fields.get("user_id"),"correlation_id":fields.get("correlation_id"),"created_at":fields.get("created_at"),"payload":payload}
                    text_probe = str((payload or {}).get("text") or "").lower()
                    for agent_id, manifest in agents.items():
                        if not agent_is_persistent(manifest):
                            continue
                        subscribed = any(event_matches(p,event_type) for p in agent_subscriptions(manifest))
                        keyword_routed = event_type == "user.message" and text_probe and any(k in text_probe for k in agent_routing_keywords(manifest))
                        if subscribed or keyword_routed:
                            routed = dict(envelope); routed["routing"] = "subscription" if subscribed else "keyword"
                            enqueue_agent_job(agent_id,"event",event_id,event_type,routed,int(persistent_cfg(manifest).get("priority",50)))
                    r.xack(AGENT_EVENT_STREAM, AGENT_CONSUMER_GROUP, event_id)
        except Exception:
            time.sleep(2)


def _heartbeat_loop() -> None:
    while not _supervisor_stop.is_set():
        agents = list_agent_manifests()
        for agent_id, manifest in agents.items():
            if agent_is_persistent(manifest):
                with db() as conn:
                    q = conn.execute("SELECT COUNT(*) AS n FROM agent_jobs WHERE agent_id=? AND status IN ('queued','running','waiting')",(agent_id,)).fetchone()["n"]
                heartbeat_agent(agent_id,"queued" if q else "listening",detail={"queued":q,"subscriptions":agent_subscriptions(manifest)})
        _supervisor_stop.wait(max(5,AGENT_HEARTBEAT_SECONDS))


def _parse_interval(value: Any) -> int | None:
    if isinstance(value,(int,float)): return max(1,int(value))
    raw=str(value or "").strip().lower()
    m=re.fullmatch(r"(\d+)\s*(s|m|h|d)?",raw)
    if not m: return None
    n=int(m.group(1)); unit=m.group(2) or "s"
    return n*{"s":1,"m":60,"h":3600,"d":86400}[unit]


def _scheduler_loop() -> None:
    last: dict[str,float] = {}
    while not _supervisor_stop.is_set():
        ts=time.time()
        for agent_id, manifest in list_agent_manifests().items():
            if not agent_is_persistent(manifest): continue
            schedules=persistent_cfg(manifest).get("periodic",[]) or []
            for idx,item in enumerate(schedules):
                if not isinstance(item,dict): continue
                interval=_parse_interval(item.get("every"))
                if not interval: continue
                key=f"{agent_id}:{idx}:{item.get('task','periodic')}"
                if ts-last.get(key,0) < interval: continue
                bucket=str(int(ts//interval))
                trigger_id=f"{key}:{bucket}"
                job=enqueue_agent_job(agent_id,"schedule",trigger_id,str(item.get("event","agent.periodic")),{"task":item.get("task","periodic"),"scheduled_every":item.get("every"),"node_id":AGENT_NODE_ID},int(item.get("priority",persistent_cfg(manifest).get("priority",50))))
                if job: last[key]=ts
        _supervisor_stop.wait(max(5,AGENT_SCHEDULER_SECONDS))


def _recent_user_id() -> str | None:
    with db() as conn:
        rows=conn.execute("SELECT payload_json FROM agent_jobs WHERE event_type='user.message' ORDER BY created_at DESC LIMIT 25").fetchall()
    for row in rows:
        try:
            payload=json.loads(row["payload_json"] or "{}")
            uid=str(payload.get("user_id") or "").strip()
            if uid:return uid
        except Exception:
            continue
    return None


def _service_get(url: str, key: str = "", params: dict[str,Any] | None = None) -> dict[str,Any]:
    headers={"Authorization":f"Bearer {key}"} if key else {}
    with httpx.Client(timeout=10) as client:
        r=client.get(url,headers=headers,params=params); r.raise_for_status(); return compact_tool_payload(r.json())

def _service_post(url: str, key: str = "", params: dict[str,Any] | None = None, payload: dict[str,Any] | None = None) -> dict[str,Any]:
    headers={"Authorization":f"Bearer {key}"} if key else {}
    with httpx.Client(timeout=15) as client:
        r=client.post(url,headers=headers,params=params,json=payload); r.raise_for_status(); return compact_tool_payload(r.json())


def _index_session_message(envelope: dict[str,Any]) -> None:
    if str(envelope.get("event_type") or "") != "user.message":
        return
    payload=envelope.get("payload") or {}; text=str(payload.get("text") or "").strip()
    if not text:return
    sid=str(payload.get("message_id") or envelope.get("correlation_id") or uuid.uuid4())
    with db() as conn:
        conn.execute("INSERT OR IGNORE INTO session_messages(id,user_id,chat_id,message_id,model,input_type,text,created_at) VALUES(?,?,?,?,?,?,?,?)",(sid,envelope.get("user_id"),payload.get("chat_id"),payload.get("message_id"),payload.get("model"),payload.get("input_type"),text,envelope.get("created_at") or now()))


def _static_skills() -> dict[str,Any]:
    if not SKILLS_FILE.exists():return {}
    data=yaml.safe_load(SKILLS_FILE.read_text()) or {}
    return data.get("skills",{}) if isinstance(data,dict) else {}


def _learned_skills() -> dict[str,Any]:
    with db() as conn: rows=conn.execute("SELECT * FROM learned_skills WHERE status='active' ORDER BY name").fetchall()
    out={}
    for r in rows:
        out[r["name"]]={"source":"learned","version":r["version"],"agents":[r["agent_id"]],"description":r["description"],"procedure":json.loads(r["procedure_json"] or "{}"),"required_tools":json.loads(r["required_tools_json"] or "[]"),"approval":"PROMOTED","created_at":r["created_at"],"updated_at":r["updated_at"]}
    return out


def _skill_catalog() -> dict[str,Any]:
    out={name:{**cfg,"source":"static"} for name,cfg in _static_skills().items() if isinstance(cfg,dict)}
    out.update(_learned_skills()); return out


def _skill_score(name:str,cfg:dict[str,Any],text:str,agent_id:str|None=None) -> int:
    agents=cfg.get("agents") or []
    if agent_id and agents and agent_id not in agents:return 0
    lowered=text.lower(); hay=" ".join([name,str(cfg.get("description") or "")," ".join(str(x) for x in cfg.get("checks",[]) or [])," ".join(str(x) for x in cfg.get("required_tools",[]) or [])]).lower()
    words={w for w in re.findall(r"[a-z0-9_-]{3,}",lowered)}
    score=sum(2 if w in name.lower() else 1 for w in words if w in hay)
    reminder_intent=bool(re.search(r"\b(remind|reminder|schedule|snooze|due|appointment)\b",lowered))
    schedule_skill=("schedule" in name.lower() or "reminder" in name.lower() or "schedule_write" in hay or "schedule_read" in hay)
    if reminder_intent and schedule_skill:score+=20
    if reminder_intent and "reflection" in name.lower():score=max(0,score-5)
    return score


def _match_skills(text:str,agent_id:str|None=None,limit:int=5) -> list[dict[str,Any]]:
    scored=[]
    for name,cfg in _skill_catalog().items():
        score=_skill_score(name,cfg,text,agent_id)
        if score:scored.append((score,name,cfg))
    scored.sort(key=lambda x:(-x[0],x[1]))
    return [{"name":name,"score":score,"source":cfg.get("source","static"),"description":cfg.get("description"),"required_tools":cfg.get("required_tools",[]),"approval":cfg.get("approval"),"procedure":cfg.get("procedure")} for score,name,cfg in scored[:max(1,min(limit,20))]]


def _observe_successful_job(job:dict[str,Any],result:dict[str,Any]) -> None:
    payload=job.get("payload") or {}; task=str(payload.get("task") or "").strip()
    if not task or task in {"review_agent_queue"}:return
    if result.get("disposition") in {"no_handler","event_ingested"}:return
    signature=f"{job['agent_id']}:{task}"; ts=now()
    with db() as conn:
        row=conn.execute("SELECT * FROM skill_observations WHERE signature=?",(signature,)).fetchone()
        if row:
            count=int(row["success_count"] or 0)+1
            conn.execute("UPDATE skill_observations SET success_count=?,last_job_id=?,last_result_json=?,last_seen_at=? WHERE signature=?",(count,job["id"],json.dumps(compact_tool_payload(result)),ts,signature))
        else:
            count=1; conn.execute("INSERT INTO skill_observations(signature,agent_id,task_name,success_count,failure_count,last_job_id,last_result_json,first_seen_at,last_seen_at) VALUES(?,?,?,?,?,?,?,?,?)",(signature,job["agent_id"],task,1,0,job["id"],json.dumps(compact_tool_payload(result)),ts,ts))
        if count >= AGENT_LEARNING_MIN_SUCCESSES:
            existing=conn.execute("SELECT id FROM skill_candidates WHERE signature=?",(signature,)).fetchone()
            if not existing:
                cid=str(uuid.uuid4()); name=f"learned-{job['agent_id']}-{task}".replace("_","-")[:120]
                proc={"kind":"observed_job","task":task,"agent_id":job["agent_id"],"execution":"reuse existing deterministic handler; do not bypass tool policy","evidence_job_id":job["id"]}
                conn.execute("INSERT INTO skill_candidates(id,signature,agent_id,name,description,procedure_json,required_tools_json,status,evidence_count,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(cid,signature,job["agent_id"],name,f"Candidate procedure learned from repeated successful {task} jobs.",json.dumps(proc),json.dumps([]),"candidate",count,ts,ts))
            else:
                conn.execute("UPDATE skill_candidates SET evidence_count=?,updated_at=? WHERE signature=?",(count,ts,signature))


def _record_skill_failure(job:dict[str,Any]) -> None:
    task=str((job.get("payload") or {}).get("task") or "").strip()
    if not task:return
    sig=f"{job['agent_id']}:{task}"; ts=now()
    with db() as conn:
        row=conn.execute("SELECT signature FROM skill_observations WHERE signature=?",(sig,)).fetchone()
        if row:conn.execute("UPDATE skill_observations SET failure_count=failure_count+1,last_seen_at=? WHERE signature=?",(ts,sig))


def _observe_reasoning_action(agent_id:str,tool:str,arguments:dict[str,Any],job_id:str,result:dict[str,Any]) -> None:
    signature=f"{agent_id}:reasoning:{tool}";ts=now(); task=f"reasoning_{tool}"
    with db() as conn:
        row=conn.execute("SELECT * FROM skill_observations WHERE signature=?",(signature,)).fetchone()
        if row:
            count=int(row["success_count"] or 0)+1
            conn.execute("UPDATE skill_observations SET success_count=?,last_job_id=?,last_result_json=?,last_seen_at=? WHERE signature=?",(count,job_id,json.dumps(compact_tool_payload(result)),ts,signature))
        else:
            count=1;conn.execute("INSERT INTO skill_observations(signature,agent_id,task_name,success_count,failure_count,last_job_id,last_result_json,first_seen_at,last_seen_at) VALUES(?,?,?,?,?,?,?,?,?)",(signature,agent_id,task,1,0,job_id,json.dumps(compact_tool_payload(result)),ts,ts))
        if count>=AGENT_LEARNING_MIN_SUCCESSES and not conn.execute("SELECT id FROM skill_candidates WHERE signature=?",(signature,)).fetchone():
            cid=str(uuid.uuid4());name=f"learned-{agent_id}-{tool}".replace("_","-")[:120]
            proc={"kind":"observed_reasoning_action","tool":tool,"agent_id":agent_id,"argument_keys":sorted(str(k) for k in arguments.keys()),"execution":"re-propose through bounded reasoning; tool policy, review, approval, and verification remain mandatory","evidence_job_id":job_id}
            conn.execute("INSERT INTO skill_candidates(id,signature,agent_id,name,description,procedure_json,required_tools_json,status,evidence_count,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(cid,signature,agent_id,name,f"Candidate procedure learned from repeated verified {tool} actions.",json.dumps(proc),json.dumps([tool]),"candidate",count,ts,ts))
        elif count>=AGENT_LEARNING_MIN_SUCCESSES:
            conn.execute("UPDATE skill_candidates SET evidence_count=?,updated_at=? WHERE signature=?",(count,ts,signature))


def _recover_expired_leases() -> int:
    ts=now(); recovered=0
    with db() as conn:
        rows=conn.execute("SELECT id,attempts FROM agent_jobs WHERE status='running' AND lease_expires_at IS NOT NULL AND lease_expires_at < ?",(ts,)).fetchall()
        for row in rows:
            if int(row["attempts"] or 0) >= AGENT_JOB_MAX_ATTEMPTS:
                conn.execute("UPDATE agent_jobs SET status='failed',error_text=?,lease_owner=NULL,lease_expires_at=NULL,updated_at=? WHERE id=?",("lease expired after maximum attempts",ts,row["id"]))
            else:
                conn.execute("UPDATE agent_jobs SET status='queued',lease_owner=NULL,lease_expires_at=NULL,updated_at=? WHERE id=?",(ts,row["id"]))
            recovered+=1
    return recovered


def _claim_job(worker_id: str) -> dict[str,Any] | None:
    lease=(datetime.now(timezone.utc)+timedelta(seconds=AGENT_JOB_LEASE_SECONDS)).isoformat(); ts=now()
    conn=db()
    try:
        conn.execute("BEGIN IMMEDIATE")
        row=conn.execute("SELECT * FROM agent_jobs WHERE status='queued' AND attempts < ? AND (not_before IS NULL OR not_before <= ?) ORDER BY priority ASC, created_at ASC LIMIT 1",(AGENT_JOB_MAX_ATTEMPTS,ts)).fetchone()
        if not row:
            conn.commit(); return None
        changed=conn.execute("UPDATE agent_jobs SET status='running',attempts=attempts+1,lease_owner=?,lease_expires_at=?,not_before=NULL,updated_at=? WHERE id=? AND status='queued'",(worker_id,lease,ts,row["id"])).rowcount
        if not changed:
            conn.rollback(); return None
        out=dict(row); out["status"]="running"; out["attempts"]=int(out.get("attempts") or 0)+1; out["lease_owner"]=worker_id; out["lease_expires_at"]=lease
        try: out["payload"]=json.loads(out.get("payload_json") or "{}")
        except Exception: out["payload"]={}
        conn.commit(); return out
    finally:
        conn.close()


def _finish_job(job: dict[str,Any], status: str, result: dict[str,Any] | None = None, error: str | None = None) -> None:
    ts=now(); result=result or {}
    with db() as conn:
        conn.execute("UPDATE agent_jobs SET status=?,result_json=?,error_text=?,lease_owner=NULL,lease_expires_at=NULL,updated_at=? WHERE id=?",(status,json.dumps(compact_tool_payload(result)),(error or None),ts,job["id"]))
        if result:
            conn.execute("INSERT INTO agent_artifacts(id,agent_id,job_id,artifact_type,path,metadata_json,created_at) VALUES(?,?,?,?,?,?,?)",(str(uuid.uuid4()),job["agent_id"],job["id"],"job_result",None,json.dumps(compact_tool_payload(result)),ts))
    if status == "complete":
        _observe_successful_job(job,result)
    elif status == "failed":
        _record_skill_failure(job)
    heartbeat_agent(job["agent_id"],"listening" if status in {"complete","failed","discarded","deferred"} else status,last_event=job.get("event_type"),last_job_id=job["id"],detail={"last_result":compact_tool_payload(result,max_items=8,max_string=600),"error":error})


def _litellm_available_aliases() -> set[str]:
    aliases:set[str]=set()
    try:
        cfg_path=Path(os.environ.get("LITELLM_CONFIG_FILE","/config/litellm-config.yaml"))
        candidates=[cfg_path,Path("/app/config.yaml"),Path("/opt/ai-proxy/litellm-config.yaml")]
        for path in candidates:
            if not path.exists():continue
            data=yaml.safe_load(path.read_text()) or {}
            for item in data.get("model_list",[]) or []:
                name=str((item or {}).get("model_name") or "").strip()
                if name:aliases.add(name)
            if aliases:return aliases
    except Exception:
        pass
    if LITELLM_API_KEY:
        try:
            with httpx.Client(timeout=5) as client:
                r=client.get(f"{LITELLM_URL}/models",headers={"Authorization":f"Bearer {LITELLM_API_KEY}"})
                if r.status_code<400:
                    for item in (r.json() or {}).get("data",[]) or []:
                        name=str((item or {}).get("id") or "").strip()
                        if name:aliases.add(name)
        except Exception:
            pass
    return aliases

def _model_alias_for_role(role: str) -> str | None:
    cfg=model_roles().get(role) or {}
    candidates=[str(cfg.get("preferred_alias") or "").strip(),str(cfg.get("fallback") or "").strip()]
    available=_litellm_available_aliases()
    if available:
        for alias in candidates:
            if alias and alias in available:return alias
        return None
    return next((alias for alias in candidates if alias),None)

def _model_role_validation() -> dict[str,Any]:
    available=sorted(_litellm_available_aliases())
    roles={}
    for role,cfg in model_roles().items():
        preferred=str((cfg or {}).get("preferred_alias") or "").strip() or None
        fallback=str((cfg or {}).get("fallback") or "").strip() or None
        resolved=_model_alias_for_role(role)
        roles[role]={"preferred_alias":preferred,"fallback":fallback,"resolved_alias":resolved,"valid":bool(resolved)}
    invalid=sorted(role for role,item in roles.items() if not item["valid"] and role not in {"embedding","vision"})
    return {"available_aliases":available,"roles":roles,"invalid_required_roles":invalid,"ok":not invalid}


def _agent_system_prompt(agent_id: str) -> str:
    base=AGENTS_DIR/agent_id/"instructions"
    for name in ["system-prompt.txt","README.md"]:
        p=base/name
        if p.exists():
            try:return p.read_text(errors="replace")[:8000]
            except Exception:pass
    manifest=load_agent(agent_id)
    return f"You are the {manifest.get('display_name',agent_id)} agent. Follow the manifest tool policy and current mode restrictions."


def _session_search_internal(query:str,user_id:str|None,chat_id:str|None,limit:int) -> list[dict[str,Any]]:
    if not query.strip():return []
    expression,terms=_session_match_expression(query,False)
    sql="SELECT sm.*,bm25(session_messages_fts) AS fts_rank FROM session_messages_fts JOIN session_messages sm ON sm.rowid=session_messages_fts.rowid WHERE session_messages_fts MATCH ?"
    args:[Any]=[expression]
    if user_id:sql+=" AND sm.user_id=?";args.append(user_id)
    if chat_id:sql+=" AND sm.chat_id=?";args.append(chat_id)
    sql+=" ORDER BY fts_rank ASC,sm.created_at DESC LIMIT ?";args.append(min(max(limit*4,10),200))
    try:
        with db() as conn:rows=[dict(r) for r in conn.execute(sql,args).fetchall()]
    except sqlite3.OperationalError:
        return []
    return _rank_session_rows(rows,terms,limit)


def _action_intent(text:str) -> bool:
    lowered=text.casefold()
    patterns=[r"\bremind\b",r"\bremember to\b",r"\bschedule\b",r"\badd (?:this|that|it|a|an|the)?\s*(?:to|into)?\b",r"\bcreate\b",r"\bupdate\b",r"\bchange\b",r"\bplan\b",r"\bnote that\b",r"\brecord\b",r"\bset\b",r"\bsnooze\b",r"\bmark .* done\b"]
    return any(re.search(p,lowered) for p in patterns)


def _reasoning_owner(text:str) -> str:
    life_terms={"remind","remember","schedule","calendar","appointment","plan","journal","health","wellness","medication","food","water","sleep","car","home","goal","routine"}
    words=set(re.findall(r"[a-z0-9_-]+",text.casefold()))
    return "life-assistant" if words & life_terms else "orchestrator"


def _memory_text(item:dict[str,Any]) -> str:
    for key in ("memory","text","value"):
        value=item.get(key)
        if isinstance(value,str) and value.strip():return value.strip()
    return ""


def _entity_matches_for_text(user_id:str,text:str) -> list[str]:
    q=text.casefold();matches=[]
    try:
        with db() as conn:
            rows=conn.execute("SELECT entity_id,canonical_name,aliases_json FROM memory_entities WHERE user_id=?",(user_id,)).fetchall()
        for row in rows:
            names=[str(row["canonical_name"]),*json.loads(row["aliases_json"] or "[]")]
            if any(str(name).strip() and str(name).casefold() in q for name in names):matches.append(str(row["entity_id"]))
    except Exception:pass
    return sorted(set(matches))


def _memory_is_current(item:dict[str,Any], at:datetime|None=None) -> bool:
    """Validity is [valid_from, valid_until), normalized to UTC; malformed dates fail closed."""
    if item.get("superseded_by"):return False
    instant=at or datetime.now(timezone.utc)
    if instant.tzinfo is None:instant=instant.replace(tzinfo=timezone.utc)
    instant=instant.astimezone(timezone.utc)
    bounds={}
    for key in ("valid_from","valid_until"):
        raw=item.get(key)
        if raw is None or str(raw).strip()=="":continue
        try:
            value=datetime.fromisoformat(str(raw).strip().replace("Z","+00:00"))
            if value.tzinfo is None:value=value.replace(tzinfo=timezone.utc)
            bounds[key]=value.astimezone(timezone.utc)
        except (TypeError,ValueError,OverflowError):return False
    start=bounds.get("valid_from");end=bounds.get("valid_until")
    if start is not None and end is not None and start>=end:return False
    return (start is None or start<=instant) and (end is None or instant<end)

def _trusted_memory_context(user_id:str,agent_id:str,chat_id:str|None,query:str,limit:int=6) -> list[dict[str,Any]]:
    """Merge Mem0 recall with provenance-aware trusted memory and return only ranked active candidates."""
    terms=set(re.findall(r"[a-z0-9]+",query.casefold())); candidates=[]; seen=set(); ts=datetime.now(timezone.utc)
    # Explicit trusted-memory records are authoritative for provenance/supersession.
    try:
        with db() as conn: rows=[dict(r) for r in conn.execute("SELECT * FROM trusted_memories WHERE user_id=? AND superseded_by IS NULL ORDER BY updated_at DESC LIMIT 500",(user_id,)).fetchall()]
        for item in rows:
            if not _memory_is_current(item,ts):
                seen.add(_memory_text(item).casefold())
                continue
            text=_memory_text(item)
            if not text:continue
            words=set(re.findall(r"[a-z0-9]+",text.casefold())); lexical=len(terms&words)/max(1,len(terms))
            entity_ids=json.loads(item.get("entity_ids_json") or "[]")
            entity_overlap=1.0 if set(entity_ids)&set(_entity_matches_for_text(user_id,query)) else 0.0
            score=.35*lexical+.25*float(item.get("trust") or 0)+.15*float(item.get("confidence") or 0)+.15*float(item.get("importance") or 0)+.10*entity_overlap
            key=text.casefold(); seen.add(key)
            candidates.append({"id":item.get("id"),"memory":text,"source_type":item.get("source_type"),"source_id":item.get("source_id"),"trust":round(float(item.get("trust") or 0),3),"confidence":round(float(item.get("confidence") or 0),3),"importance":round(float(item.get("importance") or 0),3),"entity_ids":entity_ids,"score":round(score,4),"provenance":"trusted_memory_store"})
    except Exception:pass
    # Mem0 remains useful recall, but enters reasoning only after explicit scoring and provenance labeling.
    if MEM0_API_KEY:
        try:
            with httpx.Client(timeout=8) as client:
                r=client.post(f"{MEM0_URL}/search",headers={"Authorization":f"Bearer {MEM0_API_KEY}"},json={"user_id":user_id,"agent_id":agent_id,"session_id":chat_id,"query":query,"limit":min(max(limit*2,8),20),"include_legacy":False})
            if r.status_code < 400:
                for item in (r.json() or {}).get("memories",[]):
                    if not isinstance(item,dict):continue
                    text=_memory_text(item); key=text.casefold()
                    if not text or key in seen:continue
                    words=set(re.findall(r"[a-z0-9]+",text.casefold())); lexical=len(terms&words)/max(1,len(terms))
                    recall=str(item.get("recall_source") or "semantic")
                    confidence=float(item.get("confidence") or (0.85 if recall=="symbolic" else 0.65))
                    importance=float(item.get("importance") or 0.5)
                    # Mem0 extraction is useful but is not equivalent to a direct verified user statement.
                    trust=0.75 if recall=="symbolic" else 0.60
                    entity_ids=_entity_matches_for_text(user_id,text)
                    entity_overlap=1.0 if set(entity_ids)&set(_entity_matches_for_text(user_id,query)) else 0.0
                    score=.45*lexical+.20*trust+.15*confidence+.10*importance+.10*entity_overlap
                    candidates.append({"id":item.get("id"),"memory":text,"source_type":"mem0_symbolic" if recall=="symbolic" else "mem0_semantic","source_id":item.get("id"),"trust":round(trust,3),"confidence":round(confidence,3),"importance":round(importance,3),"entity_ids":entity_ids,"score":round(score,4),"provenance":f"mem0_{recall}"})
        except Exception:pass
    candidates=[x for x in candidates if x["trust"]>=0.35 and x["score"]>=0.18]
    candidates.sort(key=lambda x:(x["score"],x["trust"],x["confidence"],x["importance"]),reverse=True)
    return compact_tool_payload(candidates[:max(1,min(limit,10))],max_items=10,max_string=1200)


def _tool_health_allowed(tool:str,current_state:dict[str,Any]) -> bool:
    source_health=current_state.get("source_health") if isinstance(current_state,dict) else {}
    source_health=source_health if isinstance(source_health,dict) else {}
    prefixes={"calendar_":"calendar","environment_":"environment","home_":"environment","schedule_":"reminders","planning_":"plan","life_profile_":"profile","proactive_":"proactive","timeline_":"timeline"}
    for prefix,source in prefixes.items():
        if tool.startswith(prefix) and source in source_health and source_health.get(source) is False:return False
    env=current_state.get("environment") if isinstance(current_state,dict) else None
    if isinstance(env,dict):
        if tool.startswith("home_") and isinstance(env.get("home"),dict) and env["home"].get("configured") is False:return False
        if tool.startswith("environment_") and isinstance(env.get("weather"),dict) and env["weather"].get("configured") is False:return False
    return True


def _compile_tool_surface(agent_id:str,mode:str,task_text:str,matched_skills:list[dict[str,Any]],current_state:dict[str,Any],max_tools:int=6,healthy_tools:list[str]|None=None) -> dict[str,Any]:
    """Mandatory least-privilege tool surface: manifest ∩ mode ∩ intent ∩ health, capped for local models."""
    manifest=load_agent(agent_id); words=set(re.findall(r"[a-z0-9_-]+",task_text.casefold())); required=set()
    for skill in matched_skills:
        required.update(str(t) for t in (skill.get("required_tools") or []))
    intent_groups=[
        ({"remind","reminder","schedule","snooze","due"},{"schedule_read","schedule_write"}),
        ({"plan","planning","priority","task"},{"planning_read","planning_write"}),
        ({"calendar","meeting","appointment","event"},{"calendar_read","calendar_write"}),
        ({"journal","record","note","log"},{"journal_ingest","life_profile_read","life_profile_write","timeline_write"}),
        ({"notify","notification","alert"},{"notification_read","notification_write"}),
        ({"home","light","lights","thermostat","sensor","room"},{"home_state_read","home_action","environment_read"}),
        ({"email","mail","reply","send"},{"email_send"}),
        ({"file","code","script","config","configuration"},{"file_read","file_search","file_find","file_patch","file_create"}),
        ({"web","internet","website","online","search"},{"web_fetch"}),
        ({"memory","remember","preference","previous"},{"memory_search"}),
    ]
    intent_tools=set()
    for triggers,tools in intent_groups:
        if words & triggers:intent_tools.update(tools)
    healthy=set(healthy_tools or []); candidates=[]
    for tool in (manifest.get("tools") or {}):
        klass=effective_tool_class(manifest,tool,mode)
        if klass=="DENY" or (healthy and tool not in healthy) or not _tool_health_allowed(tool,current_state):continue
        hints=set(re.findall(r"[a-z0-9]+",tool.replace("_"," ").casefold()))
        score=3*len(words&hints)
        reasons=[]
        if tool in required:score+=12;reasons.append("matched_skill")
        if tool in intent_tools:score+=8;reasons.append("task_intent")
        if tool in {"current_state_read","memory_search"}:score+=1;reasons.append("bounded_context")
        if score>0:candidates.append((score,tool,klass,reasons))
    candidates.sort(key=lambda x:(x[0],x[1]),reverse=True)
    cap=max(1,min(max_tools,6)); selected=candidates[:cap]
    if not selected:
        for fallback in ("current_state_read","memory_search"):
            if fallback in (manifest.get("tools") or {}) and effective_tool_class(manifest,fallback,mode)!="DENY" and _tool_health_allowed(fallback,current_state):
                selected.append((1,fallback,effective_tool_class(manifest,fallback,mode),["safe_fallback"]))
                if len(selected)>=2:break
    items=[{"tool":tool,"policy_class":klass,"score":score,"reasons":reasons} for score,tool,klass,reasons in selected]
    return {"agent_id":agent_id,"mode":mode,"tools":items,"max_tools":cap,"policy":"manifest_intersect_mode_intent_health"}


def _reasoning_context(agent_id:str,envelope:dict[str,Any],text:str) -> dict[str,Any]:
    uid=str(envelope.get("user_id") or "").strip() or None
    chat_id=str((envelope.get("payload") or {}).get("chat_id") or "").strip() or None
    state={}
    if uid and CURRENT_STATE_API_KEY:
        try:state=_service_get(f"{CURRENT_STATE_URL}/context-pack/{uid}",CURRENT_STATE_API_KEY,{"max_chars":AGENT_REASONING_CONTEXT_CHARS})
        except Exception as exc:state={"status":"unavailable","error":type(exc).__name__}
    history=_session_search_internal(text,uid,chat_id,AGENT_REASONING_HISTORY_LIMIT)
    memories=_trusted_memory_context(uid,agent_id,chat_id,text,min(6,AGENT_REASONING_HISTORY_LIMIT)) if uid else []
    skills=[skill for skill in _match_skills(text,agent_id,5) if int(skill.get("score") or 0) >= 2]
    manifest=load_agent(agent_id); mode=str((manifest.get("execution") or {}).get("default_mode") or "default")
    if _action_intent(text) and mode == "default":mode="operate"
    surface=_compile_tool_surface(agent_id,mode,text,skills,state,6)
    allowed={item["tool"]:item["policy_class"] for item in surface["tools"]}
    return {"user_id":uid,"chat_id":chat_id,"current_state":compact_tool_payload(state,max_string=3500),"durable_memories":memories,"memory_policy":{"trusted_ranking":True,"supersession_filter":True,"entity_aware":True,"min_trust":0.35},"session_history":compact_tool_payload(history,max_items=AGENT_REASONING_HISTORY_LIMIT,max_string=1200),"matched_skills":skills,"mode":mode,"allowed_tools":allowed,"tool_surface":surface}


def _call_litellm(role:str,messages:list[dict[str,str]],temperature:float=0.1,max_tokens:int=1200) -> tuple[str,dict[str,Any]]:
    if not LITELLM_API_KEY:raise RuntimeError("LiteLLM reasoning integration is not configured")
    alias=_model_alias_for_role(role)
    if not alias:raise RuntimeError(f"No model alias configured for role {role}")
    if role == "reasoning-local": max_tokens=max(max_tokens,AGENT_REASONING_MAX_TOKENS)
    payload={"model":alias,"messages":messages,"temperature":temperature,"max_tokens":max_tokens,"response_format":{"type":"json_object"}}
    headers={"Authorization":f"Bearer {LITELLM_API_KEY}","Content-Type":"application/json"}
    with httpx.Client(timeout=AGENT_REASONING_TIMEOUT_SECONDS) as client:
        r=client.post(f"{LITELLM_URL}/chat/completions",headers=headers,json=payload)
        if r.status_code in {400,404,422}:
            payload.pop("response_format",None)
            r=client.post(f"{LITELLM_URL}/chat/completions",headers=headers,json=payload)
        r.raise_for_status(); data=r.json()
    choice=(data.get("choices") or [{}])[0]
    if choice.get("finish_reason")=="length":
        raise RuntimeError(f"Reasoning model exhausted output budget ({max_tokens} tokens); no answer accepted")
    content=str(((choice.get("message") or {}).get("content") or "")).strip()
    if not content:raise RuntimeError("Reasoning model returned an empty response")
    if content.startswith("```"):
        content=re.sub(r"^```(?:json)?\s*|\s*```$","",content,flags=re.I|re.S).strip()
    try: parsed=json.loads(content)
    except json.JSONDecodeError as exc:raise RuntimeError("Reasoning model did not return valid JSON") from exc
    if not isinstance(parsed,dict):raise RuntimeError("Reasoning model JSON response must be an object")
    return alias,parsed

def _model_failure_detail(exc: Exception) -> str:
    if isinstance(exc,httpx.TimeoutException):return "Model request timed out"
    if isinstance(exc,httpx.HTTPStatusError):return f"Model HTTP error {exc.response.status_code}"
    if isinstance(exc,RuntimeError):
        detail=str(exc)[:400]
        if LITELLM_API_KEY:detail=detail.replace(LITELLM_API_KEY,"[redacted]")
        return detail
    return type(exc).__name__


def _resource_snapshot() -> dict[str,Any]:
    try:
        data=json.loads(RESOURCE_GUARDIAN_STATUS_FILE.read_text())
        stamp=str(data.get("timestamp") or "")
        age=None
        if stamp:
            try: age=max(0.0,(datetime.now(timezone.utc)-datetime.fromisoformat(stamp.replace("Z","+00:00"))).total_seconds())
            except Exception: age=None
        gpus=(data.get("gpu") or {}).get("gpus") or []
        total=sum(float(g.get("memory_total_mib") or 0) for g in gpus)
        used=sum(float(g.get("memory_used_mib") or 0) for g in gpus)
        free=max(0.0,total-used)
        util=max([float(g.get("util_percent") or 0) for g in gpus] or [0.0])
        loaded=[]
        for item in ((data.get("ollama") or {}).get("models") or []):
            name=str(item.get("name") or item.get("model") or "")
            if name: loaded.append(name)
        return {"available":bool(gpus),"fresh":age is not None and age<=AGENT_RESOURCE_STALE_SECONDS,"age_seconds":round(age,1) if age is not None else None,"total_vram_mb":round(total),"used_vram_mb":round(used),"available_vram_mb":round(free),"gpu_util_percent":round(util,1),"gpu_busy":util>=AGENT_GPU_BUSY_UTIL_PERCENT,"loaded_models":loaded,"source":str(RESOURCE_GUARDIAN_STATUS_FILE)}
    except Exception as exc:
        return {"available":False,"fresh":False,"error":type(exc).__name__,"source":str(RESOURCE_GUARDIAN_STATUS_FILE)}


def _role_estimated_vram_mb(role:str) -> int:
    try:return max(0,int(AGENT_MODEL_VRAM_ESTIMATES.get(role,0)))
    except Exception:return 0


def _ollama_model_for_role(role:str) -> str | None:
    alias=_model_alias_for_role(role)
    if not alias:return None
    try:
        candidates=[Path(os.environ.get("LITELLM_CONFIG_FILE","/config/litellm-config.yaml")),Path("/app/config.yaml"),Path("/opt/ai-proxy/litellm-config.yaml")]
        for path in candidates:
            if not path.exists():continue
            data=yaml.safe_load(path.read_text()) or {}
            for item in data.get("model_list",[]) or []:
                if str((item or {}).get("model_name") or "").strip()!=alias:continue
                raw=str(((item or {}).get("litellm_params") or {}).get("model") or "").strip()
                if raw:
                    return raw.split("/",1)[1] if "/" in raw else raw
    except Exception:pass
    return None


def _record_resource_admission(role:str,decision:str,detail:dict[str,Any]) -> str:
    rid=str(uuid.uuid4())
    with db() as conn: conn.execute("INSERT INTO resource_admissions(id,model_role,decision,detail_json,created_at) VALUES(?,?,?,?,?)",(rid,role,decision,json.dumps(compact_tool_payload(detail)),now()))
    return rid


def _admit_model_role(role:str,priority:int=50,requested_parallel:int=1) -> dict[str,Any]:
    snap=_resource_snapshot(); estimate=_role_estimated_vram_mb(role); requested=max(1,min(int(requested_parallel or 1),8))
    # Resource Guardian is advisory when unavailable/stale: preserve service availability but force serial execution.
    if not snap.get("available") or not snap.get("fresh"):
        detail={"decision":"ADMIT","reason":"telemetry_unavailable_or_stale","model_role":role,"estimated_vram_mb":estimate,"requested_parallel":requested,"admitted_parallel":1,"telemetry":snap}
        detail["id"]=_record_resource_admission(role,"ADMIT",detail);return detail
    available=max(0,int(snap.get("available_vram_mb") or 0)-AGENT_RESOURCE_HEADROOM_MB)
    loaded_alias=_model_alias_for_role(role); ollama_model=_ollama_model_for_role(role); resident=bool(ollama_model and any(ollama_model.casefold() in x.casefold() for x in snap.get("loaded_models",[])))
    incremental=512 if resident else estimate
    if incremental and available < incremental:
        decision="WAITING_RESOURCE";reason="insufficient_vram"
    elif snap.get("gpu_busy") and priority>30:
        decision="WAITING_RESOURCE";reason="gpu_busy"
    else:
        decision="ADMIT";reason="capacity_available"
    safe_parallel=1
    if decision=="ADMIT" and incremental>0:
        safe_parallel=max(1,min(requested,available//max(1,incremental)))
    detail={"decision":decision,"reason":reason,"model_role":role,"model_alias":loaded_alias,"ollama_model":ollama_model,"estimated_vram_mb":estimate,"incremental_vram_mb":incremental,"headroom_mb":AGENT_RESOURCE_HEADROOM_MB,"available_after_headroom_mb":available,"resident":resident,"requested_parallel":requested,"admitted_parallel":int(safe_parallel),"priority":priority,"telemetry":snap}
    detail["id"]=_record_resource_admission(role,decision,detail);return detail


def _requeue_for_resource(job:dict[str,Any],admission:dict[str,Any]) -> dict[str,Any]:
    waits=int(job.get("resource_waits") or 0)+1
    if waits>AGENT_RESOURCE_MAX_WAITS:
        return {"requeued":False,"decision":"DEFERRED","resource_waits":waits,"admission":admission}
    delay=min(300,AGENT_RESOURCE_WAIT_SECONDS*max(1,min(waits,10)))
    nb=(datetime.now(timezone.utc)+timedelta(seconds=delay)).isoformat()
    with db() as conn:
        conn.execute("UPDATE agent_jobs SET status='queued',attempts=CASE WHEN attempts>0 THEN attempts-1 ELSE 0 END,resource_waits=?,not_before=?,lease_owner=NULL,lease_expires_at=NULL,error_text=?,updated_at=? WHERE id=?",(waits,nb,"waiting_resource",now(),job["id"]))
    return {"requeued":True,"decision":"WAITING_RESOURCE","resource_waits":waits,"retry_after_seconds":delay,"not_before":nb,"admission":admission}


def _reasoning_proposal(agent_id:str,text:str,ctx:dict[str,Any]) -> tuple[str,dict[str,Any]]:
    system=_agent_system_prompt(agent_id)+"\n\nYou are operating inside a bounded agent harness. You NEVER execute tools yourself. Return JSON only. Propose the minimum necessary actions. Use only tools explicitly listed in allowed_tools. Never set approved=true. If no background action is warranted, return disposition=no_action. If timing is ambiguous, prefer a non-destructive draft/no_action rather than inventing an exact time."
    schema={"disposition":"no_action|propose_actions","summary":"short explanation","actions":[{"tool":"allowed tool name","arguments":{},"reason":"why needed"}],"confidence":0.0}
    user={"request":text,"mode":ctx["mode"],"allowed_tools":ctx["allowed_tools"],"current_state":ctx["current_state"],"durable_memories":ctx.get("durable_memories",[]),"matched_skills":ctx["matched_skills"],"relevant_session_history":ctx["session_history"],"required_output_schema":schema,"max_actions":AGENT_REASONING_MAX_ACTIONS}
    return _call_litellm("reasoning-local",[{"role":"system","content":system},{"role":"user","content":json.dumps(user,ensure_ascii=False)}])


def _review_action(agent_id:str,mode:str,text:str,action:dict[str,Any],guardrail:dict[str,Any]) -> dict[str,Any]:
    if not guardrail.get("review",{}).get("required"):return {"required":False,"approved":True,"reason":"not_required"}
    prompt={"original_request":text,"agent_id":agent_id,"mode":mode,"proposed_action":action,"guardrail_checks":guardrail.get("checks",[]),"instruction":"Return JSON only with approve:boolean and rationale:string. Reject unnecessary, overbroad, unsafe, policy-inconsistent, or insufficiently grounded mutations. Do not approve actions that require explicit user approval."}
    alias,data=_call_litellm("reviewer",[{"role":"system","content":"You are a conservative read-only reviewer. You cannot execute tools. Review the proposed action against the supplied policy evidence."},{"role":"user","content":json.dumps(prompt,ensure_ascii=False)}],0.0,500)
    return {"required":True,"approved":bool(data.get("approve",False)),"rationale":str(data.get("rationale") or ""),"model":alias}


def _verify_reasoning_action(agent_id:str,tool:str,args:dict[str,Any],result:dict[str,Any],mode:str) -> dict[str,Any]:
    if result.get("status") in {"approval_required","blocked","failed"}:return {"verified":False,"method":"tool_status","detail":result.get("status")}
    if tool in {"file_create","file_patch"} and result.get("path"):
        try:
            read=execute(ToolCall(agent_id=agent_id,tool="file_read",arguments={"path":result["path"]},mode="default"))
            return {"verified":bool(read.get("result",{}).get("content") is not None),"method":"read_after_write"}
        except Exception as exc:return {"verified":False,"method":"read_after_write","error":type(exc).__name__}
    if tool == "schedule_write":
        rid=str((result.get("result") or result).get("id") or "")
        if rid:
            try:
                listed=execute(ToolCall(agent_id=agent_id,tool="schedule_read",arguments={"action":"list","user_id":args.get("user_id","default")},mode="default"))
                items=json.dumps(listed,ensure_ascii=False)
                return {"verified":rid in items,"method":"schedule_read_after_write","id":rid}
            except Exception as exc:return {"verified":False,"method":"schedule_read_after_write","error":type(exc).__name__}
    return {"verified":True,"method":"successful_tool_result"}


def _deterministic_reminder(text:str,user_id:str|None) -> dict[str,Any] | None:
    if not user_id or not re.search(r"\bremind(?: me)?\b",text,re.I):return None
    m=re.search(r"\b(tomorrow|today)\b.*?\b(?:at\s+)?(\d{1,2})(?::(\d{2}))?\s*(am|pm)\b",text,re.I)
    if not m:return None
    local_now=datetime.now(ASSISTANT_ZONE); day=m.group(1).lower(); hour=int(m.group(2)); minute=int(m.group(3) or 0); ampm=m.group(4).lower()
    if hour<1 or hour>12 or minute>59:return None
    if ampm=="pm" and hour!=12:hour+=12
    if ampm=="am" and hour==12:hour=0
    due_date=(local_now+timedelta(days=1)).date() if day=="tomorrow" else local_now.date()
    due_local=datetime(due_date.year,due_date.month,due_date.day,hour,minute,tzinfo=ASSISTANT_ZONE)
    if due_local<=local_now:return None
    title=re.sub(r"^.*?\bremind(?: me)?\b", "", text, flags=re.I).strip()
    title=re.sub(r"\b(?:today|tomorrow)\b.*?\b(?:at\s+)?\d{1,2}(?::\d{2})?\s*(?:am|pm)\b(?:\s+to)?\s*", "", title, count=1, flags=re.I).strip(" .")
    if not title:title="Reminder"
    return {"action":"create","user_id":user_id,"title":title[:300],"notes":f"Created from deterministic reminder intent. Local timezone: {LIFE_ASSISTANT_TIMEZONE}.","due_at":due_local.astimezone(timezone.utc).isoformat(),"importance":"routine","source_timezone":LIFE_ASSISTANT_TIMEZONE,"source_local_due_at":due_local.isoformat()}

def _execute_deterministic_reminder(job:dict[str,Any],owner:str,mode:str,text:str,ctx:dict[str,Any]) -> dict[str,Any] | None:
    args=_deterministic_reminder(text,ctx.get("user_id"))
    if not args:return None
    if "schedule_write" not in (ctx.get("allowed_tools") or {}):return {"path":"deterministic_reminder","status":"blocked","reason":"tool_not_in_dynamic_surface"}
    manifest=load_agent(owner); klass=effective_tool_class(manifest,"schedule_write",mode)
    guard=_guardrail_checks(owner,job["id"],mode,"schedule_write",args,False)
    if klass in {"DENY","APPROVAL_REQUIRED"} or guard["outcome"] in {"blocked","approval_required"}:
        return {"path":"deterministic_reminder","status":"blocked" if guard["outcome"]=="blocked" else "approval_required","guardrail":guard}
    result=execute(ToolCall(agent_id=owner,task_id=job["id"],tool="schedule_write",arguments=args,approved=False,mode=mode))
    verification=_verify_reasoning_action(owner,"schedule_write",args,result,mode)
    if verification.get("verified"):_observe_reasoning_action(owner,"schedule_write",args,job["id"],result)
    return {"path":"deterministic_reminder","status":"complete" if verification.get("verified") else "verification_failed","tool":"schedule_write","arguments":compact_tool_payload(args),"result":compact_tool_payload(result),"verification":verification}

def _reason_over_event(job:dict[str,Any],envelope:dict[str,Any],text:str) -> dict[str,Any]:
    correlation=str(envelope.get("correlation_id") or (envelope.get("payload") or {}).get("message_id") or job["id"])
    owner=_reasoning_owner(text)
    if job["agent_id"] != owner:return {"attempted":False,"owner":owner,"reason":"reasoning_not_owner"}
    if not AGENT_REASONING_ENABLED:return {"attempted":False,"owner":owner,"reason":"reasoning_disabled"}
    if not _action_intent(text):return {"attempted":False,"owner":owner,"reason":"no_action_intent"}
    run_id=str(uuid.uuid4());ts=now();ctx=_reasoning_context(owner,envelope,text);mode=ctx["mode"]
    try:
        with db() as conn:conn.execute("INSERT INTO reasoning_runs(id,correlation_id,agent_id,job_id,mode,model_role,status,prompt_context_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)",(run_id,correlation,owner,job["id"],mode,"reasoning-local","running",json.dumps(compact_tool_payload(ctx)),ts,ts))
    except sqlite3.IntegrityError:
        return {"attempted":False,"owner":owner,"reason":"correlation_already_reasoned"}
    try:
        fast=_execute_deterministic_reminder(job,owner,mode,text,ctx)
        if fast is not None:
            final={"proposal":{"disposition":"deterministic_action","summary":"Complete reminder intent handled without LLM reasoning.","actions":[{"tool":"schedule_write","arguments":fast.get("arguments",{})}]},"actions":[fast],"owner":owner,"mode":mode,"model":None,"reasoning_path":"deterministic_reminder"}
            with db() as conn:conn.execute("UPDATE reasoning_runs SET status=?,proposal_json=?,result_json=?,updated_at=? WHERE id=?",("complete" if fast.get("status")=="complete" else fast.get("status","failed"),json.dumps(compact_tool_payload(final["proposal"])),json.dumps(compact_tool_payload(final)),now(),run_id))
            return {"attempted":True,"run_id":run_id,**final,"status":fast.get("status")}
        validation=_model_role_validation()
        if not validation.get("ok"):raise RuntimeError(f"Required model roles unresolved: {', '.join(validation.get('invalid_required_roles',[]))}")
        admission=_admit_model_role("reasoning-local",int(job.get("priority") or 50),1)
        ctx["resource_admission"]=admission
        with db() as conn:conn.execute("UPDATE reasoning_runs SET prompt_context_json=?,updated_at=? WHERE id=?",(json.dumps(compact_tool_payload(ctx)),now(),run_id))
        if admission.get("decision") != "ADMIT":
            wait=_requeue_for_resource(job,admission)
            status="waiting_resource" if wait.get("requeued") else "deferred"
            if wait.get("requeued"):
                # Release the unique correlation owner so the same queued event can resume after capacity returns.
                with db() as conn:conn.execute("DELETE FROM reasoning_runs WHERE id=?",(run_id,))
                return {"attempted":True,"run_id":None,"owner":owner,"mode":mode,"status":status,"resource":wait}
            with db() as conn:conn.execute("UPDATE reasoning_runs SET status='deferred',result_json=?,updated_at=? WHERE id=?",(json.dumps(compact_tool_payload(wait)),now(),run_id))
            return {"attempted":True,"run_id":run_id,"owner":owner,"mode":mode,"status":"deferred","resource":wait}
        alias,proposal=_reasoning_proposal(owner,text,ctx); actions=proposal.get("actions") or []
        if not isinstance(actions,list):actions=[]
        actions=actions[:max(0,AGENT_REASONING_MAX_ACTIONS)]
        with db() as conn:conn.execute("UPDATE reasoning_runs SET model_alias=?,proposal_json=?,updated_at=? WHERE id=?",(alias,json.dumps(compact_tool_payload(proposal)),now(),run_id))
        executed=[]
        for action in actions:
            if not isinstance(action,dict):continue
            tool=str(action.get("tool") or "").strip();arguments=action.get("arguments") or {}
            if not tool or not isinstance(arguments,dict):continue
            if ctx.get("user_id") and tool in {"schedule_read","schedule_write","planning_read","planning_write","life_profile_read","life_profile_write","journal_ingest","current_state_read","notification_read","notification_write","assistance_preferences_read","assistance_preferences_write","explanation_read","explanation_record","timeline_read","timeline_write","calendar_read","calendar_write","briefing_read","proactive_read","proactive_write","rhythm_read"}:
                arguments.setdefault("user_id",ctx["user_id"])
            if tool not in (ctx.get("allowed_tools") or {}):
                aid=str(uuid.uuid4());ats=now();detail={"status":"blocked","reason":"tool_not_in_dynamic_surface","allowed_tools":sorted((ctx.get("allowed_tools") or {}).keys())}
                with db() as conn:conn.execute("INSERT INTO reasoning_actions(id,reasoning_run_id,agent_id,tool,mode,policy_class,status,arguments_json,result_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(aid,run_id,owner,tool,mode,"DENY","blocked",json.dumps(compact_tool_payload(arguments)),json.dumps(compact_tool_payload(detail)),ats,ats))
                executed.append({"tool":tool,**detail});continue
            manifest=load_agent(owner);klass=effective_tool_class(manifest,tool,mode)
            aid=str(uuid.uuid4()); ats=now()
            with db() as conn:conn.execute("INSERT INTO reasoning_actions(id,reasoning_run_id,agent_id,tool,mode,policy_class,status,arguments_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)",(aid,run_id,owner,tool,mode,klass,"proposed",json.dumps(compact_tool_payload(arguments)),ats,ats))
            guard=_guardrail_checks(owner,job["id"],mode,tool,arguments,False)
            if guard["outcome"] in {"blocked","approval_required"} or klass=="APPROVAL_REQUIRED":
                status="approval_required" if guard["outcome"]=="approval_required" or klass=="APPROVAL_REQUIRED" else "blocked"
                detail={"status":status,"guardrail":guard}
                with db() as conn:conn.execute("UPDATE reasoning_actions SET status=?,result_json=?,updated_at=? WHERE id=?",(status,json.dumps(compact_tool_payload(detail)),now(),aid))
                executed.append({"tool":tool,**detail});continue
            review=_review_action(owner,mode,text,action,guard)
            if review.get("required") and not review.get("approved"):
                with db() as conn:conn.execute("UPDATE reasoning_actions SET status='review_rejected',reviewer_json=?,updated_at=? WHERE id=?",(json.dumps(review),now(),aid))
                executed.append({"tool":tool,"status":"review_rejected","review":review});continue
            try:
                tool_result=execute(ToolCall(agent_id=owner,task_id=job["id"],tool=tool,arguments=arguments,approved=False,mode=mode))
                verification=_verify_reasoning_action(owner,tool,arguments,tool_result,mode)
                status="complete" if verification.get("verified") else "verification_failed"
                with db() as conn:conn.execute("UPDATE reasoning_actions SET status=?,result_json=?,verification_json=?,reviewer_json=?,updated_at=? WHERE id=?",(status,json.dumps(compact_tool_payload(tool_result)),json.dumps(verification),json.dumps(review),now(),aid))
                if status=="complete":_observe_reasoning_action(owner,tool,arguments,job["id"],tool_result)
                executed.append({"tool":tool,"status":status,"result":compact_tool_payload(tool_result,max_items=10,max_string=1000),"verification":verification,"review":review})
            except Exception as exc:
                with db() as conn:conn.execute("UPDATE reasoning_actions SET status='failed',error_text=?,reviewer_json=?,updated_at=? WHERE id=?",(f"{type(exc).__name__}: {exc}"[:2000],json.dumps(review),now(),aid))
                executed.append({"tool":tool,"status":"failed","error":type(exc).__name__})
        final={"proposal":compact_tool_payload(proposal),"actions":executed,"owner":owner,"mode":mode,"model":alias}
        with db() as conn:conn.execute("UPDATE reasoning_runs SET status='complete',result_json=?,updated_at=? WHERE id=?",(json.dumps(compact_tool_payload(final)),now(),run_id))
        return {"attempted":True,"run_id":run_id,**final}
    except Exception as exc:
        with db() as conn:conn.execute("UPDATE reasoning_runs SET status='failed',error_text=?,updated_at=? WHERE id=?",(f"{type(exc).__name__}: {exc}"[:2000],now(),run_id))
        return {"attempted":True,"run_id":run_id,"owner":owner,"mode":mode,"status":"failed","error":type(exc).__name__,"detail":str(exc)[:500]}


def _execute_direct_task(job:dict[str,Any]) -> dict[str,Any]:
    """Execute a user-submitted read-only objective with a durable task outcome.

    Action-oriented objectives are held for approval; no tools are dispatched here.
    """
    payload=job.get("payload") or {}
    task_id=str(payload.get("task_id") or "")
    with db() as conn:
        record=conn.execute("SELECT * FROM tasks WHERE id=?",(task_id,)).fetchone()
    if not record:
        return {"disposition":"failed","reason":"task_not_found","task_id":task_id}
    if record["agent_id"]!=job["agent_id"]:
        return {"disposition":"failed","reason":"agent_mismatch","task_id":task_id}
    if record["status"] in {"complete","failed","blocked"}:
        return {"disposition":"already_terminal","task_id":task_id}
    objective=str(record["objective"])
    if (_action_intent(objective) or re.search(r"\b(?:delete|remove|erase|send|publish|install|uninstall|restart|reboot|shutdown)\b",objective,re.I)) and not objective.lower().startswith("synthetic read-only test:"):
        with db() as conn:
            conn.execute("UPDATE tasks SET phase='APPROVE',status='blocked',evidence_json=?,updated_at=? WHERE id=?",(json.dumps(["Action-oriented task requires explicit approval and a governed executor; no tools used."]),now(),task_id))
        return {"disposition":"approval_required","task_id":task_id,"verified":False}
    if not AGENT_REASONING_ENABLED:
        with db() as conn:conn.execute("UPDATE tasks SET status='blocked',updated_at=? WHERE id=?",(now(),task_id))
        return {"disposition":"reasoning_disabled","task_id":task_id,"verified":False}
    with db() as conn:
        conn.execute("UPDATE tasks SET phase='PLAN',plan_json=?,updated_at=? WHERE id=?",(json.dumps(["Generate a read-only answer with the assigned agent and no tool calls","Verify that model output contains a substantive answer"]),now(),task_id))
    system=_agent_system_prompt(record["agent_id"])+"\nReturn a JSON object with one key, answer. Respond to the objective without calling tools, changing any user data or claiming to have done so. If the objective requires tool use, respond that it has not been performed."
    try:
        alias,response=_call_litellm("reasoning-local",[{"role":"system","content":system},{"role":"user","content":objective}],0.1,800)
        answer=str(response.get("answer") or "").strip()
        if len(answer)<12:raise RuntimeError("Model produced no verifiable answer")
        with db() as conn:
            conn.execute("UPDATE tasks SET phase='COMPLETE',status='complete',evidence_json=?,updated_at=? WHERE id=?",(json.dumps(["Verified a non-empty model response; no tools invoked.","Model: "+str(alias),"Answer: "+answer[:6000]]),now(),task_id))
            if payload.get("delegation_id"):
                conn.execute("UPDATE delegations SET status='complete',updated_at=? WHERE id=?",(now(),str(payload["delegation_id"])))
        return {"disposition":"verified_complete","task_id":task_id,"verified":True,"answer":answer[:6000],"model":alias}
    except Exception as exc:
        with db() as conn:
            conn.execute("UPDATE tasks SET status='failed',evidence_json=?,updated_at=? WHERE id=?",(json.dumps(["Model execution failed: "+_model_failure_detail(exc)]),now(),task_id))
            if payload.get("delegation_id"):
                conn.execute("UPDATE delegations SET status='failed',updated_at=? WHERE id=?",(now(),str(payload["delegation_id"])))
        return {"disposition":"failed","task_id":task_id,"verified":False,"error":_model_failure_detail(exc)}


def _execute_agent_job(job: dict[str,Any]) -> dict[str,Any]:
    payload=job.get("payload") or {}; task=str(payload.get("task") or "")
    if job.get("trigger_type") in {"direct_task","delegated_task"}:return _execute_direct_task(job)
    if job.get("trigger_type") == "event":
        envelope=payload; event_type=str(job.get("event_type") or envelope.get("event_type") or "")
        _index_session_message(envelope)
        text=str((envelope.get("payload") or {}).get("text") or "")
        matched=_match_skills(text,job.get("agent_id"),5) if text else []
        reasoning=_reason_over_event(job,envelope,text) if event_type=="user.message" and text else {"attempted":False,"reason":"non_user_event"}
        rstatus=str(reasoning.get("status") or "")
        disposition="completed_with_error" if reasoning.get("attempted") and rstatus in {"failed","verification_failed"} else ("waiting_resource" if rstatus=="waiting_resource" else ("deferred" if rstatus=="deferred" else ("waiting_approval" if rstatus=="approval_required" else "event_ingested")))
        return {"disposition":disposition,"event_type":event_type,"correlation_id":envelope.get("correlation_id"),"reasoning":reasoning,"matched_skills":matched,"session_indexed":bool(text),"note":"Event routing completed. Bounded reasoning is attempted only for actionable user messages, with a single correlation owner, mode/tool guardrails, optional reviewer, and post-action verification."}
    if task == "review_agent_queue":
        recovered=_recover_expired_leases()
        with db() as conn:
            counts={r["status"]:r["n"] for r in conn.execute("SELECT status,COUNT(*) n FROM agent_jobs GROUP BY status").fetchall()}
        return {"task":task,"recovered_expired_leases":recovered,"pruned_completed_jobs":_cleanup_completed_jobs(),"queue_counts":counts}
    uid=_recent_user_id()
    if task == "refresh_home_state":
        return {"task":task,"snapshot":_service_get(f"{ENVIRONMENT_CONTEXT_URL}/snapshot",ENVIRONMENT_CONTEXT_API_KEY)}
    if task == "refresh_current_state":
        if not uid:return {"task":task,"status":"no_recent_user","note":"No user-scoped event has been observed yet."}
        return {"task":task,"user_id":uid,"snapshot":_service_get(f"{CURRENT_STATE_URL}/snapshot/{uid}",CURRENT_STATE_API_KEY)}
    if task == "sync_external_connectors":
        if not uid:return {"task":task,"status":"no_recent_user"}
        result={"task":task,"user_id":uid,"calendar":{},"environment":{},"notifications":{},"published_events":[]}
        try:
            cal=_service_post(f"{CALENDAR_INTELLIGENCE_URL}/connectors/sync",CALENDAR_INTELLIGENCE_API_KEY,{"user_id":uid}); result["calendar"]=cal
            imported=sum(int(x.get("imported") or 0) for x in (cal.get("results") or []) if isinstance(x,dict))
            if imported:
                eid=publish_event("calendar.sync.completed",{"imported":imported,"results":cal.get("results",[])},"connector-sync",uid); result["published_events"].append(eid)
        except Exception as exc:result["calendar"]={"status":"error","error":type(exc).__name__}
        try:
            env=_service_post(f"{ENVIRONMENT_CONTEXT_URL}/changes",ENVIRONMENT_CONTEXT_API_KEY); result["environment"]=env
            for event in env.get("events",[]) or []:
                if not isinstance(event,dict) or not event.get("event_type"):continue
                eid=publish_event(str(event["event_type"]),event.get("payload") or {},"connector-sync",uid); result["published_events"].append(eid)
        except Exception as exc:result["environment"]={"status":"error","error":type(exc).__name__}
        try:
            result["notifications"]=_service_post(f"{NOTIFICATION_URL}/dispatch/{uid}",NOTIFICATION_API_KEY,{"limit":10})
        except Exception as exc:result["notifications"]={"status":"error","error":type(exc).__name__}
        return result
    if task == "review_due_items":
        if not uid:return {"task":task,"status":"no_recent_user"}
        return {"task":task,"user_id":uid,"due":_service_get(f"{SCHEDULE_URL}/due",SCHEDULE_API_KEY,{"user_id":uid,"limit":5})}
    if task == "review_productivity_context":
        if not uid:return {"task":task,"status":"no_recent_user"}
        return {"task":task,"user_id":uid,"current_state":_service_get(f"{CURRENT_STATE_URL}/snapshot/{uid}",CURRENT_STATE_API_KEY)}
    if task in {"refresh_health_context","refresh_wellness_context","daily_context_review"}:
        if not uid:return {"task":task,"status":"no_recent_user"}
        return {"task":task,"user_id":uid,"current_state":_service_get(f"{CURRENT_STATE_URL}/snapshot/{uid}",CURRENT_STATE_API_KEY)}
    return {"task":task or "unknown","disposition":"no_handler","note":"Job completed without side effects; no deterministic handler is registered."}


def _worker_loop() -> None:
    worker_id=f"{AGENT_NODE_ID}-{os.getpid()}-worker"
    while not _supervisor_stop.is_set():
        try:
            _recover_expired_leases()
            job=_claim_job(worker_id)
            if not job:
                _supervisor_stop.wait(max(0.2,AGENT_WORKER_SECONDS)); continue
            heartbeat_agent(job["agent_id"],"running",last_event=job.get("event_type"),last_job_id=job["id"])
            try:
                result=_execute_agent_job(job)
                if result.get("disposition")=="waiting_resource":
                    heartbeat_agent(job["agent_id"],"listening",last_event=job.get("event_type"),last_job_id=job["id"],detail={"waiting_resource":True})
                    continue
                if result.get("disposition")=="deferred":
                    _finish_job(job,"deferred",result); continue
                if job.get("trigger_type") in {"direct_task","delegated_task"} and not result.get("verified"):
                    _finish_job(job,"failed" if result.get("disposition")=="failed" else "deferred",result); continue
                _finish_job(job,"complete",result)
            except Exception as exc:
                attempts=int(job.get("attempts") or 1)
                if attempts < AGENT_JOB_MAX_ATTEMPTS:
                    with db() as conn:
                        conn.execute("UPDATE agent_jobs SET status='queued',error_text=?,lease_owner=NULL,lease_expires_at=NULL,updated_at=? WHERE id=?",(f"{type(exc).__name__}: {exc}"[:2000],now(),job["id"]))
                    heartbeat_agent(job["agent_id"],"queued",last_job_id=job["id"],detail={"retry":attempts,"error":type(exc).__name__})
                else:
                    _finish_job(job,"failed",{"task":(job.get("payload") or {}).get("task")},f"{type(exc).__name__}: {exc}")
        except Exception:
            _supervisor_stop.wait(1)


def _cleanup_completed_jobs() -> int:
    cutoff=(datetime.now(timezone.utc)-timedelta(hours=AGENT_COMPLETED_RETENTION_HOURS)).isoformat()
    with db() as conn:
        rows=conn.execute("SELECT id FROM agent_jobs WHERE status IN ('complete','failed','discarded','deferred') AND updated_at < ?",(cutoff,)).fetchall()
        ids=[r["id"] for r in rows]
        if ids:
            conn.executemany("DELETE FROM agent_artifacts WHERE job_id=?",[(x,) for x in ids])
            conn.executemany("DELETE FROM agent_jobs WHERE id=?",[(x,) for x in ids])
    return len(ids)


def start_supervisor() -> None:
    if _supervisor_threads:
        return
    for target,name in [(_event_loop,"agent-event-consumer"),(_heartbeat_loop,"agent-heartbeat"),(_scheduler_loop,"agent-scheduler"),(_worker_loop,"agent-worker")]:
        t=threading.Thread(target=target,name=name,daemon=True); t.start(); _supervisor_threads.append(t)


class EventCreate(BaseModel):
    event_type: str = Field(min_length=1,max_length=200)
    source: str = Field(default="api",max_length=200)
    user_id: str | None = Field(default=None,max_length=200)
    correlation_id: str | None = Field(default=None,max_length=200)
    payload: dict[str,Any] = Field(default_factory=dict)


class A2AMessageCreate(BaseModel):
    from_agent: str = Field(min_length=1,max_length=100)
    to_agent: str = Field(min_length=1,max_length=100)
    kind: str = Field(default="task",max_length=100)
    payload: dict[str,Any] = Field(default_factory=dict)


class JobStatusUpdate(BaseModel):
    status: str = Field(pattern="^(queued|running|waiting|blocked|complete|failed|discarded)$")
    artifact_type: str | None = None
    artifact_path: str | None = None
    metadata: dict[str,Any] = Field(default_factory=dict)


class SkillPromoteRequest(BaseModel):
    approved_by: str = Field(min_length=1,max_length=200)
    expected_status: str = Field(default="candidate",pattern="^candidate$")


class SkillUseRequest(BaseModel):
    agent_id: str = Field(min_length=1,max_length=100)
    job_id: str | None = Field(default=None,max_length=200)
    context: dict[str,Any] = Field(default_factory=dict)
    success: bool | None = None


class SessionImportItem(BaseModel):
    id: str | None = Field(default=None,max_length=200)
    user_id: str | None = Field(default=None,max_length=200)
    chat_id: str | None = Field(default=None,max_length=200)
    message_id: str | None = Field(default=None,max_length=200)
    model: str | None = Field(default=None,max_length=200)
    input_type: str | None = Field(default="chat",max_length=100)
    text: str = Field(min_length=1,max_length=200000)
    created_at: str | None = Field(default=None,max_length=100)


class SessionImportRequest(BaseModel):
    messages: list[SessionImportItem]
    source: str = Field(default="open-webui-backfill",max_length=100)


class GuardrailRequest(BaseModel):
    agent_id: str = Field(min_length=1,max_length=100)
    task_id: str | None = Field(default=None,max_length=200)
    mode: str = Field(default="default",max_length=40)
    tool: str | None = Field(default=None,max_length=100)
    arguments: dict[str,Any] = Field(default_factory=dict)
    approved: bool = False


class DelegationRequest(BaseModel):
    parent_agent: str = Field(min_length=1,max_length=100)
    child_agent: str = Field(min_length=1,max_length=100)
    objective: str = Field(min_length=1,max_length=10000)
    parent_task_id: str | None = Field(default=None,max_length=200)
    mode: str = Field(default="plan",max_length=40)
    depth: int = Field(default=1,ge=1,le=10)
    context_summary: str = Field(default="",max_length=12000)
    session_sources: list[str] = Field(default_factory=list,max_length=20)


class ContextCheckpointRequest(BaseModel):
    agent_id: str = Field(min_length=1,max_length=100)
    task_id: str | None = Field(default=None,max_length=200)
    summary: str = Field(min_length=1,max_length=50000)
    sources: list[str] = Field(default_factory=list,max_length=50)


class ProjectIndexRequest(BaseModel):
    agent_id: str = Field(min_length=1,max_length=100)
    path: str = Field(default=".",max_length=2000)
    extensions: list[str] = Field(default_factory=lambda:[".py",".js",".ts",".tsx",".jsx",".go",".rs",".sh",".yaml",".yml"],max_length=30)


init_db()
start_supervisor()


@app.get("/health")
def health() -> dict[str, Any]:
    routing=_model_role_validation()
    return {"status": "ok" if routing.get("ok") else "degraded", "version": APP_VERSION, "node_id": AGENT_NODE_ID, "persistent_agents": sum(1 for a in list_agent_manifests().values() if agent_is_persistent(a)), "event_stream": AGENT_EVENT_STREAM, "worker": {"lease_seconds": AGENT_JOB_LEASE_SECONDS, "max_attempts": AGENT_JOB_MAX_ATTEMPTS}, "learning": {"min_successes": AGENT_LEARNING_MIN_SUCCESSES, "session_search": "fts5"}, "execution_controls": {"modes": sorted(mode_catalog()), "guardrails": True, "delegation": True, "model_roles": sorted(model_roles()), "model_routing": routing, "bounded_reasoning": AGENT_REASONING_ENABLED, "reasoning_max_actions": AGENT_REASONING_MAX_ACTIONS, "trusted_memory_retrieval": True, "memory_supersession_filter": True, "entity_aware_memory": True, "dynamic_tool_surface": True, "tool_surface_max": 6, "resource_aware_admission": True, "resource_guardian_status_file": str(RESOURCE_GUARDIAN_STATUS_FILE), "resource_wait_backoff": True, "parallel_workers": True, "fanout_deterministic_merge": True,
            "user_timezone": LIFE_ASSISTANT_TIMEZONE}, "state_machine": ["DISCOVER","PLAN","APPROVE","EXECUTE","VERIFY","COMPLETE"]}


@app.get("/agents", dependencies=[Depends(auth)])
def agent_registry() -> dict[str,Any]:
    manifests=list_agent_manifests(); out=[]
    with db() as conn:
        statuses={r["agent_id"]:dict(r) for r in conn.execute("SELECT * FROM agent_status").fetchall()}
        for aid,m in manifests.items():
            cfg=persistent_cfg(m); st=statuses.get(aid,{})
            q=conn.execute("SELECT COUNT(*) AS n FROM agent_jobs WHERE agent_id=? AND status IN ('queued','running','waiting')",(aid,)).fetchone()["n"]
            out.append({"agent_id":aid,"display_name":m.get("display_name",aid),"persistent":agent_is_persistent(m),"state":st.get("state","definition-only"),"node_id":st.get("node_id",AGENT_NODE_ID if agent_is_persistent(m) else None),"last_heartbeat":st.get("last_heartbeat"),"last_event":st.get("last_event"),"queued_jobs":q,"subscriptions":agent_subscriptions(m),"routing_keywords":agent_routing_keywords(m),"periodic":cfg.get("periodic",[])})
    return {"node_id":AGENT_NODE_ID,"agents":out}


@app.get("/agents/{agent_id}/status", dependencies=[Depends(auth)])
def agent_status_detail(agent_id:str) -> dict[str,Any]:
    manifest=load_agent(agent_id)
    with db() as conn:
        st=conn.execute("SELECT * FROM agent_status WHERE agent_id=?",(agent_id,)).fetchone()
        jobs=[dict(r) for r in conn.execute("SELECT id,trigger_type,event_type,status,priority,node_id,created_at,updated_at FROM agent_jobs WHERE agent_id=? ORDER BY created_at DESC LIMIT 50",(agent_id,)).fetchall()]
    return {"agent_id":agent_id,"persistent":agent_is_persistent(manifest),"status":dict(st) if st else None,"subscriptions":agent_subscriptions(manifest),"jobs":jobs}


@app.post("/events", dependencies=[Depends(auth)])
def create_event(req:EventCreate) -> dict[str,Any]:
    eid=publish_event(req.event_type,req.payload,req.source,req.user_id,req.correlation_id)
    return {"status":"accepted","event_id":eid,"event_type":req.event_type,"node_id":AGENT_NODE_ID}


@app.get("/jobs", dependencies=[Depends(auth)])
def list_jobs(agent_id:str|None=None,status:str|None=None,limit:int=100) -> dict[str,Any]:
    query="SELECT * FROM agent_jobs WHERE 1=1"; args=[]
    if agent_id: query+=" AND agent_id=?"; args.append(agent_id)
    if status: query+=" AND status=?"; args.append(status)
    query+=" ORDER BY created_at DESC LIMIT ?"; args.append(min(max(limit,1),500))
    with db() as conn: rows=[dict(r) for r in conn.execute(query,args).fetchall()]
    for r in rows:
        try:r["payload"]=json.loads(r.pop("payload_json"))
        except Exception:r["payload"]={}
        try:r["result"]=json.loads(r.pop("result_json"))
        except Exception:r["result"]={}
    return {"jobs":rows}


@app.get("/jobs/summary", dependencies=[Depends(auth)])
def job_summary() -> dict[str,Any]:
    with db() as conn:
        rows=conn.execute("SELECT agent_id,status,COUNT(*) n,MIN(created_at) oldest FROM agent_jobs GROUP BY agent_id,status ORDER BY agent_id,status").fetchall()
    agents: dict[str,dict[str,Any]]={}
    for row in rows:
        aid=row["agent_id"]; entry=agents.setdefault(aid,{"agent_id":aid,"queued":0,"running":0,"waiting":0,"failed":0,"complete":0,"discarded":0,"active":0,"oldest_active":None})
        status=row["status"]; entry[status]=int(row["n"] or 0)
        if status in {"queued","running","waiting"}:
            entry["active"]+=int(row["n"] or 0)
            if not entry["oldest_active"] or (row["oldest"] and row["oldest"] < entry["oldest_active"]): entry["oldest_active"]=row["oldest"]
    return {"node_id":AGENT_NODE_ID,"agents":list(agents.values())}


@app.put("/jobs/{job_id}/status", dependencies=[Depends(auth)])
def update_job_status(job_id:str,req:JobStatusUpdate) -> dict[str,Any]:
    ts=now()
    with db() as conn:
        row=conn.execute("SELECT * FROM agent_jobs WHERE id=?",(job_id,)).fetchone()
        if not row: raise HTTPException(status_code=404,detail="Agent job not found")
        conn.execute("UPDATE agent_jobs SET status=?,updated_at=? WHERE id=?",(req.status,ts,job_id))
        if req.artifact_type:
            conn.execute("INSERT INTO agent_artifacts(id,agent_id,job_id,artifact_type,path,metadata_json,created_at) VALUES(?,?,?,?,?,?,?)",(str(uuid.uuid4()),row["agent_id"],job_id,req.artifact_type,req.artifact_path,json.dumps(req.metadata),ts))
    heartbeat_agent(row["agent_id"],"listening" if req.status in {"complete","failed","discarded"} else req.status,last_job_id=job_id)
    return {"id":job_id,"status":req.status}


@app.post("/a2a", dependencies=[Depends(auth)])
def create_a2a(req:A2AMessageCreate) -> dict[str,Any]:
    load_agent(req.from_agent); load_agent(req.to_agent); mid=str(uuid.uuid4()); ts=now()
    with db() as conn:
        conn.execute("INSERT INTO a2a_messages(id,from_agent,to_agent,kind,payload_json,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",(mid,req.from_agent,req.to_agent,req.kind,json.dumps(req.payload),"queued",ts,ts))
    publish_event("a2a.message",{"message_id":mid,"from_agent":req.from_agent,"to_agent":req.to_agent,"kind":req.kind,"payload":req.payload},source=req.from_agent,correlation_id=mid)
    return {"id":mid,"status":"queued","from_agent":req.from_agent,"to_agent":req.to_agent}


@app.get("/a2a/{agent_id}", dependencies=[Depends(auth)])
def list_a2a(agent_id:str,limit:int=100) -> dict[str,Any]:
    load_agent(agent_id)
    with db() as conn: rows=[dict(r) for r in conn.execute("SELECT * FROM a2a_messages WHERE to_agent=? ORDER BY created_at DESC LIMIT ?",(agent_id,min(max(limit,1),500))).fetchall()]
    for r in rows:
        try:r["payload"]=json.loads(r.pop("payload_json"))
        except Exception:r["payload"]={}
    return {"messages":rows}



class MaintenanceRequest(BaseModel):
    stale_task_hours: int = Field(default=8, ge=1, le=168)
    checkpoint_retention_days: int = Field(default=30, ge=1, le=365)


def iso_cutoff(hours: int = 0, days: int = 0) -> str:
    return (datetime.now(timezone.utc) - timedelta(hours=hours, days=days)).isoformat()


@app.post("/maintenance", dependencies=[Depends(auth)])
def maintenance(req: MaintenanceRequest) -> dict[str, Any]:
    stale_cutoff = iso_cutoff(hours=req.stale_task_hours)
    prune_cutoff = iso_cutoff(days=req.checkpoint_retention_days)
    blocked=[]; pruned=[]
    with closing(db()) as conn:
        with conn:
            rows=conn.execute("SELECT id,phase,evidence_json FROM tasks WHERE status='active' AND updated_at < ?", (stale_cutoff,)).fetchall()
            for row in rows:
                evidence=json.loads(row['evidence_json'] or '[]')
                evidence.append({'type':'self_healing','message':'Task auto-blocked after becoming stale','timestamp':now()})
                conn.execute("UPDATE tasks SET status='blocked', evidence_json=?, updated_at=? WHERE id=?", (json.dumps(evidence),now(),row['id']))
                blocked.append(row['id'])
            old=conn.execute("SELECT id FROM tasks WHERE status IN ('complete','blocked','failed') AND updated_at < ?", (prune_cutoff,)).fetchall()
    # The write transaction is committed and closed before filesystem pruning/checkpoint.
    for row in old:
        d=CHECKPOINTS/row['id']
        if d.exists(): shutil.rmtree(d,ignore_errors=True); pruned.append(row['id'])
    checkpoint={'status':'ok'}
    with closing(db()) as conn:
        try:
            result=conn.execute('PRAGMA wal_checkpoint(PASSIVE)').fetchone()
            checkpoint={'status':'busy' if result[0] else 'ok','busy':result[0],'log_frames':result[1],'checkpointed_frames':result[2]}
            conn.execute('PRAGMA optimize')
        except sqlite3.OperationalError as exc:
            if (getattr(exc,'sqlite_errorcode',0) & 255) not in {sqlite3.SQLITE_BUSY,sqlite3.SQLITE_LOCKED}:raise
            checkpoint={'status':'deferred','reason':'database busy or locked'}
    return {'status':'ok','blocked_stale_tasks':blocked,'pruned_checkpoint_tasks':pruned,'pruned_agent_jobs':_cleanup_completed_jobs(),'checkpoint':checkpoint}

@app.get("/skills", dependencies=[Depends(auth)])
def skills() -> dict[str, Any]:
    catalog=_skill_catalog()
    return {"version":2,"skills":catalog,"counts":{"static":sum(1 for v in catalog.values() if v.get("source")=="static"),"learned":sum(1 for v in catalog.values() if v.get("source")=="learned")}}


@app.get("/skills/match", dependencies=[Depends(auth)])
def match_skills(q:str,agent_id:str|None=None,limit:int=5) -> dict[str,Any]:
    if agent_id:load_agent(agent_id)
    return {"query":q,"agent_id":agent_id,"matches":_match_skills(q,agent_id,limit)}


@app.get("/skills/candidates", dependencies=[Depends(auth)])
def skill_candidates(status:str="candidate",agent_id:str|None=None,limit:int=100) -> dict[str,Any]:
    query="SELECT * FROM skill_candidates WHERE status=?"; args=[status]
    if agent_id:query+=" AND agent_id=?"; args.append(agent_id)
    query+=" ORDER BY evidence_count DESC,updated_at DESC LIMIT ?"; args.append(min(max(limit,1),500))
    with db() as conn:rows=[dict(r) for r in conn.execute(query,args).fetchall()]
    for r in rows:
        r["procedure"]=json.loads(r.pop("procedure_json") or "{}"); r["required_tools"]=json.loads(r.pop("required_tools_json") or "[]")
    return {"candidates":rows,"promotion_policy":"explicit approval required; promotion does not grant new tool permissions"}


@app.post("/skills/candidates/{candidate_id}/promote", dependencies=[Depends(auth)])
def promote_skill_candidate(candidate_id:str,req:SkillPromoteRequest) -> dict[str,Any]:
    ts=now()
    with db() as conn:
        row=conn.execute("SELECT * FROM skill_candidates WHERE id=?",(candidate_id,)).fetchone()
        if not row:raise HTTPException(status_code=404,detail="Skill candidate not found")
        if row["status"] != req.expected_status:raise HTTPException(status_code=409,detail="Skill candidate is not promotable in its current state")
        if int(row["evidence_count"] or 0) < AGENT_LEARNING_MIN_SUCCESSES:raise HTTPException(status_code=409,detail="Not enough successful evidence to promote")
        sid=str(uuid.uuid4())
        conn.execute("INSERT INTO learned_skills(id,name,version,agent_id,description,procedure_json,required_tools_json,source_candidate_id,status,promoted_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",(sid,row["name"],1,row["agent_id"],row["description"],row["procedure_json"],row["required_tools_json"],candidate_id,"active",req.approved_by,ts,ts))
        conn.execute("UPDATE skill_candidates SET status='promoted',updated_at=? WHERE id=?",(ts,candidate_id))
    return {"id":sid,"name":row["name"],"status":"active","promoted_by":req.approved_by,"note":"Learned skill is procedural metadata only; existing agent tool policy remains authoritative."}


@app.post("/skills/{skill_name}/use", dependencies=[Depends(auth)])
def use_skill(skill_name:str,req:SkillUseRequest) -> dict[str,Any]:
    load_agent(req.agent_id); catalog=_skill_catalog(); cfg=catalog.get(skill_name)
    if not cfg:raise HTTPException(status_code=404,detail="Skill not found")
    agents=cfg.get("agents") or []
    if agents and req.agent_id not in agents:raise HTTPException(status_code=403,detail="Skill is not assigned to this agent")
    required=list(cfg.get("required_tools") or [])
    agent=load_agent(req.agent_id); denied=[t for t in required if tool_class(agent,t)=="DENY"]
    if denied:raise HTTPException(status_code=403,detail={"message":"Agent policy denies required skill tools","tools":denied})
    with db() as conn:conn.execute("INSERT INTO skill_usage(skill_name,agent_id,job_id,context_json,success,created_at) VALUES(?,?,?,?,?,?)",(skill_name,req.agent_id,req.job_id,json.dumps(compact_tool_payload(req.context)),None if req.success is None else int(req.success),now()))
    return {"skill":skill_name,"agent_id":req.agent_id,"source":cfg.get("source","static"),"description":cfg.get("description"),"procedure":cfg.get("procedure"),"required_tools":required,"approval":cfg.get("approval"),"policy":"tool permissions remain authoritative"}


def _session_terms(q:str) -> list[str]:
    seen=set(); out=[]
    for token in re.findall(r"[\w'-]+", q, flags=re.UNICODE):
        token=token.strip("'-")
        if not token:
            continue
        key=token.casefold()
        if key not in seen:
            seen.add(key); out.append(token)
    return out


def _fts_phrase(value:str) -> str:
    return '"' + value.replace('"','""') + '"'


def _session_match_expression(q:str,exact:bool=False) -> tuple[str,list[str]]:
    terms=_session_terms(q)
    if exact:
        phrase=" ".join(q.split()).strip()
        return (_fts_phrase(phrase) if phrase else "", terms)
    return (" OR ".join(_fts_phrase(t) for t in terms),terms)


def _rank_session_rows(rows:list[dict[str,Any]],terms:list[str],limit:int) -> list[dict[str,Any]]:
    lowered=[t.casefold() for t in terms]
    for row in rows:
        text=str(row.get("text") or "").casefold()
        row["matched_terms"]=sum(1 for t in lowered if t in text)
    rows.sort(key=lambda r:str(r.get("created_at") or ""),reverse=True)
    rows.sort(key=lambda r:float(r.get("_fts_rank",0.0)))
    rows.sort(key=lambda r:int(r.get("matched_terms",0)),reverse=True)
    for row in rows: row.pop("_fts_rank",None)
    return rows[:limit]


@app.get("/sessions/search", dependencies=[Depends(auth)])
def search_sessions(q:str,user_id:str|None=None,chat_id:str|None=None,limit:int=20,exact:bool=False) -> dict[str,Any]:
    limit=min(max(limit,1),min(100,AGENT_SESSION_SEARCH_LIMIT if AGENT_SESSION_SEARCH_LIMIT>0 else 100))
    expr,terms=_session_match_expression(q,exact)
    if not expr:
        return {"query":q,"mode":"exact" if exact else "broad","user_id":user_id,"chat_id":chat_id,"results":[],"scope":"historical session retrieval; not automatically injected into every prompt"}
    with db() as conn:
        try:
            query="SELECT s.*, bm25(session_messages_fts) AS _fts_rank FROM session_messages_fts f JOIN session_messages s ON s.rowid=f.rowid WHERE session_messages_fts MATCH ?"; args=[expr]
            if user_id:query+=" AND s.user_id=?"; args.append(user_id)
            if chat_id:query+=" AND s.chat_id=?"; args.append(chat_id)
            query+=" ORDER BY bm25(session_messages_fts), s.created_at DESC LIMIT ?"; args.append(min(500,max(limit*5,limit)))
            rows=[dict(r) for r in conn.execute(query,args).fetchall()]
            rows=_rank_session_rows(rows,terms,limit)
        except sqlite3.OperationalError:
            clauses=["text LIKE ?" for _ in terms]; args=[f"%{t}%" for t in terms]
            query="SELECT * FROM session_messages WHERE ("+" OR ".join(clauses)+")"
            if user_id:query+=" AND user_id=?"; args.append(user_id)
            if chat_id:query+=" AND chat_id=?"; args.append(chat_id)
            query+=" ORDER BY created_at DESC LIMIT ?"; args.append(min(500,max(limit*5,limit)))
            rows=[dict(r) for r in conn.execute(query,args).fetchall()]
            rows=_rank_session_rows(rows,terms,limit)
    return {"query":q,"mode":"exact" if exact else "broad","terms":terms,"user_id":user_id,"chat_id":chat_id,"results":rows,"scope":"historical session retrieval; not automatically injected into every prompt"}


@app.post("/sessions/import", dependencies=[Depends(auth)])
def import_sessions(req:SessionImportRequest) -> dict[str,Any]:
    if len(req.messages)>500:
        raise HTTPException(status_code=413,detail="Maximum 500 messages per import batch")
    imported=duplicates=skipped=0
    by_user:dict[str,int]={}; by_chat:dict[str,int]={}
    with db() as conn:
        for item in req.messages:
            text=item.text.strip()
            if not text:
                skipped+=1; continue
            stable=item.id or item.message_id
            if not stable:
                raw="\x1f".join([req.source,item.user_id or "",item.chat_id or "",text,item.created_at or ""])
                stable=hashlib.sha256(raw.encode()).hexdigest()
            existing=conn.execute("SELECT 1 FROM session_messages WHERE id=? OR (? IS NOT NULL AND message_id=? AND COALESCE(chat_id,'')=COALESCE(?,'')) LIMIT 1",(stable,item.message_id,item.message_id,item.chat_id)).fetchone()
            if existing:
                duplicates+=1
                continue
            cur=conn.execute("INSERT OR IGNORE INTO session_messages(id,user_id,chat_id,message_id,model,input_type,text,created_at) VALUES(?,?,?,?,?,?,?,?)",(stable,item.user_id,item.chat_id,item.message_id,item.model,item.input_type or "chat",text,item.created_at or now()))
            if cur.rowcount:
                imported+=1
                if item.user_id:by_user[item.user_id]=by_user.get(item.user_id,0)+1
                if item.chat_id:by_chat[item.chat_id]=by_chat.get(item.chat_id,0)+1
            else:
                duplicates+=1
    return {"status":"ok","source":req.source,"received":len(req.messages),"imported":imported,"duplicates":duplicates,"skipped":skipped,"by_user":by_user,"by_chat":by_chat}


@app.get("/learning/status", dependencies=[Depends(auth)])
def learning_status() -> dict[str,Any]:
    with db() as conn:
        obs=conn.execute("SELECT COUNT(*) n FROM skill_observations").fetchone()["n"]
        candidates=conn.execute("SELECT status,COUNT(*) n FROM skill_candidates GROUP BY status").fetchall()
        learned=conn.execute("SELECT COUNT(*) n FROM learned_skills WHERE status='active'").fetchone()["n"]
        sessions=conn.execute("SELECT COUNT(*) n FROM session_messages").fetchone()["n"]
    return {"enabled":True,"min_successes":AGENT_LEARNING_MIN_SUCCESSES,"observed_procedures":obs,"candidates":{r["status"]:r["n"] for r in candidates},"active_learned_skills":learned,"indexed_session_messages":sessions,"promotion":"explicit","self_modifying_prompts":False}


@app.get("/modes", dependencies=[Depends(auth)])
def modes() -> dict[str,Any]:
    return {"default": _yaml_file(MODE_POLICY_FILE).get("default_mode", "default"), "modes": mode_catalog(), "principle": "modes can only restrict agent-manifest permissions"}


@app.get("/model-roles", dependencies=[Depends(auth)])
def get_model_roles() -> dict[str,Any]:
    return {"roles": model_roles(), "routing": "capability aliases route through LiteLLM; no direct agent-to-Ollama path"}


@app.post("/guardrails/evaluate", dependencies=[Depends(auth)])
def guardrails_evaluate(req: GuardrailRequest) -> dict[str,Any]:
    load_agent(req.agent_id); mode_policy(req.mode)
    return _guardrail_checks(req.agent_id, req.task_id, req.mode, req.tool, req.arguments, req.approved)


@app.post("/context/checkpoints", dependencies=[Depends(auth)])
def create_context_checkpoint(req: ContextCheckpointRequest) -> dict[str,Any]:
    load_agent(req.agent_id)
    summary=req.summary[:AGENT_CONTEXT_CHECKPOINT_MAX_CHARS]
    cid=str(uuid.uuid4())
    with db() as conn:
        conn.execute("INSERT INTO context_checkpoints(id,agent_id,task_id,summary,sources_json,created_at) VALUES(?,?,?,?,?,?)", (cid, req.agent_id, req.task_id, summary, json.dumps(req.sources), now()))
    return {"id":cid,"agent_id":req.agent_id,"task_id":req.task_id,"summary":summary,"sources":req.sources,"truncated":len(req.summary)>len(summary)}


@app.post("/delegations", dependencies=[Depends(auth)])
def create_delegation(req: DelegationRequest) -> dict[str,Any]:
    parent=load_agent(req.parent_agent); load_agent(req.child_agent); cfg=mode_policy(req.mode)
    if tool_class(parent,"delegate_task") == "DENY":
        raise HTTPException(status_code=403,detail="Parent agent is not permitted to delegate")
    max_depth=int(cfg.get("max_delegation_depth",1))
    if req.depth>max_depth:
        raise HTTPException(status_code=403,detail=f"Mode {req.mode} permits delegation depth {max_depth}")
    summary=req.context_summary[:AGENT_CONTEXT_CHECKPOINT_MAX_CHARS]
    task_id=str(uuid.uuid4()); did=str(uuid.uuid4()); ts=now()
    with db() as conn:
        conn.execute("INSERT INTO tasks(id,agent_id,objective,phase,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?)", (task_id,req.child_agent,req.objective,"DISCOVER","active",ts,ts))
        conn.execute("INSERT INTO delegations(id,parent_agent,child_agent,parent_task_id,child_task_id,mode,objective,context_json,session_sources_json,status,depth,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)", (did,req.parent_agent,req.child_agent,req.parent_task_id,task_id,req.mode,req.objective,json.dumps({"summary":summary}),json.dumps(req.session_sources),"queued",req.depth,ts,ts))
        conn.execute("INSERT INTO agent_jobs(id,agent_id,trigger_type,trigger_id,event_type,payload_json,status,priority,node_id,attempts,result_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",(str(uuid.uuid4()),req.child_agent,"delegated_task",task_id,"user.delegation",json.dumps({"task_id":task_id,"delegation_id":did}),"queued",50,AGENT_NODE_ID,0,"{}",ts,ts))
    return {"id":did,"parent_agent":req.parent_agent,"child_agent":req.child_agent,"child_task_id":task_id,"mode":req.mode,"depth":req.depth,"status":"queued","context":{"summary":summary,"session_sources":req.session_sources},"isolation":"child agent manifest and mode policy remain authoritative"}


@app.get("/delegations", dependencies=[Depends(auth)])
def list_delegations(parent_agent:str|None=None,child_agent:str|None=None,status:str|None=None,limit:int=100) -> dict[str,Any]:
    q="SELECT * FROM delegations WHERE 1=1"; args=[]
    if parent_agent:q+=" AND parent_agent=?";args.append(parent_agent)
    if child_agent:q+=" AND child_agent=?";args.append(child_agent)
    if status:q+=" AND status=?";args.append(status)
    q+=" ORDER BY created_at DESC LIMIT ?";args.append(min(max(limit,1),500))
    with db() as conn: rows=[dict(r) for r in conn.execute(q,args).fetchall()]
    for r in rows:r["context"]=json.loads(r.pop("context_json") or "{}");r["session_sources"]=json.loads(r.pop("session_sources_json") or "[]")
    return {"delegations":rows}


def _project_language(path:Path)->str:
    return {".py":"python",".js":"javascript",".jsx":"javascript",".ts":"typescript",".tsx":"typescript",".go":"go",".rs":"rust",".sh":"shell",".yaml":"yaml",".yml":"yaml"}.get(path.suffix.lower(),path.suffix.lower().lstrip("."))


def _project_extract(path:Path,text:str)->tuple[list[str],list[str]]:
    symbols=[]; imports=[]
    patterns=[r"^\s*(?:async\s+)?def\s+([A-Za-z_][\w]*)",r"^\s*class\s+([A-Za-z_][\w]*)",r"^\s*(?:export\s+)?(?:async\s+)?function\s+([A-Za-z_$][\w$]*)",r"^\s*(?:export\s+)?(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=",r"^\s*func\s+(?:\([^)]*\)\s*)?([A-Za-z_][\w]*)",r"^\s*(?:pub\s+)?(?:fn|struct|enum|trait)\s+([A-Za-z_][\w]*)"]
    for line in text.splitlines():
        for pat in patterns:
            m=re.search(pat,line)
            if m: symbols.append(m.group(1)); break
        m=re.search(r"^\s*(?:from\s+([\w.]+)\s+import|import\s+([\w.]+)|(?:import|export).*?from\s+['\"]([^'\"]+)|require\(['\"]([^'\"]+))",line)
        if m:
            imports.append(next((x for x in m.groups() if x),""))
    return sorted(set(symbols))[:500],sorted(set(x for x in imports if x))[:500]


@app.get("/reasoning/runs", dependencies=[Depends(auth)])
def reasoning_runs(agent_id:str|None=None,status:str|None=None,limit:int=50) -> dict[str,Any]:
    query="SELECT * FROM reasoning_runs WHERE 1=1";args=[]
    if agent_id:query+=" AND agent_id=?";args.append(agent_id)
    if status:query+=" AND status=?";args.append(status)
    query+=" ORDER BY created_at DESC LIMIT ?";args.append(min(max(limit,1),200))
    with db() as conn:rows=[dict(r) for r in conn.execute(query,args).fetchall()]
    for row in rows:
        for src,dst in [("prompt_context_json","prompt_context"),("proposal_json","proposal"),("result_json","result")]:
            try:row[dst]=json.loads(row.pop(src) or "{}")
            except Exception:row[dst]={}
    return {"enabled":AGENT_REASONING_ENABLED,"runs":rows}


@app.get("/reasoning/runs/{run_id}", dependencies=[Depends(auth)])
def reasoning_run_detail(run_id:str) -> dict[str,Any]:
    with db() as conn:
        row=conn.execute("SELECT * FROM reasoning_runs WHERE id=?",(run_id,)).fetchone()
        if not row:raise HTTPException(status_code=404,detail="Reasoning run not found")
        actions=[dict(r) for r in conn.execute("SELECT * FROM reasoning_actions WHERE reasoning_run_id=? ORDER BY created_at",(run_id,)).fetchall()]
    out=dict(row)
    for src,dst in [("prompt_context_json","prompt_context"),("proposal_json","proposal"),("result_json","result")]:
        try:out[dst]=json.loads(out.pop(src) or "{}")
        except Exception:out[dst]={}
    for a in actions:
        for src,dst in [("arguments_json","arguments"),("result_json","result"),("verification_json","verification"),("reviewer_json","reviewer")]:
            try:a[dst]=json.loads(a.pop(src) or "{}")
            except Exception:a[dst]={}
    out["actions"]=actions;return out


@app.post("/projects/index", dependencies=[Depends(auth)])
def index_project(req: ProjectIndexRequest) -> dict[str,Any]:
    agent=load_agent(req.agent_id); root=resolve_scoped(agent,req.path,True)
    if not root.is_dir(): raise HTTPException(status_code=400,detail="Project index path must be a directory")
    extensions={x if x.startswith(".") else "."+x for x in req.extensions}; indexed=skipped=0; ts=now()
    with db() as conn:
        for f in root.rglob("*"):
            if indexed>=AGENT_PROJECT_GRAPH_MAX_FILES:break
            if not f.is_file() or f.suffix.lower() not in extensions:continue
            try:
                if f.stat().st_size>MAX_FILE_BYTES:skipped+=1;continue
                text=f.read_text(errors="replace")
            except Exception:
                skipped+=1;continue
            symbols,imports=_project_extract(f,text); rel=str(f.relative_to(root)); digest=hashlib.sha256(text.encode(errors="replace")).hexdigest()
            conn.execute("INSERT INTO project_graph_files(agent_id,path,language,sha256,symbols_json,imports_json,indexed_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(agent_id,path) DO UPDATE SET language=excluded.language,sha256=excluded.sha256,symbols_json=excluded.symbols_json,imports_json=excluded.imports_json,indexed_at=excluded.indexed_at", (req.agent_id,rel,_project_language(f),digest,json.dumps(symbols),json.dumps(imports),ts)); indexed+=1
    return {"agent_id":req.agent_id,"root":str(root),"indexed":indexed,"skipped":skipped,"max_files":AGENT_PROJECT_GRAPH_MAX_FILES}


@app.get("/projects/search", dependencies=[Depends(auth)])
def search_project(agent_id:str,q:str,limit:int=50) -> dict[str,Any]:
    load_agent(agent_id); needle=q.casefold(); out=[]
    with db() as conn: rows=conn.execute("SELECT * FROM project_graph_files WHERE agent_id=? ORDER BY path",(agent_id,)).fetchall()
    for row in rows:
        d=dict(row); symbols=json.loads(d.pop("symbols_json") or "[]"); imports=json.loads(d.pop("imports_json") or "[]")
        hay=" ".join([d["path"],*symbols,*imports]).casefold()
        if needle in hay: d["symbols"]=symbols;d["imports"]=imports;out.append(d)
        if len(out)>=min(max(limit,1),200):break
    return {"agent_id":agent_id,"query":q,"results":out}


@app.get("/tools/{agent_id}", dependencies=[Depends(auth)])
def tools(agent_id: str) -> dict[str, Any]:
    agent = load_agent(agent_id)
    return {"agent_id": agent_id, "tools": agent.get("tools", {})}


@app.post("/tasks", dependencies=[Depends(auth)])
def create_task(req: TaskCreate) -> dict[str, Any]:
    load_agent(req.agent_id)
    task_id = str(uuid.uuid4())
    ts = now()
    with db() as conn:
        conn.execute("INSERT INTO tasks(id,agent_id,objective,phase,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?)",
                     (task_id, req.agent_id, req.objective, "DISCOVER", "active", ts, ts))
        conn.execute("INSERT INTO agent_jobs(id,agent_id,trigger_type,trigger_id,event_type,payload_json,status,priority,node_id,attempts,result_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",(str(uuid.uuid4()),req.agent_id,"direct_task",task_id,"user.task",json.dumps({"task_id":task_id}),"queued",50,AGENT_NODE_ID,0,"{}",ts,ts))
    return {"id": task_id, "agent_id": req.agent_id, "objective": req.objective, "phase": "DISCOVER", "status": "active"}


@app.put("/tasks/{task_id}/plan", dependencies=[Depends(auth)])
def set_plan(task_id: str, req: TaskPlan) -> dict[str, Any]:
    with db() as conn:
        row = conn.execute("SELECT * FROM tasks WHERE id=?", (task_id,)).fetchone()
        if not row: raise HTTPException(status_code=404, detail="Task not found")
        conn.execute("UPDATE tasks SET plan_json=?, phase='PLAN', updated_at=? WHERE id=?", (json.dumps(req.steps), now(), task_id))
    return {"id": task_id, "phase": "PLAN", "steps": req.steps}


@app.put("/tasks/{task_id}/phase", dependencies=[Depends(auth)])
def set_phase(task_id: str, req: TaskPhase) -> dict[str, Any]:
    with db() as conn:
        row = conn.execute("SELECT * FROM tasks WHERE id=?", (task_id,)).fetchone()
        if not row: raise HTTPException(status_code=404, detail="Task not found")
        old = ["DISCOVER","PLAN","APPROVE","EXECUTE","VERIFY","COMPLETE"].index(row["phase"])
        new = ["DISCOVER","PLAN","APPROVE","EXECUTE","VERIFY","COMPLETE"].index(req.phase)
        if new < old and req.status not in {"failed", "blocked"}:
            raise HTTPException(status_code=409, detail="Phase cannot move backwards unless task is blocked/failed")
        if req.phase == "COMPLETE" and req.status == "complete":
            verified=conn.execute("SELECT id FROM agent_jobs WHERE trigger_id=? AND trigger_type IN ('direct_task','delegated_task') AND status='complete' AND json_extract(result_json,'$.verified')=1 LIMIT 1",(task_id,)).fetchone()
            if not verified:raise HTTPException(status_code=409,detail="Cannot complete task without a verified worker result")
        evidence = json.loads(row["evidence_json"] or "[]") + req.evidence
        conn.execute("UPDATE tasks SET phase=?,status=?,evidence_json=?,updated_at=? WHERE id=?", (req.phase,req.status,json.dumps(evidence),now(),task_id))
    return {"id": task_id, "phase": req.phase, "status": req.status, "evidence": evidence}


@app.get("/tasks/{task_id}", dependencies=[Depends(auth)])
def get_task(task_id: str) -> dict[str, Any]:
    with db() as conn:
        row = conn.execute("SELECT * FROM tasks WHERE id=?", (task_id,)).fetchone()
        if not row: raise HTTPException(status_code=404, detail="Task not found")
        events = [dict(x) for x in conn.execute("SELECT * FROM tool_events WHERE task_id=? ORDER BY id", (task_id,)).fetchall()]
    out = dict(row); out["plan"] = json.loads(out.pop("plan_json")); out["evidence"] = json.loads(out.pop("evidence_json")); out["tool_events"] = events
    return out


@app.post("/tools/execute", dependencies=[Depends(auth)])
def execute(req: ToolCall) -> dict[str, Any]:
    agent = load_agent(req.agent_id)
    mode_policy(req.mode)
    klass = effective_tool_class(agent, req.tool, req.mode)
    guardrail = _guardrail_checks(req.agent_id, req.task_id, req.mode, req.tool, req.arguments, req.approved)
    if guardrail["outcome"] == "blocked":
        event(req.task_id, req.agent_id, req.tool, klass, req.approved, False, f"guardrail blocked in mode {req.mode}")
        raise HTTPException(status_code=403, detail={"message":"Tool blocked by agent/mode guardrails","guardrail":guardrail})
    if guardrail["outcome"] == "approval_required" and not req.approved:
        event(req.task_id, req.agent_id, req.tool, klass, False, False, "guardrail approval required")
        return {"status": "approval_required", "tool": req.tool, "policy_class": klass, "mode":req.mode, "guardrail":guardrail}
    if klass == "APPROVAL_REQUIRED" and not req.approved:
        event(req.task_id, req.agent_id, req.tool, klass, False, False, "approval required")
        return {"status": "approval_required", "tool": req.tool, "policy_class": klass, "mode":req.mode, "guardrail":guardrail}
    pre = run_hooks("pre", req.tool, req.arguments)
    try:
        if req.tool == "file_read":
            p = resolve_scoped(agent, str(req.arguments.get("path", "")), True)
            if not p.is_file(): raise HTTPException(status_code=400, detail="Not a file")
            if p.stat().st_size > MAX_FILE_BYTES: raise HTTPException(status_code=413, detail="File exceeds read limit")
            result = {"path": str(p), "content": p.read_text(errors="replace")}
        elif req.tool == "file_list":
            p = resolve_scoped(agent, str(req.arguments.get("path", ".")), True)
            if not p.is_dir(): raise HTTPException(status_code=400, detail="Not a directory")
            result = {"path": str(p), "entries": sorted(x.name for x in p.iterdir())[:1000]}
        elif req.tool == "file_find":
            p = resolve_scoped(agent, str(req.arguments.get("path", ".")), True)
            pattern = str(req.arguments.get("pattern", "*"))
            result = {"matches": [str(x) for x in list(p.rglob(pattern))[:500] if any(x == r or r in x.parents for r in workspace_roots(agent))]}
        elif req.tool == "file_search":
            p = resolve_scoped(agent, str(req.arguments.get("path", ".")), True)
            needle = str(req.arguments.get("query", ""))
            if not needle: raise HTTPException(status_code=400, detail="query required")
            hits=[]
            for f in p.rglob("*"):
                if not f.is_file() or f.stat().st_size > MAX_FILE_BYTES: continue
                try: lines=f.read_text(errors="replace").splitlines()
                except Exception: continue
                for i,line in enumerate(lines,1):
                    if needle.lower() in line.lower(): hits.append({"path":str(f),"line":i,"text":line[:500]})
                    if len(hits)>=300: break
                if len(hits)>=300: break
            result={"matches":hits}
        elif req.tool == "file_patch":
            p = resolve_scoped(agent, str(req.arguments.get("path", "")), True)
            old = str(req.arguments.get("old", "")); new = str(req.arguments.get("new", "")); count = int(req.arguments.get("count", 1))
            if not old: raise HTTPException(status_code=400, detail="old text required")
            text = p.read_text(); occurrences = text.count(old)
            if occurrences < count: raise HTTPException(status_code=409, detail=f"Patch target found {occurrences} times; expected at least {count}")
            cp = checkpoint(req.task_id, req.agent_id, p)
            p.write_text(text.replace(old,new,count))
            result={"path":str(p),"checkpoint":cp,"replacements":count}
        elif req.tool == "file_create":
            p = resolve_scoped(agent, str(req.arguments.get("path", "")), False)
            overwrite = bool(req.arguments.get("overwrite", False))
            if p.exists() and not overwrite: raise HTTPException(status_code=409, detail="File exists; set overwrite=true")
            cp = checkpoint(req.task_id, req.agent_id, p)
            p.parent.mkdir(parents=True, exist_ok=True); p.write_text(str(req.arguments.get("content", "")))
            result={"path":str(p),"checkpoint":cp}
        elif req.tool == "memory_search":
            if not MEM0_API_KEY: raise HTTPException(status_code=503,detail="Memory service is not configured")
            query=str(req.arguments.get("query") or "").strip();uid=str(req.arguments.get("user_id") or "default")
            if not query:raise HTTPException(status_code=400,detail="query required")
            payload={"user_id":uid,"agent_id":req.agent_id,"session_id":req.arguments.get("session_id"),"query":query,"limit":min(max(int(req.arguments.get("limit",8)),1),20),"include_legacy":bool(req.arguments.get("include_legacy",False))}
            with httpx.Client(timeout=12) as client:
                r=client.post(f"{MEM0_URL}/search",headers={"Authorization":f"Bearer {MEM0_API_KEY}"},json=payload)
                if r.status_code>=400:raise HTTPException(status_code=r.status_code,detail=r.text[:1000])
                result=r.json()
        elif req.tool == "delegate_task":
            child=str(req.arguments.get("child_agent") or "").strip();objective=str(req.arguments.get("objective") or "").strip()
            if not child or not objective:raise HTTPException(status_code=400,detail="child_agent and objective are required")
            result=create_delegation(DelegationRequest(parent_agent=req.agent_id,child_agent=child,objective=objective,parent_task_id=req.task_id,mode=str(req.arguments.get("mode") or "plan"),depth=int(req.arguments.get("depth",1)),context_summary=str(req.arguments.get("context_summary") or "")[:AGENT_CONTEXT_CHECKPOINT_MAX_CHARS],session_sources=list(req.arguments.get("session_sources") or [])[:20]))
        elif req.tool == "web_fetch":
            url=str(req.arguments.get("url", "")); validate_url(url)
            with httpx.Client(timeout=15.0, follow_redirects=False) as client:
                r=client.get(url, headers={"User-Agent":"ai-laptop-agent-runtime/1.6"})
                if r.is_redirect: raise HTTPException(status_code=403, detail="Redirects are not followed to prevent SSRF bypass")
                content=r.content[:MAX_FETCH_BYTES]
                result={"url":url,"status_code":r.status_code,"content_type":r.headers.get("content-type"),"text":content.decode(errors="replace")}
        elif req.tool == "journal_ingest":
            if not LIFE_PROFILE_API_KEY:
                raise HTTPException(status_code=503, detail="Life profile integration is not configured")
            payload = dict(req.arguments.get("data") or {})
            payload.setdefault("user_id", str(req.arguments.get("user_id", "default")))
            if "raw_text" not in payload and req.arguments.get("raw_text"):
                payload["raw_text"] = str(req.arguments["raw_text"])
            if not payload.get("raw_text"):
                raise HTTPException(status_code=400, detail="raw_text required")
            with httpx.Client(timeout=100.0) as client:
                r = client.post(LIFE_PROFILE_URL + "/journal", headers={"Authorization": f"Bearer {LIFE_PROFILE_API_KEY}"}, json=payload)
                if r.status_code >= 400:
                    raise HTTPException(status_code=502, detail=f"Life profile journal error {r.status_code}: {r.text[:1000]}")
                result = r.json()
        elif req.tool in {"life_profile_read", "life_profile_write"}:
            if not LIFE_PROFILE_API_KEY:
                raise HTTPException(status_code=503, detail="Life profile integration is not configured")
            action = str(req.arguments.get("action", "summary" if req.tool == "life_profile_read" else "checkin"))
            user_id = str(req.arguments.get("user_id", "default"))
            headers={"Authorization":f"Bearer {LIFE_PROFILE_API_KEY}"}
            read_actions={
                "fields": ("GET", "/fields"),
                "timeline": ("GET", "/timeline"),
                "entry": ("GET", "/entries/{entry_id}"),
                "summary_day": ("GET", "/summary/day"),
                "summary_week": ("GET", "/summary/week"),
                "summary_month": ("GET", "/summary/month"),
                "summary_year": ("GET", "/summary/year"),
                "journal": ("GET", "/journal"),
                "journal_entry": ("GET", "/journal/{journal_id}"),
            }
            write_actions={
                "checkin": ("POST", "/checkins"),
                "capacity": ("POST", "/capacity"),
                "context": ("POST", "/contexts"),
                "goal": ("POST", "/goals"),
                "preference": ("POST", "/preferences"),
                "field": ("POST", "/fields"),
                "entry_patch": ("PATCH", "/entries/{entry_id}"),
                "entry_delete": ("DELETE", "/entries/{entry_id}"),
                "journal": ("POST", "/journal"),
                "journal_patch": ("PATCH", "/journal/{journal_id}"),
                "journal_reprocess": ("POST", "/journal/{journal_id}/reprocess"),
            }
            allowed = read_actions if req.tool == "life_profile_read" else write_actions
            if action not in allowed:
                raise HTTPException(status_code=400, detail=f"Unsupported life profile action: {action}")
            method,path = allowed[action]
            entry_id=str(req.arguments.get("entry_id", ""))
            journal_id=str(req.arguments.get("journal_id", ""))
            if "{entry_id}" in path:
                if not entry_id: raise HTTPException(status_code=400, detail="entry_id required")
                path=path.replace("{entry_id}", entry_id)
            if "{journal_id}" in path:
                if not journal_id: raise HTTPException(status_code=400, detail="journal_id required")
                path=path.replace("{journal_id}", journal_id)
            payload = dict(req.arguments.get("data") or {})
            payload.setdefault("user_id", user_id)
            params={"user_id":user_id}
            if "anchor" in req.arguments: params["anchor"] = str(req.arguments["anchor"])
            if "limit" in req.arguments: params["limit"] = int(req.arguments["limit"])
            with httpx.Client(timeout=15.0) as client:
                if method == "GET": r=client.get(LIFE_PROFILE_URL+path,headers=headers,params=params)
                elif method == "POST": r=client.post(LIFE_PROFILE_URL+path,headers=headers,json=payload,params={"user_id":user_id} if action=="field" else None)
                elif method == "PATCH": r=client.patch(LIFE_PROFILE_URL+path,headers=headers,json=payload,params=params)
                else: r=client.delete(LIFE_PROFILE_URL+path,headers=headers,params=params)
                if r.status_code >= 400:
                    raise HTTPException(status_code=502, detail=f"Life profile service error {r.status_code}: {r.text[:1000]}")
                result=r.json()
        elif req.tool in {"schedule_read", "schedule_write"}:
            if not SCHEDULE_API_KEY: raise HTTPException(status_code=503,detail="Schedule service is not configured")
            action=str(req.arguments.get("action","list" if req.tool=="schedule_read" else "create"))
            uid=str(req.arguments.get("user_id",req.agent_id))
            hdr={"Authorization":f"Bearer {SCHEDULE_API_KEY}"}
            with httpx.Client(timeout=10) as client:
                if req.tool=="schedule_read":
                    if action=="list": r=client.get(f"{SCHEDULE_URL}/reminders",headers=hdr,params={"user_id":uid,"status":req.arguments.get("status","active")})
                    elif action=="due": r=client.get(f"{SCHEDULE_URL}/due",headers=hdr,params={"user_id":uid,"capacity":req.arguments.get("capacity","normal"),"limit":req.arguments.get("limit",5)})
                    else: raise HTTPException(status_code=400,detail=f"Unsupported schedule read action: {action}")
                else:
                    if action=="create": r=client.post(f"{SCHEDULE_URL}/reminders",headers=hdr,json={k:v for k,v in req.arguments.items() if k!="action"})
                    elif action=="snooze": r=client.post(f"{SCHEDULE_URL}/reminders/{req.arguments['id']}/snooze",headers=hdr,json={"minutes":req.arguments.get("minutes",30)})
                    elif action=="done": r=client.post(f"{SCHEDULE_URL}/reminders/{req.arguments['id']}/done",headers=hdr)
                    elif action=="update": r=client.patch(f"{SCHEDULE_URL}/reminders/{req.arguments['id']}",headers=hdr,json=req.arguments.get("changes",{}))
                    else: raise HTTPException(status_code=400,detail=f"Unsupported schedule write action: {action}")
                if r.status_code>=400: raise HTTPException(status_code=r.status_code,detail=r.text[:1000])
                result=r.json()
        elif req.tool in {"planning_read", "planning_write"}:
            if not PLANNER_API_KEY: raise HTTPException(status_code=503,detail="Planner service is not configured")
            action=str(req.arguments.get("action","today" if req.tool=="planning_read" else "rebuild"))
            uid=str(req.arguments.get("user_id","default")); hdr={"Authorization":f"Bearer {PLANNER_API_KEY}"}
            with httpx.Client(timeout=12) as client:
                if req.tool=="planning_read":
                    if action!="today": raise HTTPException(status_code=400,detail=f"Unsupported planning read action: {action}")
                    r=client.get(f"{PLANNER_URL}/today",headers=hdr,params={"user_id":uid})
                else:
                    if action=="rebuild": r=client.post(f"{PLANNER_URL}/rebuild",headers=hdr,json={"user_id":uid,"reason":req.arguments.get("reason","day changed"),"preserve_started":bool(req.arguments.get("preserve_started",True))})
                    elif action=="add": r=client.post(f"{PLANNER_URL}/items",headers=hdr,json={"user_id":uid,"title":req.arguments.get("title",""),"importance":req.arguments.get("importance","routine"),"note":req.arguments.get("note",""),"optional":bool(req.arguments.get("optional",True))})
                    elif action=="update": r=client.patch(f"{PLANNER_URL}/items/{req.arguments['id']}",headers=hdr,json=req.arguments.get("changes",{}))
                    elif action=="discard": r=client.post(f"{PLANNER_URL}/discard",headers=hdr,params={"user_id":uid,"reason":req.arguments.get("reason","not useful today")})
                    else: raise HTTPException(status_code=400,detail=f"Unsupported planning write action: {action}")
                if r.status_code>=400: raise HTTPException(status_code=r.status_code,detail=r.text[:1000])
                result=r.json()
        elif req.tool == "current_state_read":
            if not CURRENT_STATE_API_KEY: raise HTTPException(status_code=503,detail="Current-state service is not configured")
            uid=str(req.arguments.get("user_id","default"))
            with httpx.Client(timeout=12) as client:
                action=str(req.arguments.get("action","snapshot")); path=f"/context-pack/{uid}" if action=="context_pack" else f"/snapshot/{uid}"
                params={"max_chars":int(req.arguments.get("max_chars",12000))} if action=="context_pack" else None
                r=client.get(CURRENT_STATE_URL+path,headers={"Authorization":f"Bearer {CURRENT_STATE_API_KEY}"},params=params)
                if r.status_code>=400: raise HTTPException(status_code=r.status_code,detail=r.text[:1000])
                result=r.json()
        elif req.tool in {"notification_read", "notification_write"}:
            if not NOTIFICATION_API_KEY: raise HTTPException(status_code=503,detail="Notification service is not configured")
            uid=str(req.arguments.get("user_id","default")); hdr={"Authorization":f"Bearer {NOTIFICATION_API_KEY}"}
            action=str(req.arguments.get("action","feed" if req.tool=="notification_read" else "create"))
            with httpx.Client(timeout=10) as client:
                if req.tool=="notification_read":
                    if action!="feed": raise HTTPException(status_code=400,detail=f"Unsupported notification read action: {action}")
                    r=client.get(f"{NOTIFICATION_URL}/feed/{uid}",headers=hdr,params={"limit":int(req.arguments.get("limit",10))})
                else:
                    if action=="create":
                        payload=dict(req.arguments.get("data") or {}); payload.setdefault("user_id",uid); r=client.post(f"{NOTIFICATION_URL}/notifications",headers=hdr,json=payload)
                    elif action in {"dismiss","delivered"}:
                        nid=str(req.arguments.get("id",""));
                        if not nid: raise HTTPException(status_code=400,detail="notification id required")
                        r=client.post(f"{NOTIFICATION_URL}/notifications/{nid}/{action}",headers=hdr)
                    else: raise HTTPException(status_code=400,detail=f"Unsupported notification write action: {action}")
                if r.status_code>=400: raise HTTPException(status_code=r.status_code,detail=r.text[:1000])
                result=r.json()
        elif req.tool in {"assistance_preferences_read", "assistance_preferences_write", "explanation_read", "explanation_record"}:
            if not ASSISTANCE_CONTROL_API_KEY: raise HTTPException(status_code=503,detail="Assistance-control service is not configured")
            uid=str(req.arguments.get("user_id","default")); hdr={"Authorization":f"Bearer {ASSISTANCE_CONTROL_API_KEY}"}
            with httpx.Client(timeout=10) as client:
                if req.tool=="assistance_preferences_read":
                    r=client.get(f"{ASSISTANCE_CONTROL_URL}/preferences/{uid}",headers=hdr)
                elif req.tool=="assistance_preferences_write":
                    action=str(req.arguments.get("action","set"))
                    if action=="set": r=client.put(f"{ASSISTANCE_CONTROL_URL}/preferences",headers=hdr,json={"user_id":uid,"key":req.arguments.get("key"),"value":req.arguments.get("value"),"source":"explicit"})
                    elif action=="reset": r=client.delete(f"{ASSISTANCE_CONTROL_URL}/preferences/{uid}/{req.arguments.get('key','')}",headers=hdr)
                    else: raise HTTPException(status_code=400,detail=f"Unsupported assistance preference action: {action}")
                elif req.tool=="explanation_read":
                    r=client.get(f"{ASSISTANCE_CONTROL_URL}/explanations/{uid}",headers=hdr,params={"limit":int(req.arguments.get("limit",20))})
                else:
                    payload={"user_id":uid,"agent_id":req.agent_id,"action":str(req.arguments.get("action","assistance")),"reason":str(req.arguments.get("reason","")),"sources":list(req.arguments.get("sources",[])),"excluded":list(req.arguments.get("excluded",[])),"confidence":str(req.arguments.get("confidence","moderate"))}
                    if not payload['reason']: raise HTTPException(status_code=400,detail="reason required")
                    r=client.post(f"{ASSISTANCE_CONTROL_URL}/explanations",headers=hdr,json=payload)
                if r.status_code>=400: raise HTTPException(status_code=r.status_code,detail=r.text[:1000])
                result=r.json()
        elif req.tool in {"timeline_read", "timeline_write"}:
            if not TIMELINE_API_KEY: raise HTTPException(status_code=503,detail="Timeline service is not configured")
            uid=str(req.arguments.get("user_id","default")); hdr={"Authorization":f"Bearer {TIMELINE_API_KEY}"}; action=str(req.arguments.get("action","timeline" if req.tool=="timeline_read" else "ingest"))
            with httpx.Client(timeout=15) as client:
                if req.tool=="timeline_read":
                    if action=="timeline": r=client.get(f"{TIMELINE_URL}/timeline",headers=hdr,params={"user_id":uid,"start":req.arguments.get("start"),"end":req.arguments.get("end"),"category":req.arguments.get("category"),"source_name":req.arguments.get("source_name"),"limit":int(req.arguments.get("limit",200))})
                    elif action=="summary": r=client.get(f"{TIMELINE_URL}/summary",headers=hdr,params={"user_id":uid,"days":int(req.arguments.get("days",30))})
                    elif action=="sources": r=client.get(f"{TIMELINE_URL}/sources/{uid}",headers=hdr)
                    elif action=="export": r=client.get(f"{TIMELINE_URL}/export",headers=hdr,params={"user_id":uid,"category":req.arguments.get("category"),"source_name":req.arguments.get("source_name")})
                    else: raise HTTPException(status_code=400,detail=f"Unsupported timeline read action: {action}")
                else:
                    if action=="ingest":
                        payload=dict(req.arguments.get("data") or req.arguments); payload.pop("action",None); payload.setdefault("user_id",uid); r=client.post(f"{TIMELINE_URL}/events",headers=hdr,json=payload)
                    elif action=="sync_platform": r=client.post(f"{TIMELINE_URL}/sync/platform",headers=hdr,params={"user_id":uid,"limit":int(req.arguments.get("limit",200))})
                    elif action=="source":
                        payload=dict(req.arguments.get("data") or {}); payload.setdefault("user_id",uid); r=client.post(f"{TIMELINE_URL}/sources",headers=hdr,json=payload)
                    elif action=="delete_category": r=client.delete(f"{TIMELINE_URL}/events",headers=hdr,params={"user_id":uid,"category":req.arguments.get("category")})
                    else: raise HTTPException(status_code=400,detail=f"Unsupported timeline write action: {action}")
                if r.status_code>=400: raise HTTPException(status_code=r.status_code,detail=r.text[:1000])
                result=r.json()
        elif req.tool in {"calendar_read", "calendar_write", "briefing_read"}:
            if not CALENDAR_INTELLIGENCE_API_KEY: raise HTTPException(status_code=503,detail="Calendar intelligence service is not configured")
            uid=str(req.arguments.get("user_id","default")); hdr={"Authorization":f"Bearer {CALENDAR_INTELLIGENCE_API_KEY}"}
            action=str(req.arguments.get("action","agenda" if req.tool=="calendar_read" else "create"))
            with httpx.Client(timeout=12) as client:
                if req.tool=="briefing_read":
                    kind=str(req.arguments.get("kind","morning")); r=client.get(f"{CALENDAR_INTELLIGENCE_URL}/briefing/{kind}",headers=hdr,params={"user_id":uid})
                elif req.tool=="calendar_read":
                    if action=="agenda": r=client.get(f"{CALENDAR_INTELLIGENCE_URL}/agenda/{req.arguments.get('period','day')}",headers=hdr,params={"user_id":uid})
                    elif action=="events": r=client.get(f"{CALENDAR_INTELLIGENCE_URL}/events",headers=hdr,params={"user_id":uid,"start":req.arguments.get("start"),"end":req.arguments.get("end")})
                    elif action=="conflicts": r=client.get(f"{CALENDAR_INTELLIGENCE_URL}/conflicts",headers=hdr,params={"user_id":uid,"days":int(req.arguments.get("days",14))})
                    else: raise HTTPException(status_code=400,detail=f"Unsupported calendar read action: {action}")
                else:
                    if action=="create":
                        payload=dict(req.arguments.get("data") or req.arguments); payload.pop("action",None); payload.setdefault("user_id",uid); r=client.post(f"{CALENDAR_INTELLIGENCE_URL}/events",headers=hdr,json=payload)
                    elif action=="update": r=client.patch(f"{CALENDAR_INTELLIGENCE_URL}/events/{req.arguments['id']}",headers=hdr,json=req.arguments.get("changes",{}))
                    elif action=="delete": r=client.delete(f"{CALENDAR_INTELLIGENCE_URL}/events/{req.arguments['id']}",headers=hdr)
                    elif action=="import_ics": r=client.post(f"{CALENDAR_INTELLIGENCE_URL}/import/ics",headers=hdr,json={"user_id":uid,"ics_text":req.arguments.get("ics_text","") ,"source":req.arguments.get("source","ics-import")})
                    else: raise HTTPException(status_code=400,detail=f"Unsupported calendar write action: {action}")
                if r.status_code>=400: raise HTTPException(status_code=r.status_code,detail=r.text[:1000])
                result=r.json()
        elif req.tool == "environment_read":
            if not ENVIRONMENT_CONTEXT_API_KEY: raise HTTPException(status_code=503,detail="Environment context service is not configured")
            action=str(req.arguments.get("action","snapshot")); paths={"snapshot":"/snapshot","weather":"/weather","home":"/home"}
            if action not in paths: raise HTTPException(status_code=400,detail=f"Unsupported environment action: {action}")
            with httpx.Client(timeout=12) as client:
                r=client.get(ENVIRONMENT_CONTEXT_URL+paths[action],headers={"Authorization":f"Bearer {ENVIRONMENT_CONTEXT_API_KEY}"})
                if r.status_code>=400: raise HTTPException(status_code=r.status_code,detail=r.text[:1000])
                result=r.json()
        elif req.tool in {"home_state_read", "home_action", "environment_routine"}:
            if not HOME_ASSISTANT_GATEWAY_API_KEY: raise HTTPException(status_code=503,detail="Home Assistant gateway is not configured")
            hdr={"Authorization":f"Bearer {HOME_ASSISTANT_GATEWAY_API_KEY}"}
            with httpx.Client(timeout=12) as client:
                if req.tool=="home_state_read":
                    entity=req.arguments.get("entity_id")
                    url=f"{HOME_ASSISTANT_GATEWAY_URL}/states/{entity}" if entity else f"{HOME_ASSISTANT_GATEWAY_URL}/states"
                    r=client.get(url,headers=hdr)
                elif req.tool=="environment_routine":
                    action=str(req.arguments.get("action","preview")); name=str(req.arguments.get("name",""))
                    if not name: raise HTTPException(status_code=400,detail="routine name required")
                    if action=="preview": r=client.get(f"{HOME_ASSISTANT_GATEWAY_URL}/routines/{name}/preview",headers=hdr)
                    elif action=="apply": r=client.post(f"{HOME_ASSISTANT_GATEWAY_URL}/routines/{name}/apply",headers=hdr)
                    else: raise HTTPException(status_code=400,detail=f"Unsupported routine action: {action}")
                else:
                    r=client.post(f"{HOME_ASSISTANT_GATEWAY_URL}/services/call",headers=hdr,json=req.arguments)
                if r.status_code>=400: raise HTTPException(status_code=r.status_code,detail=r.text[:1000])
                result=r.json()
        elif req.tool == "rhythm_read":
            action=str(req.arguments.get("action","dashboard"))
            user_id=str(req.arguments.get("user_id","default"))
            paths={"dashboard":"/dashboard","patterns":"/patterns","cards":"/cards"}
            if action not in paths: raise HTTPException(status_code=400,detail=f"Unsupported rhythm action: {action}")
            params={"user_id":user_id}
            if "days" in req.arguments: params["days"]=int(req.arguments["days"])
            if "limit" in req.arguments: params["limit"]=int(req.arguments["limit"])
            if "anchor" in req.arguments: params["anchor"]=str(req.arguments["anchor"])
            with httpx.Client(timeout=20.0) as client:
                r=client.get(RHYTHM_URL+paths[action],params=params)
                if r.status_code>=400: raise HTTPException(status_code=502,detail=f"Rhythm service error {r.status_code}: {r.text[:1000]}")
                result=r.json()
        elif req.tool in {"proactive_read", "proactive_write"}:
            if not PROACTIVE_API_KEY:
                raise HTTPException(status_code=503, detail="Proactive assistant integration is not configured")
            action = str(req.arguments.get("action", "feed" if req.tool == "proactive_read" else "settings"))
            user_id = str(req.arguments.get("user_id", "default"))
            headers={"Authorization":f"Bearer {PROACTIVE_API_KEY}"}
            read_actions={
                "feed": ("GET", "/feed"),
                "settings": ("GET", "/settings"),
            }
            write_actions={
                "settings": ("PATCH", "/settings"),
                "generate_day": ("POST", "/generate/day"),
                "generate_week": ("POST", "/generate/week"),
                "delivered": ("POST", "/cards/{card_id}/delivered"),
                "dismiss": ("POST", "/cards/{card_id}/dismiss"),
                "snooze": ("POST", "/cards/{card_id}/snooze"),
                "support_suspend": ("POST", "/support-theme/suspend"),
                "support_resume": ("POST", "/support-theme/resume"),
            }
            allowed=read_actions if req.tool=="proactive_read" else write_actions
            if action not in allowed: raise HTTPException(status_code=400, detail=f"Unsupported proactive action: {action}")
            method,path=allowed[action]; card_id=str(req.arguments.get("card_id", ""))
            if "{card_id}" in path:
                if not card_id: raise HTTPException(status_code=400, detail="card_id required")
                path=path.replace("{card_id}",card_id)
            payload=dict(req.arguments.get("data") or {}); payload.setdefault("user_id",user_id)
            params={"user_id":user_id}
            if "anchor" in req.arguments: params["anchor"]=str(req.arguments["anchor"])
            if "force" in req.arguments: params["force"]=str(bool(req.arguments["force"])).lower()
            with httpx.Client(timeout=60.0) as client:
                if method=="GET": r=client.get(PROACTIVE_URL+path,headers=headers,params=params)
                elif method=="PATCH": r=client.patch(PROACTIVE_URL+path,headers=headers,json=payload)
                else: r=client.post(PROACTIVE_URL+path,headers=headers,json=payload if action in {"snooze","support_suspend"} else None,params=params if action.startswith("generate_") or action=="support_resume" else None)
                if r.status_code>=400: raise HTTPException(status_code=502, detail=f"Proactive service error {r.status_code}: {r.text[:1000]}")
                result=r.json()
        elif req.tool == "shell_exec":
            if klass not in {"CONTROLLED","APPROVAL_REQUIRED"}: raise HTTPException(status_code=403, detail="shell_exec must be controlled")
            command=req.arguments.get("command")
            argv=shlex.split(command) if isinstance(command,str) else list(command or [])
            if not argv or Path(argv[0]).name not in SHELL_ALLOW: raise HTTPException(status_code=403, detail="Executable is not in controlled-command allowlist")
            cwd=resolve_scoped(agent, str(req.arguments.get("cwd", (agent.get('workspace') or {}).get('root','/workspaces'))), True)
            timeout=min(int(req.arguments.get("timeout",30)),120)
            proc=subprocess.Popen(argv,cwd=cwd,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env={"PATH":os.environ.get("PATH","")},start_new_session=True)
            try:
                stdout,stderr=proc.communicate(timeout=timeout)
            except subprocess.TimeoutExpired:
                try: os.killpg(proc.pid, signal.SIGTERM)
                except ProcessLookupError: pass
                try: stdout,stderr=proc.communicate(timeout=3)
                except subprocess.TimeoutExpired:
                    try: os.killpg(proc.pid, signal.SIGKILL)
                    except ProcessLookupError: pass
                    stdout,stderr=proc.communicate()
                event(req.task_id, req.agent_id, req.tool, klass, req.approved, False, f"command timeout after {timeout}s; process group terminated")
                raise HTTPException(status_code=504, detail={"error":"command_timeout","hint":"The command exceeded its bounded runtime and its process group was terminated. Reduce the operation or split it into smaller steps."})
            result={"argv":argv,"returncode":proc.returncode,"stdout":stdout[-20000:],"stderr":stderr[-20000:]}
        else:
            raise HTTPException(status_code=400, detail="Tool not implemented by this runtime")
        compact_default = req.tool.endswith("_read") or req.tool in {"web_fetch","file_read","file_search","file_find","current_state_read","briefing_read"}
        if bool(req.arguments.get("compact_result", compact_default)):
            result=compact_tool_payload(result,max_items=min(int(req.arguments.get("max_result_items",20)),100),max_string=min(int(req.arguments.get("max_result_string",2500)),10000))
        post = run_hooks("post", req.tool, req.arguments)
        event(req.task_id, req.agent_id, req.tool, klass, req.approved, True, json.dumps({"pre":pre,"post":post}))
        return {"status":"ok","tool":req.tool,"policy_class":klass,"mode":req.mode,"guardrail":guardrail,"hooks":{"pre":pre,"post":post},"result":result}
    except HTTPException:
        raise
    except Exception as exc:
        event(req.task_id, req.agent_id, req.tool, klass, req.approved, False, str(exc))
        raise HTTPException(status_code=500, detail=str(exc)) from exc



# v3.7.0 Context, Memory Trust & Decision Intelligence
class DecisionRequest(BaseModel):
    text:str
    known:dict[str,Any]=Field(default_factory=dict)
    required_fields:list[str]=Field(default_factory=list)
class TrustedMemoryUpsert(BaseModel):
    user_id:str
    text:str
    source_type:str="agent_inference"
    source_id:str|None=None
    confidence:float=0.5
    importance:float=0.5
    entity_ids:list[str]=Field(default_factory=list)
    valid_from:str|None=None
    valid_until:str|None=None
    supersedes:str|None=None
class EntityUpsert(BaseModel):
    user_id:str
    entity_id:str
    kind:str
    canonical_name:str
    aliases:list[str]=Field(default_factory=list)
class ContextBudgetRequest(BaseModel):
    total_chars:int=12000
    sections:dict[str,int]=Field(default_factory=dict)
class ToolSurfaceRequest(BaseModel):
    agent_id:str
    mode:str="default"
    task_text:str=""
    healthy_tools:list[str]=Field(default_factory=list)
    max_tools:int=6

def _v370_init():
    with db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS trusted_memories(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,text TEXT NOT NULL,source_type TEXT NOT NULL,source_id TEXT,trust REAL NOT NULL,confidence REAL NOT NULL,importance REAL NOT NULL,entity_ids_json TEXT NOT NULL DEFAULT '[]',valid_from TEXT,valid_until TEXT,superseded_by TEXT,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS memory_entities(entity_id TEXT PRIMARY KEY,user_id TEXT NOT NULL,kind TEXT NOT NULL,canonical_name TEXT NOT NULL,aliases_json TEXT NOT NULL DEFAULT '[]',created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS decision_events(id TEXT PRIMARY KEY,decision TEXT NOT NULL,missing_json TEXT NOT NULL DEFAULT '[]',detail_json TEXT NOT NULL DEFAULT '{}',created_at TEXT NOT NULL);
        """)
_v370_init()

def _memory_trust(source_type:str)->float:
    return {"user_statement":1.0,"verified_service":0.95,"structured_profile":0.9,"agent_verified":0.8,"agent_inference":0.55,"document":0.5,"email":0.45,"web":0.25,"llm_generated":0.15}.get(source_type,0.4)

def _decision_gate(text:str,known:dict[str,Any],required:list[str])->dict[str,Any]:
    missing=[x for x in required if known.get(x) in {None,"",[]}]
    ambiguous=bool(re.search(r"\b(someone|sometime|later|next week|one of|that person|it)\b",text.casefold()))
    decision="ASK" if missing or ambiguous else ("REQUIRE_APPROVAL" if re.search(r"\b(delete|remove|send|purchase|pay|unlock|shutdown)\b",text.casefold()) else "ACT")
    return {"decision":decision,"missing":missing,"ambiguous":ambiguous}

@app.post('/decision/evaluate',dependencies=[Depends(auth)])
def decision_evaluate(req:DecisionRequest):
    result=_decision_gate(req.text,req.known,req.required_fields); rid=str(uuid.uuid4())
    with db() as conn: conn.execute("INSERT INTO decision_events(id,decision,missing_json,detail_json,created_at) VALUES(?,?,?,?,?)",(rid,result['decision'],json.dumps(result['missing']),json.dumps(result),now()))
    return {"id":rid,**result}

@app.post('/memory/trusted',dependencies=[Depends(auth)])
def trusted_memory_upsert(req:TrustedMemoryUpsert):
    mid=str(uuid.uuid4());ts=now();trust=_memory_trust(req.source_type)
    with db() as conn:
        conn.execute("INSERT INTO trusted_memories(id,user_id,text,source_type,source_id,trust,confidence,importance,entity_ids_json,valid_from,valid_until,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",(mid,req.user_id,req.text,req.source_type,req.source_id,trust,max(0,min(req.confidence,1)),max(0,min(req.importance,1)),json.dumps(req.entity_ids),req.valid_from,req.valid_until,ts,ts))
        if req.supersedes: conn.execute("UPDATE trusted_memories SET superseded_by=?,updated_at=? WHERE id=? AND user_id=?",(mid,ts,req.supersedes,req.user_id))
    return {"id":mid,"trust":trust,"status":"active"}

@app.get('/memory/trusted/rank',dependencies=[Depends(auth)])
def trusted_memory_rank(user_id:str,query:str,limit:int=10):
    terms=set(re.findall(r'[a-z0-9]+',query.casefold())); rows=[]
    with db() as conn:
        for r in conn.execute("SELECT * FROM trusted_memories WHERE user_id=? AND superseded_by IS NULL ORDER BY updated_at DESC LIMIT 500",(user_id,)):
            d=dict(r)
            if not _memory_is_current(d):continue
            words=set(re.findall(r'[a-z0-9]+',d['text'].casefold())); exact=len(terms&words)/max(1,len(terms)); score=.35*exact+.25*d['trust']+.2*d['confidence']+.2*d['importance'];d['score']=round(score,4);rows.append(d)
    rows.sort(key=lambda x:(x['score'],x['updated_at']),reverse=True);return {"query":query,"results":rows[:max(1,min(limit,50))]}

@app.post('/entities',dependencies=[Depends(auth)])
def entity_upsert(req:EntityUpsert):
    ts=now()
    with db() as conn:conn.execute("INSERT INTO memory_entities(entity_id,user_id,kind,canonical_name,aliases_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(entity_id) DO UPDATE SET kind=excluded.kind,canonical_name=excluded.canonical_name,aliases_json=excluded.aliases_json,updated_at=excluded.updated_at",(req.entity_id,req.user_id,req.kind,req.canonical_name,json.dumps(req.aliases),ts,ts))
    return {"entity_id":req.entity_id,"aliases":req.aliases}

@app.get('/entities/resolve',dependencies=[Depends(auth)])
def entity_resolve(user_id:str,text:str):
    q=text.casefold().strip();matches=[]
    with db() as conn:
        for r in conn.execute("SELECT * FROM memory_entities WHERE user_id=?",(user_id,)):
            d=dict(r); names=[d['canonical_name'],*json.loads(d['aliases_json'])];score=max((1.0 if q==str(n).casefold() else .7 if q in str(n).casefold() or str(n).casefold() in q else 0) for n in names); 
            if score:matches.append({"entity_id":d['entity_id'],"canonical_name":d['canonical_name'],"kind":d['kind'],"score":score})
    return {"query":text,"matches":sorted(matches,key=lambda x:x['score'],reverse=True)}

@app.post('/context/budget',dependencies=[Depends(auth)])
def context_budget(req:ContextBudgetRequest):
    defaults={"policy":1200,"current_state":2200,"durable_memory":1600,"session_history":1400,"skills":800,"tool_results":2800,"reserve":2000}; alloc={**defaults,**req.sections}; scale=min(1.0,req.total_chars/max(1,sum(alloc.values())));alloc={k:max(128,int(v*scale)) for k,v in alloc.items()};return {"total_chars":req.total_chars,"allocation":alloc,"allocated":sum(alloc.values())}

@app.post('/tools/surface',dependencies=[Depends(auth)])
def tool_surface(req:ToolSurfaceRequest):
    skills=_match_skills(req.task_text,req.agent_id,5)
    return _compile_tool_surface(req.agent_id,req.mode,req.task_text,skills,{},req.max_tools,req.healthy_tools)

@app.get('/prompt/audit',dependencies=[Depends(auth)])
def prompt_audit(agent_id:str):
    text=_agent_system_prompt(agent_id); lines=[x.strip() for x in text.splitlines() if x.strip()];seen=set();dupes=[]
    for line in lines:
        key=re.sub(r'\s+',' ',line.casefold())
        if key in seen:dupes.append(line)
        seen.add(key)
    deterministic=[x for x in lines if any(w in x.casefold() for w in ['permission','tool policy','approval','guardrail'])]
    return {"agent_id":agent_id,"chars":len(text),"duplicate_lines":dupes[:20],"possible_deterministic_duplicates":deterministic[:20]}




# v3.8.0 Parallel Workers, Resource Admission & Sandbox Policy
class FanoutRequest(BaseModel):
    agent_id:str
    items:list[dict[str,Any]]
    schema_fields:list[str]=Field(default_factory=list)
    max_parallel:int=4
    model_role:str="fast-local"
    execute_model:bool=False
    prompt_field:str="prompt"
    max_tokens:int=800
class ResourceAdmissionRequest(BaseModel):
    model_role:str
    estimated_vram_mb:int=0
    priority:int=50
    available_vram_mb:int=0
    gpu_busy:bool=False
class SandboxPolicyRequest(BaseModel):
    agent_id:str
    mode:str='default'
    requested_hosts:list[str]=Field(default_factory=list)
    writable_paths:list[str]=Field(default_factory=list)

def _v380_init():
    with db() as conn:conn.executescript("""
    CREATE TABLE IF NOT EXISTS fanout_batches(id TEXT PRIMARY KEY,agent_id TEXT NOT NULL,status TEXT NOT NULL,schema_json TEXT NOT NULL,items_json TEXT NOT NULL,result_json TEXT NOT NULL DEFAULT '{}',created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS resource_admissions(id TEXT PRIMARY KEY,model_role TEXT NOT NULL,decision TEXT NOT NULL,detail_json TEXT NOT NULL,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS verification_events(id TEXT PRIMARY KEY,job_id TEXT,kind TEXT NOT NULL,verified INTEGER NOT NULL,detail_json TEXT NOT NULL,created_at TEXT NOT NULL);
    """)
_v380_init()

@app.post('/workers/fanout',dependencies=[Depends(auth)])
def workers_fanout(req:FanoutRequest):
    bid=str(uuid.uuid4());ts=now();items=req.items[:100];records=[]
    for idx,item in enumerate(items):
        missing=[f for f in req.schema_fields if f not in item];records.append({"index":idx,"valid":not missing,"missing":missing,"record":item})
    valid=[x for x in records if x['valid']]
    admission=_admit_model_role(req.model_role,50,req.max_parallel) if req.execute_model else {"decision":"ADMIT","admitted_parallel":max(1,min(req.max_parallel,8)),"reason":"validation_only"}
    if admission.get("decision")!="ADMIT":
        result={"records":[],"invalid":len(records)-len(valid),"merge":"deterministic","status":admission.get("decision"),"resource_admission":admission}
        with db() as conn:conn.execute("INSERT INTO fanout_batches(id,agent_id,status,schema_json,items_json,result_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",(bid,req.agent_id,str(admission.get('decision')).lower(),json.dumps(req.schema_fields),json.dumps(items),json.dumps(compact_tool_payload(result)),ts,now()))
        return {"id":bid,**result}
    if not req.execute_model:
        merged=[x['record'] for x in valid];result={"records":merged,"invalid":len(records)-len(valid),"merge":"deterministic","max_parallel":admission.get("admitted_parallel",1),"resource_admission":admission}
    else:
        parallel=max(1,int(admission.get("admitted_parallel") or 1));outputs=[None]*len(valid)
        def run_one(pair):
            pos,row=pair; item=row['record']; prompt=str(item.get(req.prompt_field) or "").strip()
            if not prompt:return pos,{"index":row['index'],"status":"invalid","error":"missing_prompt","input":item}
            schema={k:"required" for k in req.schema_fields}
            alias,data=_call_litellm(req.model_role,[{"role":"system","content":"You are a bounded parallel worker. Return JSON only. Do not execute tools. Produce an independent result for this item."},{"role":"user","content":json.dumps({"item":item,"required_fields":schema},ensure_ascii=False)}],0.1,max(100,min(req.max_tokens,2000)))
            missing=[f for f in req.schema_fields if f not in data]
            return pos,{"index":row['index'],"status":"complete" if not missing else "schema_invalid","model":alias,"missing":missing,"result":data}
        with ThreadPoolExecutor(max_workers=parallel,thread_name_prefix="agent-fanout") as ex:
            futures=[ex.submit(run_one,(pos,row)) for pos,row in enumerate(valid)]
            for fut in as_completed(futures):
                try: pos,out=fut.result();outputs[pos]=out
                except Exception as exc:
                    # preserve deterministic slot ordering even when a worker fails
                    for i,x in enumerate(outputs):
                        if x is None: outputs[i]={"status":"failed","error":type(exc).__name__};break
        result={"records":outputs,"invalid":len(records)-len(valid),"merge":"deterministic_index_order","max_parallel":parallel,"resource_admission":admission}
    with db() as conn:conn.execute("INSERT INTO fanout_batches(id,agent_id,status,schema_json,items_json,result_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",(bid,req.agent_id,'complete',json.dumps(req.schema_fields),json.dumps(items),json.dumps(compact_tool_payload(result)),ts,now()))
    return {"id":bid,**result}

@app.post('/resources/admit',dependencies=[Depends(auth)])
def resources_admit(req:ResourceAdmissionRequest):
    if req.estimated_vram_mb or req.available_vram_mb or req.gpu_busy:
        available=max(0,int(req.available_vram_mb)-AGENT_RESOURCE_HEADROOM_MB) if req.available_vram_mb else 0
        if req.estimated_vram_mb and req.available_vram_mb and req.estimated_vram_mb>available:decision='WAITING_RESOURCE'
        elif req.gpu_busy and req.priority>30:decision='WAITING_RESOURCE'
        else:decision='ADMIT'
        detail={"model_role":req.model_role,"estimated_vram_mb":req.estimated_vram_mb,"available_vram_mb":req.available_vram_mb,"headroom_mb":AGENT_RESOURCE_HEADROOM_MB,"gpu_busy":req.gpu_busy,"priority":req.priority,"source":"explicit_request"};detail['id']=_record_resource_admission(req.model_role,decision,detail);return {"decision":decision,**detail}
    return _admit_model_role(req.model_role,req.priority,1)

@app.post('/sandbox/policy',dependencies=[Depends(auth)])
def sandbox_policy(req:SandboxPolicyRequest):
    manifest=load_agent(req.agent_id); allowed_hosts=set((manifest.get('network') or {}).get('allowed_hosts') or []); hosts=[h for h in req.requested_hosts if h in allowed_hosts]
    root=(WORKSPACES/'agents'/req.agent_id).resolve();paths=[]
    for raw in req.writable_paths:
        try:
            p=(root/raw).resolve()
            if p==root or root in p.parents:paths.append(str(p.relative_to(root)))
        except Exception:pass
    return {"agent_id":req.agent_id,"rootless_required":True,"docker_socket":False,"network_default":"deny","allowed_hosts":hosts,"writable_paths":paths,"egress_audit":True}

@app.post('/verification/record',dependencies=[Depends(auth)])
def verification_record(payload:dict[str,Any]):
    vid=str(uuid.uuid4());verified=bool(payload.get('verified'));kind=str(payload.get('kind') or 'generic')
    with db() as conn:conn.execute("INSERT INTO verification_events(id,job_id,kind,verified,detail_json,created_at) VALUES(?,?,?,?,?,?)",(vid,payload.get('job_id'),kind,int(verified),json.dumps(payload),now()))
    return {"id":vid,"status":"COMPLETE" if verified else "UNVERIFIED"}

@app.get('/projects/navigation-index',dependencies=[Depends(auth)])
def navigation_index():
    roots={'install':['install.sh','docs/getting-started'],'agents':['opt/ai-proxy/agent-runtime','opt/ai-proxy/agents'],'memory':['opt/ai-proxy/mem0-service','opt/ai-proxy/life-profile-service'],'operations':['docs/operations','usr/local/bin']}
    return {"version":1,"tasks":roots,"purpose":"compact task-to-path navigation before deep file reads"}




# v3.9.0 Proactive Event Intelligence & Trigger Correlation
class EventRuleUpsert(BaseModel):
    rule_id:str
    event_type:str
    target_agent:str
    contains:list[str]=Field(default_factory=list)
    cooldown_seconds:int=300
    priority:int=50
    enabled:bool=True
class CorrelateRequest(BaseModel):
    event_type:str
    source:str
    subject:str=''
    payload:dict[str,Any]=Field(default_factory=dict)
    occurred_at:str|None=None

def _v390_init():
    with db() as conn:conn.executescript("""
    CREATE TABLE IF NOT EXISTS event_rules(rule_id TEXT PRIMARY KEY,event_type TEXT NOT NULL,target_agent TEXT NOT NULL,contains_json TEXT NOT NULL,cooldown_seconds INTEGER NOT NULL,priority INTEGER NOT NULL,enabled INTEGER NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS event_correlations(id TEXT PRIMARY KEY,fingerprint TEXT NOT NULL,event_type TEXT NOT NULL,source TEXT NOT NULL,subject TEXT,decision TEXT NOT NULL,matched_rules_json TEXT NOT NULL,created_at TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_event_correlations_fp ON event_correlations(fingerprint,created_at);
    """)
_v390_init()

@app.post('/events/rules',dependencies=[Depends(auth)])
def event_rule_upsert(req:EventRuleUpsert):
    ts=now()
    with db() as conn:conn.execute("INSERT INTO event_rules(rule_id,event_type,target_agent,contains_json,cooldown_seconds,priority,enabled,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(rule_id) DO UPDATE SET event_type=excluded.event_type,target_agent=excluded.target_agent,contains_json=excluded.contains_json,cooldown_seconds=excluded.cooldown_seconds,priority=excluded.priority,enabled=excluded.enabled,updated_at=excluded.updated_at",(req.rule_id,req.event_type,req.target_agent,json.dumps(req.contains),req.cooldown_seconds,req.priority,int(req.enabled),ts,ts))
    return {"rule_id":req.rule_id,"enabled":req.enabled}

@app.get('/events/rules',dependencies=[Depends(auth)])
def event_rules():
    with db() as conn:return {"rules":[{**dict(r),"contains":json.loads(r['contains_json'])} for r in conn.execute("SELECT * FROM event_rules ORDER BY priority,rule_id")]}

@app.post('/events/correlate',dependencies=[Depends(auth)])
def events_correlate(req:CorrelateRequest):
    normalized=json.dumps(req.payload,sort_keys=True,separators=(',',':'));fp=hashlib.sha256(f"{req.event_type}|{req.source}|{req.subject}|{normalized}".encode()).hexdigest();matched=[];ts=datetime.now(timezone.utc)
    with db() as conn:
        rules=[dict(r) for r in conn.execute("SELECT * FROM event_rules WHERE enabled=1 AND event_type=? ORDER BY priority",(req.event_type,))]
        recent=conn.execute("SELECT created_at FROM event_correlations WHERE fingerprint=? ORDER BY created_at DESC LIMIT 1",(fp,)).fetchone()
        for rule in rules:
            needles=json.loads(rule['contains_json']);hay=(req.subject+' '+normalized).casefold()
            if all(str(n).casefold() in hay for n in needles):matched.append({"rule_id":rule['rule_id'],"target_agent":rule['target_agent'],"priority":rule['priority'],"cooldown_seconds":rule['cooldown_seconds']})
        duplicate=False
        if recent and matched:
            try:age=(ts-datetime.fromisoformat(recent['created_at'])).total_seconds();duplicate=age<min(x['cooldown_seconds'] for x in matched)
            except Exception:pass
        decision='SUPPRESS_DUPLICATE' if duplicate else ('ROUTE' if matched else 'IGNORE');cid=str(uuid.uuid4());conn.execute("INSERT INTO event_correlations(id,fingerprint,event_type,source,subject,decision,matched_rules_json,created_at) VALUES(?,?,?,?,?,?,?,?)",(cid,fp,req.event_type,req.source,req.subject,decision,json.dumps(matched),ts.isoformat()))
    return {"id":cid,"fingerprint":fp,"decision":decision,"matched_rules":matched}

@app.get('/proactive/readiness',dependencies=[Depends(auth)])
def proactive_readiness():
    with db() as conn:
        rules=conn.execute("SELECT COUNT(*) FROM event_rules WHERE enabled=1").fetchone()[0];recent=conn.execute("SELECT decision,COUNT(*) c FROM event_correlations WHERE created_at>=? GROUP BY decision",((datetime.now(timezone.utc)-timedelta(hours=24)).isoformat(),)).fetchall()
    return {"enabled_rules":rules,"last_24h":{r['decision']:r['c'] for r in recent},"quiet_hours_enforced_by":"proactive-assistant","notifications":"notification-service"}




# v3.10.0 Multi-Node Agent Fabric & Execution Placement
class NodeRegister(BaseModel):
    node_id:str
    capabilities:list[str]=Field(default_factory=list)
    model_roles:list[str]=Field(default_factory=list)
    gpu_vram_mb:int=0
    available_vram_mb:int=0
    labels:dict[str,str]=Field(default_factory=dict)
    accepting_jobs:bool=True
class PlacementRequest(BaseModel):
    required_capabilities:list[str]=Field(default_factory=list)
    model_role:str|None=None
    estimated_vram_mb:int=0
    preferred_node:str|None=None

def _v3100_init():
    with db() as conn:conn.executescript("""
    CREATE TABLE IF NOT EXISTS fabric_nodes(node_id TEXT PRIMARY KEY,capabilities_json TEXT NOT NULL,model_roles_json TEXT NOT NULL,gpu_vram_mb INTEGER NOT NULL,available_vram_mb INTEGER NOT NULL,labels_json TEXT NOT NULL,accepting_jobs INTEGER NOT NULL,state TEXT NOT NULL,last_heartbeat TEXT NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS placement_decisions(id TEXT PRIMARY KEY,node_id TEXT,decision TEXT NOT NULL,requirements_json TEXT NOT NULL,score REAL NOT NULL,created_at TEXT NOT NULL);
    """)
_v3100_init()

def _local_node_bootstrap():
    ts=now()
    with db() as conn:conn.execute("INSERT INTO fabric_nodes(node_id,capabilities_json,model_roles_json,gpu_vram_mb,available_vram_mb,labels_json,accepting_jobs,state,last_heartbeat,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(node_id) DO NOTHING",(AGENT_NODE_ID,json.dumps(['agent-runtime','local-tools','memory','scheduler']),json.dumps(list(model_roles().keys())),0,0,json.dumps({'class':'primary'}),1,'online',ts,ts,ts))
_local_node_bootstrap()

@app.post('/fabric/nodes/register',dependencies=[Depends(auth)])
def node_register(req:NodeRegister):
    ts=now()
    with db() as conn:conn.execute("INSERT INTO fabric_nodes(node_id,capabilities_json,model_roles_json,gpu_vram_mb,available_vram_mb,labels_json,accepting_jobs,state,last_heartbeat,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(node_id) DO UPDATE SET capabilities_json=excluded.capabilities_json,model_roles_json=excluded.model_roles_json,gpu_vram_mb=excluded.gpu_vram_mb,available_vram_mb=excluded.available_vram_mb,labels_json=excluded.labels_json,accepting_jobs=excluded.accepting_jobs,state='online',last_heartbeat=excluded.last_heartbeat,updated_at=excluded.updated_at",(req.node_id,json.dumps(req.capabilities),json.dumps(req.model_roles),req.gpu_vram_mb,req.available_vram_mb,json.dumps(req.labels),int(req.accepting_jobs),'online',ts,ts,ts))
    return {"node_id":req.node_id,"state":"online"}

@app.get('/fabric/nodes',dependencies=[Depends(auth)])
def fabric_nodes(stale_seconds:int=90):
    cutoff=datetime.now(timezone.utc)-timedelta(seconds=stale_seconds);out=[]
    with db() as conn:
        for r in conn.execute("SELECT * FROM fabric_nodes ORDER BY node_id"):
            d=dict(r);d['capabilities']=json.loads(d.pop('capabilities_json'));d['model_roles']=json.loads(d.pop('model_roles_json'));d['labels']=json.loads(d.pop('labels_json'));d['state']='stale' if datetime.fromisoformat(d['last_heartbeat'])<cutoff else d['state'];out.append(d)
    return {"nodes":out}

@app.post('/fabric/place',dependencies=[Depends(auth)])
def fabric_place(req:PlacementRequest):
    candidates=[]
    with db() as conn:
        for r in conn.execute("SELECT * FROM fabric_nodes WHERE accepting_jobs=1"):
            d=dict(r);caps=set(json.loads(d['capabilities_json']));roles=set(json.loads(d['model_roles_json']))
            if not set(req.required_capabilities)<=caps:continue
            if req.model_role and req.model_role not in roles:continue
            if req.estimated_vram_mb and d['available_vram_mb'] and req.estimated_vram_mb>d['available_vram_mb']:continue
            score=(100 if req.preferred_node==d['node_id'] else 0)+(d['available_vram_mb']/1024)+(10 if d['node_id']==AGENT_NODE_ID else 0);candidates.append((score,d['node_id']))
        candidates.sort(reverse=True);node=candidates[0][1] if candidates else None;decision='PLACE' if node else 'WAITING_RESOURCE';pid=str(uuid.uuid4());score=candidates[0][0] if candidates else 0;conn.execute("INSERT INTO placement_decisions(id,node_id,decision,requirements_json,score,created_at) VALUES(?,?,?,?,?,?)",(pid,node,decision,json.dumps(req.model_dump()),score,now()))
    return {"id":pid,"decision":decision,"node_id":node,"score":score}




# v3.11.0 Reliability, Observability & Self-Healing
class HealthSignal(BaseModel):
    component:str
    ok:bool
    latency_ms:float|None=None
    detail:dict[str,Any]=Field(default_factory=dict)
class RecoveryPolicy(BaseModel):
    component:str
    action:str
    max_attempts:int=3
    cooldown_seconds:int=300
    enabled:bool=True

def _v3110_init():
    with db() as conn:conn.executescript("""
    CREATE TABLE IF NOT EXISTS health_signals(id TEXT PRIMARY KEY,component TEXT NOT NULL,ok INTEGER NOT NULL,latency_ms REAL,detail_json TEXT NOT NULL,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS recovery_policies(component TEXT PRIMARY KEY,action TEXT NOT NULL,max_attempts INTEGER NOT NULL,cooldown_seconds INTEGER NOT NULL,enabled INTEGER NOT NULL,updated_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS recovery_events(id TEXT PRIMARY KEY,component TEXT NOT NULL,action TEXT NOT NULL,decision TEXT NOT NULL,detail_json TEXT NOT NULL,created_at TEXT NOT NULL);
    """)
_v3110_init()

@app.post('/reliability/signal',dependencies=[Depends(auth)])
def reliability_signal(req:HealthSignal):
    sid=str(uuid.uuid4())
    with db() as conn:conn.execute("INSERT INTO health_signals(id,component,ok,latency_ms,detail_json,created_at) VALUES(?,?,?,?,?,?)",(sid,req.component,int(req.ok),req.latency_ms,json.dumps(req.detail),now()))
    return {"id":sid,"recorded":True}

@app.post('/reliability/policies',dependencies=[Depends(auth)])
def recovery_policy(req:RecoveryPolicy):
    with db() as conn:conn.execute("INSERT INTO recovery_policies(component,action,max_attempts,cooldown_seconds,enabled,updated_at) VALUES(?,?,?,?,?,?) ON CONFLICT(component) DO UPDATE SET action=excluded.action,max_attempts=excluded.max_attempts,cooldown_seconds=excluded.cooldown_seconds,enabled=excluded.enabled,updated_at=excluded.updated_at",(req.component,req.action,req.max_attempts,req.cooldown_seconds,int(req.enabled),now()))
    return {"component":req.component,"enabled":req.enabled}

@app.get('/reliability/summary',dependencies=[Depends(auth)])
def reliability_summary(hours:int=24):
    cutoff=(datetime.now(timezone.utc)-timedelta(hours=max(1,min(hours,168)))).isoformat();components={}
    with db() as conn:
        for r in conn.execute("SELECT component,COUNT(*) total,SUM(ok) good,AVG(latency_ms) latency FROM health_signals WHERE created_at>=? GROUP BY component",(cutoff,)):
            total=r['total'];good=r['good'] or 0;components[r['component']]={"samples":total,"availability":round(good/max(1,total),4),"avg_latency_ms":round(r['latency'] or 0,2)}
        jobs={r['status']:r['c'] for r in conn.execute("SELECT status,COUNT(*) c FROM agent_jobs GROUP BY status")}
    return {"window_hours":hours,"components":components,"jobs":jobs,"node_id":AGENT_NODE_ID}

@app.post('/reliability/recover/{component}',dependencies=[Depends(auth)])
def reliability_recover(component:str):
    with db() as conn:
        p=conn.execute("SELECT * FROM recovery_policies WHERE component=? AND enabled=1",(component,)).fetchone()
        if not p:return {"component":component,"decision":"NO_POLICY"}
        recent=conn.execute("SELECT COUNT(*) FROM recovery_events WHERE component=? AND created_at>=?",(component,(datetime.now(timezone.utc)-timedelta(seconds=p['cooldown_seconds'])).isoformat())).fetchone()[0]
        decision='COOLDOWN' if recent else 'AUTHORIZED_REPAIR_REQUIRED';rid=str(uuid.uuid4());detail={"action":p['action'],"max_attempts":p['max_attempts'],"note":"Agent Runtime records and authorizes recovery intent; host maintenance utility performs privileged repair."};conn.execute("INSERT INTO recovery_events(id,component,action,decision,detail_json,created_at) VALUES(?,?,?,?,?,?)",(rid,component,p['action'],decision,json.dumps(detail),now()))
    return {"id":rid,"component":component,"decision":decision,**detail}

@app.get('/reliability/audit',dependencies=[Depends(auth)])
def reliability_audit(limit:int=100):
    with db() as conn:
        rec=[dict(r) for r in conn.execute("SELECT * FROM recovery_events ORDER BY created_at DESC LIMIT ?",(max(1,min(limit,500)),))];ver=[dict(r) for r in conn.execute("SELECT * FROM verification_events ORDER BY created_at DESC LIMIT ?",(max(1,min(limit,500)),))]
    return {"recovery_events":rec,"verification_events":ver,"principle":"no silent success; unverified actions remain unverified"}


# v3.15.2 multi-turn pending action control plane ----------------------------------
class PendingActionCreate(BaseModel):
    user_id: str
    chat_id: str
    action_type: str
    state: dict[str, Any] = Field(default_factory=dict)
    required_fields: list[str] = Field(default_factory=list)
    ttl_seconds: int = Field(default=7200, ge=60, le=86400)

class PendingActionPatch(BaseModel):
    state: dict[str, Any] | None = None
    required_fields: list[str] | None = None
    status: str | None = None
    ttl_seconds: int | None = Field(default=None, ge=60, le=86400)

def _pending_row(row):
    if not row:
        return None
    d=dict(row)
    d['state']=json.loads(d.pop('state_json') or '{}')
    d['required_fields']=json.loads(d.pop('required_fields_json') or '[]')
    return d

@app.get('/pending-actions', dependencies=[Depends(auth)])
def pending_list(user_id: str, status: str = 'pending', limit: int = 50):
    stamp=now()
    with db() as conn:
        conn.execute("UPDATE pending_actions SET status='expired',updated_at=? WHERE status='pending' AND expires_at<=?",(stamp,stamp))
        rows=conn.execute("SELECT * FROM pending_actions WHERE user_id=? AND status=? ORDER BY updated_at DESC LIMIT ?",(user_id,status,max(1,min(limit,200)))).fetchall()
    return {'status':'ok','pending_actions':[_pending_row(r) for r in rows]}

@app.get('/pending-actions/current', dependencies=[Depends(auth)])
def pending_current(user_id: str, chat_id: str):
    stamp=now()
    with db() as conn:
        conn.execute("UPDATE pending_actions SET status='expired',updated_at=? WHERE status='pending' AND expires_at<=?",(stamp,stamp))
        row=conn.execute("SELECT * FROM pending_actions WHERE user_id=? AND chat_id=? AND status='pending' ORDER BY updated_at DESC LIMIT 1",(user_id,chat_id)).fetchone()
    return {'status':'ok','pending':_pending_row(row)}

@app.post('/pending-actions', dependencies=[Depends(auth)])
def pending_create(req: PendingActionCreate):
    stamp=now(); expires=(datetime.now(timezone.utc)+timedelta(seconds=req.ttl_seconds)).isoformat(); pid=str(uuid.uuid4())
    with db() as conn:
        conn.execute("UPDATE pending_actions SET status='superseded',updated_at=? WHERE user_id=? AND chat_id=? AND status='pending'",(stamp,req.user_id,req.chat_id))
        conn.execute("INSERT INTO pending_actions(id,user_id,chat_id,action_type,status,state_json,required_fields_json,created_at,updated_at,expires_at) VALUES(?,?,?,?,?,?,?,?,?,?)",(pid,req.user_id,req.chat_id,req.action_type,'pending',json.dumps(req.state),json.dumps(req.required_fields),stamp,stamp,expires))
        row=conn.execute("SELECT * FROM pending_actions WHERE id=?",(pid,)).fetchone()
    return {'status':'ok','pending':_pending_row(row)}

@app.patch('/pending-actions/{pending_id}', dependencies=[Depends(auth)])
def pending_patch(pending_id: str, req: PendingActionPatch):
    with db() as conn:
        row=conn.execute("SELECT * FROM pending_actions WHERE id=?",(pending_id,)).fetchone()
        if not row: raise HTTPException(404,'pending action not found')
        state=json.loads(row['state_json'] or '{}') if req.state is None else req.state
        fields=json.loads(row['required_fields_json'] or '[]') if req.required_fields is None else req.required_fields
        status=req.status or row['status']; expires=row['expires_at']
        if req.ttl_seconds is not None: expires=(datetime.now(timezone.utc)+timedelta(seconds=req.ttl_seconds)).isoformat()
        stamp=now(); conn.execute("UPDATE pending_actions SET state_json=?,required_fields_json=?,status=?,updated_at=?,expires_at=? WHERE id=?",(json.dumps(state),json.dumps(fields),status,stamp,expires,pending_id))
        out=conn.execute("SELECT * FROM pending_actions WHERE id=?",(pending_id,)).fetchone()
    return {'status':'ok','pending':_pending_row(out)}

@app.delete('/pending-actions/{pending_id}', dependencies=[Depends(auth)])
def pending_cancel(pending_id: str):
    stamp=now()
    with db() as conn:
        cur=conn.execute("UPDATE pending_actions SET status='cancelled',updated_at=? WHERE id=? AND status='pending'",(stamp,pending_id))
    return {'status':'ok','cancelled':bool(cur.rowcount)}

# v3.15.0 unified read control plane -------------------------------------------------
class ReadResolveRequest(BaseModel):
    user_id: str
    resource: str
    query: str = ""
    agent_id: str = "general"
    params: dict[str, Any] = Field(default_factory=dict)

@app.post('/reads/resolve', dependencies=[Depends(auth)])
def read_resolve(req: ReadResolveRequest):
    """Resolve bounded authoritative reads without forcing an LLM reasoning run."""
    resource = req.resource.strip().casefold()
    if resource == 'memory.projects':
        if not MEM0_API_KEY:
            raise HTTPException(503, 'memory service key not configured')
        headers = {'Authorization': f'Bearer {MEM0_API_KEY}'}
        try:
            with httpx.Client(timeout=10) as client:
                try:
                    client.post(MEM0_URL + '/projects/reconcile', headers=headers, json={
                        'user_id': req.user_id, 'agent_id': req.agent_id, 'dry_run': False,
                    })
                except Exception:
                    pass
                r = client.get(MEM0_URL + '/projects', headers=headers, params={
                    'user_id': req.user_id, 'agent_id': req.agent_id,
                })
                r.raise_for_status()
                projects = (r.json() or {}).get('projects', [])
            return {'status': 'ok', 'disposition': 'READ', 'resource': 'memory.projects', 'authoritative': True, 'result_count': len(projects), 'projects': projects}
        except httpx.HTTPError as exc:
            raise HTTPException(502, f'memory project read failed: {type(exc).__name__}')
    if resource == 'memory.project_current':
        if not MEM0_API_KEY:
            raise HTTPException(503, 'memory service key not configured')
        headers = {'Authorization': f'Bearer {MEM0_API_KEY}'}
        try:
            with httpx.Client(timeout=10) as client:
                r = client.get(MEM0_URL + '/projects', headers=headers, params={'user_id': req.user_id, 'agent_id': req.agent_id})
                r.raise_for_status()
                projects = (r.json() or {}).get('projects', [])
            current = [p for p in projects if isinstance(p, dict) and str(p.get('status') or 'active') == 'active' and p.get('is_current')]
            return {'status': 'ok', 'disposition': 'READ', 'resource': 'memory.project_current', 'authoritative': True, 'result_count': len(current), 'projects': current}
        except httpx.HTTPError as exc:
            raise HTTPException(502, f'current project read failed: {type(exc).__name__}')
    if resource in {'schedule.reminders', 'schedule.reminders_today'}:
        if not SCHEDULE_API_KEY:
            raise HTTPException(503, 'schedule service is not configured')
        try:
            with httpx.Client(timeout=10) as client:
                r = client.get(SCHEDULE_URL + '/reminders', headers={'Authorization': f'Bearer {SCHEDULE_API_KEY}'}, params={'user_id': req.user_id, 'status': str(req.params.get('status') or 'active')})
                r.raise_for_status()
                reminders = (r.json() or {}).get('reminders', [])
            if resource == 'schedule.reminders_today':
                zone = ASSISTANT_ZONE
                today = datetime.now(zone).date()
                filtered = []
                for item in reminders:
                    try:
                        due = datetime.fromisoformat(str(item.get('due_at') or '').replace('Z', '+00:00')).astimezone(zone)
                    except Exception:
                        continue
                    if due.date() == today:
                        filtered.append(item)
                reminders = filtered
            return {'status': 'ok', 'disposition': 'READ', 'resource': resource, 'authoritative': True, 'result_count': len(reminders), 'reminders': reminders, 'timezone': LIFE_ASSISTANT_TIMEZONE}
        except httpx.HTTPError as exc:
            raise HTTPException(502, f'reminder read failed: {type(exc).__name__}')
    if resource in {'calendar.today', 'calendar.tomorrow', 'calendar.week'}:
        if not CALENDAR_INTELLIGENCE_API_KEY:
            raise HTTPException(503, 'calendar intelligence service is not configured')
        zone = ASSISTANT_ZONE
        now_local = datetime.now(zone)
        if resource == 'calendar.today':
            anchor = now_local
            period = 'day'
        elif resource == 'calendar.tomorrow':
            anchor = now_local + timedelta(days=1)
            period = 'day'
        else:
            anchor = now_local
            period = 'week'
        try:
            with httpx.Client(timeout=10) as client:
                r = client.get(f'{CALENDAR_INTELLIGENCE_URL}/agenda/{period}', headers={'Authorization': f'Bearer {CALENDAR_INTELLIGENCE_API_KEY}'}, params={'user_id': req.user_id, 'anchor': anchor.astimezone(timezone.utc).isoformat()})
                r.raise_for_status()
                data = r.json() or {}
            events = data.get('events', [])
            return {'status': 'ok', 'disposition': 'READ', 'resource': resource, 'authoritative': True, 'result_count': len(events), 'events': events, 'start': data.get('start'), 'end': data.get('end'), 'timezone': LIFE_ASSISTANT_TIMEZONE}
        except httpx.HTTPError as exc:
            raise HTTPException(502, f'calendar read failed: {type(exc).__name__}')
    if resource == 'current_state.summary':
        if not CURRENT_STATE_API_KEY:
            raise HTTPException(503, 'current state service is not configured')
        try:
            with httpx.Client(timeout=10) as client:
                r = client.get(CURRENT_STATE_URL + '/snapshot/' + req.user_id, headers={'Authorization': f'Bearer {CURRENT_STATE_API_KEY}'})
                r.raise_for_status()
                data = r.json() or {}
            return {'status': 'ok', 'disposition': 'READ', 'resource': resource, 'authoritative': True, 'result_count': 1, 'data': data}
        except httpx.HTTPError as exc:
            raise HTTPException(502, f'current-state read failed: {type(exc).__name__}')
    raise HTTPException(400, f'unsupported read resource: {req.resource}')
