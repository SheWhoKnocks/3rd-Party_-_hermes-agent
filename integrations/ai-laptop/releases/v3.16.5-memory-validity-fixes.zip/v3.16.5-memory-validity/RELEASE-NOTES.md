# v3.16.5 - Trusted memory validity

- Exclude expired and future-dated trusted memories from both ranked API results and prompt context.
- Use inclusive valid_from and exclusive valid_until boundaries with UTC normalization; naive legacy dates are UTC and malformed/inverted windows fail closed.
- Do not reintroduce a rejected trusted-memory text through duplicate Mem0 recall.
- Provide checksummed cumulative and small fixes ZIPs with a runtime-only backup and rollback installer.

Validation: 13 suites passed; 98 Python files compiled; shell syntax checked. Live deployment validation is recorded separately after installation.

Install over a standard v3.16.4+ installation: sudo python3 tools/install-runtime-release.py --dry-run, then sudo python3 tools/install-runtime-release.py. For a fresh machine use the cumulative archive and normal install.sh workflow. The small fixes ZIP requires the existing runtime image/dependencies. Configuration and runtime data are preserved. Each deployment saves source, configuration, prior image tag and a consistent runtime-volume backup under /opt/AI-Install/backups. Roll back code/image using sudo python3 tools/install-runtime-release.py --rollback BACKUP_DIRECTORY; current data is retained. A full data restore is a separate explicit recovery step.
